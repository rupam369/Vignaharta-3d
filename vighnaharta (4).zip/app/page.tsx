"use client";
// ============================================================
// VIGHNAHARTA — THE LOST MODAK · app shell & screen router (3D)
// ============================================================
import dynamic from "next/dynamic";
import { useCallback, useEffect, useMemo, useState } from "react";
import {
  AchievementsPanel, HowToPlay, SettingsModal, Toasts,
} from "@/components/Overlays";
import type { Toast } from "@/components/Overlays";
import { StoryIntro, TitleScreen, WorldMap } from "@/components/Screens";
import { audio } from "@/game/audio";
import { getDailyConfig } from "@/game/daily";
import {
  awardAchievement, loadProgress, recordLevelResult, resetProgress, saveProgress,
} from "@/game/storage";
import { ACHIEVEMENTS, WORLD_META } from "@/game/types";
import type { LevelResult, PlayId, Progress, Screen } from "@/game/types";

// Three.js renders client-side only.
const GameView3D = dynamic(() => import("@/components/GameView3D"), {
  ssr: false,
  loading: () => (
    <div className="boot">
      <div className="boot-diya">🪔</div>
      <div>Building the festival…</div>
    </div>
  ),
});

let toastKey = 1;

export default function Home() {
  const [progress, setProgress] = useState<Progress | null>(null);
  const [screen, setScreen] = useState<Screen>("title");
  const [playId, setPlayId] = useState<PlayId>(1);
  const [showSettings, setShowSettings] = useState(false);
  const [showHowTo, setShowHowTo] = useState(false);
  const [showAch, setShowAch] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const daily = useMemo(() => getDailyConfig(), []);

  // Boot: load save, apply audio prefs, unlock AudioContext on first gesture.
  useEffect(() => {
    const p = loadProgress();
    setProgress(p);
    audio.setEnabled(p.settings.sound, p.settings.music);
    audio.setVolumes(p.settings.masterVolume, p.settings.musicVolume, p.settings.sfxVolume);
    const unlock = () => audio.ensure();
    window.addEventListener("pointerdown", unlock, { once: true });
    window.addEventListener("keydown", unlock, { once: true });
    return () => {
      window.removeEventListener("pointerdown", unlock);
      window.removeEventListener("keydown", unlock);
    };
  }, []);

  // Menu music on non-game screens (game levels run their own music).
  useEffect(() => {
    if (!progress) return;
    if (screen === "title" || screen === "story" || screen === "map") {
      audio.playMusic("menu");
    }
  }, [screen, progress]);

  // Duck all audio when the tab hides; resume on return (game screen is
  // resumed by the engine's own pause toggle instead).
  useEffect(() => {
    const onVis = () => {
      if (document.hidden) audio.pauseAll(true);
      else if (screen !== "game") audio.pauseAll(false);
    };
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, [screen]);

  const update = useCallback((p: Progress) => {
    setProgress(p);
    saveProgress(p);
  }, []);

  const pushToast = useCallback((icon: string, name: string, desc: string) => {
    const key = toastKey++;
    setToasts((t) => [...t.slice(-2), { key, icon, name, desc }]);
    window.setTimeout(() => setToasts((t) => t.filter((x) => x.key !== key)), 3800);
  }, []);

  // Playtest shortcut (hidden): press U 3 times on the map to unlock all worlds.
  useEffect(() => {
    if (screen !== "map") return;
    let taps = 0;
    let timer = 0;
    const onKey = (e: KeyboardEvent) => {
      if (e.code !== "KeyU") return;
      taps++;
      window.clearTimeout(timer);
      timer = window.setTimeout(() => { taps = 0; }, 1800);
      if (taps >= 3) {
        taps = 0;
        setProgress((prev) => {
          if (!prev || prev.unlockedWorld >= 5) return prev;
          const p = { ...prev, unlockedWorld: 5 };
          saveProgress(p);
          return p;
        });
        audio.achievement();
        pushToast("🔓", "All worlds unlocked", "Happy playtesting!");
      }
    };
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.clearTimeout(timer);
    };
  }, [screen, pushToast]);

  const grant = useCallback(
    (base: Progress, id: string): Progress => {
      const [p, isNew] = awardAchievement(base, id);
      if (isNew) {
        const def = ACHIEVEMENTS.find((a) => a.id === id);
        audio.achievement();
        pushToast(def?.icon ?? "🏆", def?.name ?? id, def?.desc ?? "");
      }
      return p;
    },
    [pushToast]
  );

  const handleAchievement = useCallback(
    (id: string) => {
      setProgress((prev) => {
        if (!prev) return prev;
        const p = grant(prev, id);
        if (p !== prev) saveProgress(p);
        return p;
      });
    },
    [grant]
  );

  const handleComplete = useCallback(
    (r: LevelResult) => {
      setProgress((prev) => {
        if (!prev) return prev;
        const { progress: recorded } = recordLevelResult(prev, r);
        let p = recorded;
        if (r.worldId === 1 && r.victory && r.heartsLeft >= 3) p = grant(p, "master_streets");
        if (p.totalDiyas >= 20) p = grant(p, "light_the_night");
        if ([1, 2, 3, 4].every((i) => p.worlds[String(i)]?.completed)) p = grant(p, "explorer");
        saveProgress(p);
        return p;
      });
    },
    [grant]
  );

  if (!progress) {
    return (
      <div className="boot">
        <div className="boot-diya">🪔</div>
        <div>Lighting the diyas…</div>
      </div>
    );
  }

  const settings = progress.settings;
  const goGame = (id: PlayId) => {
    setPlayId(id);
    setScreen("game");
  };
  const finishStory = () => {
    update({ ...progress, seenIntro: true });
    setScreen("map");
  };

  const worldMeta = typeof playId === "number" ? WORLD_META.find((w) => w.id === playId) : null;

  return (
    <div className={`app ${settings.highContrast ? "hc" : ""} ${settings.reducedMotion ? "rm" : ""}`}>
      {screen === "title" && (
        <TitleScreen
          hasSave={progress.hasPlayed || progress.seenIntro}
          playerName={settings.playerName}
          onPlay={() => (progress.seenIntro ? setScreen("map") : setScreen("story"))}
          onContinue={() => setScreen("map")}
          onDaily={() => goGame("daily")}
          onHowTo={() => setShowHowTo(true)}
          onSettings={() => setShowSettings(true)}
        />
      )}

      {screen === "story" && <StoryIntro onDone={finishStory} onSkip={finishStory} />}

      {screen === "map" && (
        <WorldMap
          progress={progress}
          daily={daily}
          dailyBest={progress.dailyBest[daily.key] ?? 0}
          onPlayWorld={(id) => goGame(id)}
          onPlayDaily={() => goGame("daily")}
          onHowTo={() => setShowHowTo(true)}
          onSettings={() => setShowSettings(true)}
          onAchievements={() => setShowAch(true)}
        />
      )}

      {screen === "game" && (
        <GameView3D
          key={String(playId)}
          playId={playId}
          settings={settings}
          best={
            playId === "daily"
              ? progress.dailyBest[daily.key] ?? 0
              : progress.worlds[String(playId)]?.bestScore ?? 0
          }
          daily={
            playId === "daily"
              ? { seed: daily.seed, goalModaks: daily.goalModaks, timeLimit: daily.timeLimit }
              : null
          }
          title={playId === "daily" ? "Daily Challenge" : worldMeta?.name ?? ""}
          onExit={() => setScreen("map")}
          onNext={
            typeof playId === "number" && playId < 5
              ? () => goGame((playId + 1) as PlayId)
              : null
          }
          onComplete={handleComplete}
          onAchievement={handleAchievement}
          onOpenSettings={() => setShowSettings(true)}
        />
      )}

      {showSettings && (
        <SettingsModal
          settings={settings}
          onChange={(s) => {
            update({ ...progress, settings: s });
            audio.setEnabled(s.sound, s.music);
            audio.setVolumes(s.masterVolume, s.musicVolume, s.sfxVolume);
          }}
          onClose={() => setShowSettings(false)}
          onReset={() => {
            const fresh = resetProgress();
            setProgress(fresh);
            audio.setEnabled(true, true);
            audio.setVolumes(
              fresh.settings.masterVolume,
              fresh.settings.musicVolume,
              fresh.settings.sfxVolume
            );
            setShowSettings(false);
            setScreen("title");
          }}
        />
      )}
      {showHowTo && <HowToPlay onClose={() => setShowHowTo(false)} />}
      {showAch && (
        <AchievementsPanel unlocked={progress.achievements} onClose={() => setShowAch(false)} />
      )}
      <Toasts toasts={toasts} />
    </div>
  );
}
