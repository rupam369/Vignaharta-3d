import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Vighnaharta — The Lost Modak",
  description:
    "A Ganesh Chaturthi festival adventure game. Guide Mushak through 5 magical worlds to recover the lost Modak. Ganapati Bappa Morya!",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: "cover",
  themeColor: "#0b1030",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <link
          rel="icon"
          href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Ccircle cx='32' cy='32' r='30' fill='%230b1030'/%3E%3Cellipse cx='32' cy='38' rx='14' ry='10' fill='%23f5b942'/%3E%3Cpath d='M32 10 C36 18 40 24 44 28 L20 28 C24 24 28 18 32 10Z' fill='%23ffe9c4'/%3E%3Ccircle cx='32' cy='14' r='3' fill='%23ff7a1a'/%3E%3C/svg%3E"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
