// ============================================================
// HTML overlay: floating +score popups, prompts, big titles,
// fade veil & hit flash. Crisp text without canvas textures.
// ============================================================
import * as THREE from "three";

interface Floater {
  el: HTMLDivElement;
  alive: boolean;
  x: number; y: number; z: number;
  life: number;
}

export class Floaters {
  private container: HTMLElement;
  private pool: Floater[] = [];
  private tmp = new THREE.Vector3();
  private veil: HTMLDivElement;
  private flash: HTMLDivElement;
  private prompt: HTMLDivElement;
  private titleBox: HTMLDivElement;

  constructor(container: HTMLElement) {
    this.container = container;
    for (let i = 0; i < 14; i++) {
      const el = document.createElement("div");
      el.className = "floater3d";
      el.style.display = "none";
      container.appendChild(el);
      this.pool.push({ el, alive: false, x: 0, y: 0, z: 0, life: 0 });
    }
    this.prompt = document.createElement("div");
    this.prompt.className = "interact-prompt";
    this.prompt.style.display = "none";
    container.appendChild(this.prompt);

    this.titleBox = document.createElement("div");
    this.titleBox.className = "big-title-box";
    this.titleBox.style.display = "none";
    container.appendChild(this.titleBox);

    this.flash = document.createElement("div");
    this.flash.className = "flash-veil";
    container.appendChild(this.flash);

    this.veil = document.createElement("div");
    this.veil.className = "fade-veil";
    container.appendChild(this.veil);
  }

  spawn(x: number, y: number, z: number, text: string, cls = ""): void {
    const f = this.pool.find((p) => !p.alive) ?? this.pool[0];
    f.alive = true;
    f.x = x; f.y = y; f.z = z;
    f.life = 1;
    f.el.textContent = text;
    f.el.className = `floater3d pop-in ${cls}`;
    f.el.style.display = "block";
  }

  setPrompt(text: string | null): void {
    if (!text) {
      this.prompt.style.display = "none";
      return;
    }
    if (this.prompt.style.display === "none" || this.prompt.textContent !== text) {
      this.prompt.textContent = text;
      this.prompt.style.display = "block";
    }
  }

  bigTitle(main: string, sub = ""): void {
    this.titleBox.innerHTML = `<div class="big-title">${main}</div>${sub ? `<div class="big-sub">${sub}</div>` : ""}`;
    this.titleBox.style.display = "flex";
    // retrigger animation
    this.titleBox.classList.remove("show");
    void this.titleBox.offsetWidth;
    this.titleBox.classList.add("show");
  }

  hideTitle(): void {
    this.titleBox.style.display = "none";
  }

  hitFlash(): void {
    this.flash.classList.remove("go");
    void this.flash.offsetWidth;
    this.flash.classList.add("go");
  }

  fade(inOut: "in" | "out", ms = 600): void {
    this.veil.style.transitionDuration = `${ms}ms`;
    this.veil.classList.toggle("dark", inOut === "out");
  }

  update(dt: number, camera: THREE.Camera, w: number, h: number): void {
    for (const f of this.pool) {
      if (!f.alive) continue;
      f.life -= dt;
      if (f.life <= 0) {
        f.alive = false;
        f.el.style.display = "none";
        continue;
      }
      f.y += dt * 1.6;
      this.tmp.set(f.x, f.y, f.z).project(camera);
      if (this.tmp.z > 1) {
        f.el.style.display = "none";
        continue;
      }
      f.el.style.display = "block";
      f.el.style.left = `${(this.tmp.x * 0.5 + 0.5) * w}px`;
      f.el.style.top = `${(-this.tmp.y * 0.5 + 0.5) * h}px`;
      f.el.style.opacity = String(Math.min(1, f.life * 2.4));
    }
  }

  clear(): void {
    for (const f of this.pool) {
      f.alive = false;
      f.el.style.display = "none";
    }
    this.setPrompt(null);
    this.hideTitle();
  }

  destroy(): void {
    this.container.innerHTML = "";
  }
}
