// ============================================================
// Third-person follow camera: smoothed follow, drag-look
// (mouse + touch), gentle auto-align that never fights manual
// drags, trauma shake, sprint FOV kick, and a cinematic orbit
// mode for celebrations.
// ============================================================
import * as THREE from "three";

const BASE_FOV = 58;

export class FollowCamera {
  yaw = 0;
  pitch = 0.42;
  dist = 7.2;
  target = new THREE.Vector3();
  private shake = 0;
  private sx = 0;
  private sy = 0;
  /** seconds of manual-drag grace before auto-align resumes */
  private alignPause = 0;
  cine: { t: number; dur: number; cx: number; cz: number; r: number; h: number } | null = null;

  reset(yaw: number, playerPos: THREE.Vector3): void {
    this.yaw = yaw;
    this.pitch = 0.42;
    this.target.copy(playerPos);
    this.cine = null;
    this.shake = 0;
    this.alignPause = 0;
  }

  addShake(amount: number): void {
    this.shake = Math.min(1, this.shake + amount);
  }

  applyDrag(dx: number, dy: number): void {
    this.yaw -= dx * 0.0042;
    this.pitch += dy * 0.0032;
    this.pitch = Math.max(0.08, Math.min(1.15, this.pitch));
    if (Math.abs(dx) + Math.abs(dy) > 0.5) this.alignPause = 1.4;
  }

  startCine(dur: number, cx: number, cz: number, r = 13, h = 6): void {
    this.cine = { t: 0, dur, cx, cz, r, h };
  }

  update(
    dt: number,
    camera: THREE.PerspectiveCamera,
    playerPos: THREE.Vector3,
    faceYaw: number,
    moving: boolean,
    groundY: (x: number, z: number) => number,
    reducedMotion: boolean,
    fovKick = 0
  ): void {
    // shake decay
    this.shake = Math.max(0, this.shake - dt * 1.7);
    const sh = reducedMotion ? 0 : this.shake * this.shake * 0.9;
    this.sx = (Math.random() * 2 - 1) * sh;
    this.sy = (Math.random() * 2 - 1) * sh;

    if (this.cine) {
      const c = this.cine;
      c.t += dt;
      const a = c.t * 0.42;
      const px = c.cx + Math.cos(a) * c.r;
      const pz = c.cz + Math.sin(a) * c.r;
      const py = c.h + Math.sin(c.t * 0.5) * 1.2;
      camera.position.set(px + this.sx, py + this.sy, pz);
      this.target.set(c.cx, 2.2, c.cz);
      camera.lookAt(this.target);
      // ease FOV back to base during cinematics
      if (Math.abs(camera.fov - BASE_FOV) > 0.05) {
        camera.fov += (BASE_FOV - camera.fov) * Math.min(1, dt * 4);
        camera.updateProjectionMatrix();
      }
      return;
    }

    // gentle auto-align behind movement direction — paused after drags
    if (this.alignPause > 0) this.alignPause -= dt;
    if (moving && this.alignPause <= 0) {
      let d = faceYaw - this.yaw;
      while (d > Math.PI) d -= Math.PI * 2;
      while (d < -Math.PI) d += Math.PI * 2;
      this.yaw += d * Math.min(1, dt * 0.85);
    }

    // smoothed focus (player chest)
    const fx = playerPos.x;
    const fy = playerPos.y + 1.55;
    const fz = playerPos.z;
    const k = Math.min(1, dt * 7);
    this.target.x += (fx - this.target.x) * k;
    this.target.y += (fy - this.target.y) * k;
    this.target.z += (fz - this.target.z) * k;

    const cp = Math.cos(this.pitch);
    const sp = Math.sin(this.pitch);
    let cx = this.target.x - Math.sin(this.yaw) * cp * this.dist;
    let cz = this.target.z - Math.cos(this.yaw) * cp * this.dist;
    let cy = this.target.y + sp * this.dist;
    // keep camera out of the ground
    const minY = groundY(cx, cz) + 0.6;
    if (cy < minY) cy = minY;
    camera.position.set(cx + this.sx, cy + this.sy, cz);
    camera.lookAt(this.target);

    // smooth sprint FOV kick
    const wantFov = BASE_FOV + (reducedMotion ? 0 : fovKick);
    if (Math.abs(camera.fov - wantFov) > 0.02) {
      camera.fov += (wantFov - camera.fov) * Math.min(1, dt * 5);
      camera.updateProjectionMatrix();
    }
  }
}
