// ============================================================
// Procedural festival art — every mesh built in code.
// Shared materials, instanced diyas/marigolds, merged bunting,
// canvas textures (rangoli, stripes, water, numerals).
// No external models, no copyrighted assets.
// ============================================================
import * as THREE from "three";

// ---------------- material cache ----------------
const matCache = new Map<string, THREE.Material>();

export function std(color: number, rough = 0.8, metal = 0.05): THREE.MeshStandardMaterial {
  const key = `s${color}-${rough}-${metal}`;
  let m = matCache.get(key) as THREE.MeshStandardMaterial | undefined;
  if (!m) {
    m = new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal });
    matCache.set(key, m);
  }
  return m;
}

export function glow(color: number, intensity = 1.2): THREE.MeshBasicMaterial {
  const key = `g${color}-${intensity}`;
  let m = matCache.get(key) as THREE.MeshBasicMaterial | undefined;
  if (!m) {
    m = new THREE.MeshBasicMaterial({ color: new THREE.Color(color).multiplyScalar(intensity) });
    matCache.set(key, m);
  }
  return m;
}

export function glowStd(color: number, emissive: number, ei = 0.9, rough = 0.6): THREE.MeshStandardMaterial {
  const key = `e${color}-${emissive}-${ei}`;
  let m = matCache.get(key) as THREE.MeshStandardMaterial | undefined;
  if (!m) {
    m = new THREE.MeshStandardMaterial({
      color, roughness: rough, metalness: 0.1,
      emissive: new THREE.Color(emissive), emissiveIntensity: ei,
    });
    matCache.set(key, m);
  }
  return m;
}

// ---------------- canvas textures ----------------
function canvasTex(size: number, draw: (c: CanvasRenderingContext2D, s: number) => void): THREE.CanvasTexture {
  const cv = document.createElement("canvas");
  cv.width = size;
  cv.height = size;
  const c = cv.getContext("2d");
  if (!c) throw new Error("no 2d ctx");
  draw(c, size);
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

let _glowTex: THREE.Texture | null = null;
export function glowTexture(): THREE.Texture {
  if (_glowTex) return _glowTex;
  _glowTex = canvasTex(128, (c, s) => {
    const g = c.createRadialGradient(s / 2, s / 2, 2, s / 2, s / 2, s / 2);
    g.addColorStop(0, "rgba(255,245,220,1)");
    g.addColorStop(0.35, "rgba(255,200,120,0.55)");
    g.addColorStop(1, "rgba(255,150,50,0)");
    c.fillStyle = g;
    c.fillRect(0, 0, s, s);
  });
  return _glowTex;
}

export function glowSprite(color = 0xffc87a, size = 1.2, opacity = 0.85): THREE.Sprite {
  const m = new THREE.SpriteMaterial({
    map: glowTexture(), color, transparent: true, opacity,
    blending: THREE.AdditiveBlending, depthWrite: false,
  });
  const s = new THREE.Sprite(m);
  s.scale.set(size, size, 1);
  return s;
}

export function stripeTexture(c1: string, c2: string): THREE.CanvasTexture {
  return canvasTex(128, (c, s) => {
    const n = 8;
    for (let i = 0; i < n; i++) {
      c.fillStyle = i % 2 === 0 ? c1 : c2;
      c.fillRect((s / n) * i, 0, s / n, s);
    }
  });
}

export function rangoliTexture(): THREE.CanvasTexture {
  return canvasTex(512, (c, s) => {
    const cx = s / 2;
    const cy = s / 2;
    c.clearRect(0, 0, s, s);
    // base disc
    const bg = c.createRadialGradient(cx, cy, 10, cx, cy, s / 2);
    bg.addColorStop(0, "#3d1f4d");
    bg.addColorStop(0.75, "#2a1540");
    bg.addColorStop(1, "rgba(30,10,40,0)");
    c.fillStyle = bg;
    c.beginPath();
    c.arc(cx, cy, s / 2, 0, Math.PI * 2);
    c.fill();
    const ring = (r: number, n: number, len: number, w: number, col: string, rot = 0) => {
      c.fillStyle = col;
      for (let i = 0; i < n; i++) {
        const a = rot + (i / n) * Math.PI * 2;
        c.save();
        c.translate(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
        c.rotate(a + Math.PI / 2);
        c.beginPath();
        c.ellipse(0, 0, w, len, 0, 0, Math.PI * 2);
        c.fill();
        c.restore();
      }
    };
    ring(s * 0.4, 24, 26, 10, "#ff6b8b");
    ring(s * 0.4, 24, 14, 5, "#ffd43b", Math.PI / 24);
    ring(s * 0.3, 16, 30, 13, "#c77dff");
    ring(s * 0.3, 16, 16, 6, "#fff3d6", Math.PI / 16);
    ring(s * 0.18, 12, 26, 11, "#ffa94d");
    ring(s * 0.18, 12, 13, 5, "#e63956", Math.PI / 12);
    // dots
    c.fillStyle = "#fff6e3";
    for (let i = 0; i < 32; i++) {
      const a = (i / 32) * Math.PI * 2;
      c.beginPath();
      c.arc(cx + Math.cos(a) * s * 0.465, cy + Math.sin(a) * s * 0.465, 4, 0, Math.PI * 2);
      c.fill();
    }
    // center flower
    c.fillStyle = "#ffd43b";
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2;
      c.beginPath();
      c.ellipse(cx + Math.cos(a) * 22, cy + Math.sin(a) * 22, 16, 9, a, 0, Math.PI * 2);
      c.fill();
    }
    c.fillStyle = "#e63956";
    c.beginPath();
    c.arc(cx, cy, 14, 0, Math.PI * 2);
    c.fill();
    // outer gold ring
    c.strokeStyle = "#f5b942";
    c.lineWidth = 6;
    c.beginPath();
    c.arc(cx, cy, s * 0.485, 0, Math.PI * 2);
    c.stroke();
  });
}

export function waterTexture(): THREE.CanvasTexture {
  const t = canvasTex(256, (c, s) => {
    c.fillStyle = "#0e2a55";
    c.fillRect(0, 0, s, s);
    for (let i = 0; i < 40; i++) {
      c.fillStyle = i % 3 === 0 ? "rgba(255,200,120,0.25)" : "rgba(126,200,255,0.22)";
      const y = Math.random() * s;
      c.fillRect(Math.random() * s, y, 20 + Math.random() * 46, 2.5);
    }
  });
  t.wrapS = THREE.RepeatWrapping;
  t.wrapT = THREE.RepeatWrapping;
  return t;
}

export function flowerTexture(): THREE.CanvasTexture {
  return canvasTex(128, (c, s) => {
    c.clearRect(0, 0, s, s);
    const cx = s / 2;
    const cy = s / 2;
    const cols = ["#ff6b8b", "#ff8fa8", "#ff6b8b", "#ff8fa8", "#ff6b8b"];
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * Math.PI * 2;
      c.fillStyle = cols[i];
      c.beginPath();
      c.ellipse(cx + Math.cos(a) * 26, cy + Math.sin(a) * 26, 24, 15, a, 0, Math.PI * 2);
      c.fill();
    }
    c.fillStyle = "#ffd43b";
    c.beginPath();
    c.arc(cx, cy, 14, 0, Math.PI * 2);
    c.fill();
  });
}

export function numeralTexture(n: number): THREE.CanvasTexture {
  return canvasTex(128, (c, s) => {
    c.clearRect(0, 0, s, s);
    c.font = "700 72px Georgia, serif";
    c.textAlign = "center";
    c.textBaseline = "middle";
    c.shadowColor = "rgba(255,190,90,0.95)";
    c.shadowBlur = 22;
    c.fillStyle = "#fff3d6";
    c.fillText(String(n), s / 2, s / 2 + 4);
  });
}

// ---------------- small helpers ----------------
function mesh(geo: THREE.BufferGeometry, m: THREE.Material, x = 0, y = 0, z = 0, shadow = false): THREE.Mesh {
  const o = new THREE.Mesh(geo, m);
  o.position.set(x, y, z);
  o.castShadow = shadow;
  o.receiveShadow = false;
  return o;
}

const box = (w: number, h: number, d: number) => new THREE.BoxGeometry(w, h, d);
const cyl = (rt: number, rb: number, h: number, s = 12) => new THREE.CylinderGeometry(rt, rb, h, s);
const sph = (r: number, w = 12, h = 10) => new THREE.SphereGeometry(r, w, h);

// ---------------- collectibles ----------------
export function makeModak(s = 1): THREE.Group {
  const g = new THREE.Group();
  const pts = [
    new THREE.Vector2(0.001, 0), new THREE.Vector2(0.2, 0.015), new THREE.Vector2(0.24, 0.1),
    new THREE.Vector2(0.19, 0.24), new THREE.Vector2(0.1, 0.38), new THREE.Vector2(0.035, 0.46),
    new THREE.Vector2(0.001, 0.48),
  ];
  const body = new THREE.Mesh(new THREE.LatheGeometry(pts, 16), std(0xfff3dc, 0.55));
  body.castShadow = true;
  const crown = mesh(sph(0.05, 10, 8), glowStd(0xf5b942, 0x664400, 0.5), 0, 0.5, 0);
  g.add(body, crown);
  g.scale.setScalar(s);
  return g;
}

export function makeToken(): THREE.Group {
  const g = new THREE.Group();
  const coin = new THREE.Mesh(cyl(0.22, 0.22, 0.06, 20), glowStd(0xf5b942, 0x7a4d00, 0.65, 0.3));
  coin.rotation.x = Math.PI / 2;
  coin.castShadow = true;
  const rim = new THREE.Mesh(new THREE.TorusGeometry(0.22, 0.035, 8, 24), std(0xc47f12, 0.4, 0.5));
  g.add(coin, rim);
  return g;
}

let _flowerTex: THREE.Texture | null = null;
export function makeFlower3D(s = 1): THREE.Group {
  if (!_flowerTex) _flowerTex = flowerTexture();
  const g = new THREE.Group();
  const m = new THREE.MeshBasicMaterial({ map: _flowerTex, transparent: true, side: THREE.DoubleSide, alphaTest: 0.1 });
  const p1 = new THREE.Mesh(new THREE.PlaneGeometry(0.55, 0.55), m);
  const p2 = p1.clone();
  p2.rotation.y = Math.PI / 2;
  p1.position.y = 0.3;
  p2.position.y = 0.3;
  const stem = mesh(cyl(0.02, 0.03, 0.3, 6), std(0x2f9e6e, 0.9), 0, 0.12, 0);
  g.add(p1, p2, stem);
  g.scale.setScalar(s);
  return g;
}

export function makeDiyaSingle(s = 1): THREE.Group {
  const g = new THREE.Group();
  g.add(mesh(cyl(0.13, 0.07, 0.08, 12), std(0x8a4b1f, 0.85), 0, 0.04, 0, true));
  const fl = glowSprite(0xffc87a, 0.55 * s, 0.95);
  fl.position.y = 0.24;
  g.add(fl);
  g.scale.setScalar(s);
  return g;
}

/** tall light beam for fragments / flame targets (additive, no depth write) */
export function makeBeam(color = 0xffd489, r = 0.35, h = 9): THREE.Mesh {
  const m = new THREE.MeshBasicMaterial({
    color, transparent: true, opacity: 0.32,
    blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide,
  });
  const o = new THREE.Mesh(cyl(r, r * 1.4, h, 12, ), m);
  o.position.y = h / 2;
  return o;
}

// ---------------- instanced diya field (1 draw call) ----------------
export class DiyaField {
  private mats4: THREE.Matrix4[] = [];
  private scales: number[] = [];
  flames: { x: number; y: number; z: number }[] = [];

  add(x: number, y: number, z: number, s = 1): void {
    const m = new THREE.Matrix4();
    m.makeScale(s, s, s);
    m.setPosition(x, y, z);
    this.mats4.push(m);
    this.scales.push(s);
    this.flames.push({ x, y: y + 0.26 * s, z });
  }

  build(scene: THREE.Scene): void {
    if (this.mats4.length === 0) return;
    const geo = cyl(0.13, 0.07, 0.09, 10);
    const inst = new THREE.InstancedMesh(geo, std(0x8a4b1f, 0.85), this.mats4.length);
    for (let i = 0; i < this.mats4.length; i++) inst.setMatrixAt(i, this.mats4[i]);
    inst.instanceMatrix.needsUpdate = true;
    scene.add(inst);
  }
}

// ---------------- instanced marigold/flower puffs (1 draw call) ----------------
export class PuffField {
  private items: { x: number; y: number; z: number; s: number; c: number }[] = [];

  add(x: number, y: number, z: number, s: number, c: number): void {
    this.items.push({ x, y, z, s, c });
  }

  strand(x1: number, y1: number, z1: number, x2: number, y2: number, z2: number, sag = 0.5): void {
    const n = 9;
    for (let i = 0; i <= n; i++) {
      const u = i / n;
      const x = x1 + (x2 - x1) * u;
      const z = z1 + (z2 - z1) * u;
      const y = y1 + (y2 - y1) * u - Math.sin(Math.PI * u) * sag;
      this.add(x, y, z, 0.09 + (i % 3) * 0.015, i % 2 === 0 ? 0xff8c1a : 0xffc93c);
    }
  }

  hang(x: number, y: number, z: number, len = 1.2): void {
    const n = Math.max(3, Math.floor(len / 0.16));
    for (let i = 0; i < n; i++) {
      this.add(x, y - i * 0.16, z, 0.085, i % 2 === 0 ? 0xff8c1a : 0xffc93c);
    }
  }

  build(scene: THREE.Scene): void {
    if (this.items.length === 0) return;
    const geo = new THREE.IcosahedronGeometry(1, 0);
    const inst = new THREE.InstancedMesh(geo, std(0xffffff, 0.9), this.items.length);
    const m = new THREE.Matrix4();
    const col = new THREE.Color();
    for (let i = 0; i < this.items.length; i++) {
      const it = this.items[i];
      m.makeScale(it.s, it.s, it.s);
      m.setPosition(it.x, it.y, it.z);
      inst.setMatrixAt(i, m);
      inst.setColorAt(i, col.setHex(it.c));
    }
    inst.instanceMatrix.needsUpdate = true;
    if (inst.instanceColor) inst.instanceColor.needsUpdate = true;
    scene.add(inst);
  }
}

// ---------------- merged bunting (2 draw calls: flags + line) ----------------
export class BuntingField {
  private triPos: number[] = [];
  private triCol: number[] = [];
  private linePos: number[] = [];
  private palette = [0xff7a1a, 0xf5b942, 0xe63956, 0x2f9e6e, 0x7ec8ff, 0xc77dff];

  span(x1: number, y1: number, z1: number, x2: number, y2: number, z2: number, sag = 1.2, flags = 9): void {
    const c = new THREE.Color();
    let px = x1;
    let py = y1;
    let pz = z1;
    for (let i = 1; i <= 16; i++) {
      const u = i / 16;
      const x = x1 + (x2 - x1) * u;
      const z = z1 + (z2 - z1) * u;
      const y = y1 + (y2 - y1) * u - Math.sin(Math.PI * u) * sag;
      this.linePos.push(px, py, pz, x, y, z);
      px = x; py = y; pz = z;
    }
    for (let i = 1; i <= flags; i++) {
      const u = i / (flags + 1);
      const x = x1 + (x2 - x1) * u;
      const z = z1 + (z2 - z1) * u;
      const y = y1 + (y2 - y1) * u - Math.sin(Math.PI * u) * sag;
      const dx = (x2 - x1) / flags;
      const dz = (z2 - z1) / flags;
      const w = Math.hypot(dx, dz) * 0.32;
      const nx = -dz;
      const nz = dx;
      const nl = Math.hypot(nx, nz) || 1;
      c.setHex(this.palette[i % this.palette.length]);
      // triangle hanging down
      this.triPos.push(x - (nx / nl) * w, y, z - (nz / nl) * w);
      this.triPos.push(x + (nx / nl) * w, y, z + (nz / nl) * w);
      this.triPos.push(x, y - 0.55, z);
      for (let k = 0; k < 3; k++) this.triCol.push(c.r, c.g, c.b);
    }
  }

  build(scene: THREE.Scene): void {
    if (this.triPos.length > 0) {
      const g = new THREE.BufferGeometry();
      g.setAttribute("position", new THREE.BufferAttribute(new Float32Array(this.triPos), 3));
      g.setAttribute("color", new THREE.BufferAttribute(new Float32Array(this.triCol), 3));
      const m = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.DoubleSide }));
      scene.add(m);
    }
    if (this.linePos.length > 0) {
      const g = new THREE.BufferGeometry();
      g.setAttribute("position", new THREE.BufferAttribute(new Float32Array(this.linePos), 3));
      scene.add(new THREE.LineSegments(g, new THREE.LineBasicMaterial({ color: 0xffe9c4, transparent: true, opacity: 0.6 })));
    }
  }
}

// ---------------- structures ----------------
export function makeStall(canopyA = "#e63956", canopyB = "#ffe9c4"): THREE.Group {
  const g = new THREE.Group();
  const wood = std(0x4a2c14, 0.9);
  const woodDark = std(0x2c1a0c, 0.9);
  g.add(mesh(box(2.6, 1.0, 1.4), wood, 0, 0.75, 0, true));
  g.add(mesh(box(2.8, 0.1, 1.6), woodDark, 0, 1.3, 0));
  // goods
  const goods = glowStd(0xffc46b, 0x552f00, 0.5);
  g.add(mesh(sph(0.14), goods, -0.8, 1.48, 0.2));
  g.add(mesh(sph(0.14), goods, -0.4, 1.48, -0.15));
  g.add(mesh(sph(0.14), goods, 0.1, 1.48, 0.25));
  g.add(mesh(sph(0.14), glowStd(0xff8fa8, 0x550f1e, 0.5), 0.6, 1.48, -0.1));
  g.add(mesh(sph(0.14), goods, 0.95, 1.48, 0.15));
  // poles + striped canopy
  for (const sx of [-1.25, 1.25]) {
    for (const sz of [-0.65, 0.65]) g.add(mesh(cyl(0.05, 0.05, 1.6, 8), woodDark, sx, 2.1, sz));
  }
  const canopy = new THREE.Mesh(
    box(3.0, 0.12, 1.9),
    new THREE.MeshStandardMaterial({ map: stripeTexture(canopyA, canopyB), roughness: 0.85 })
  );
  canopy.position.set(0, 2.95, 0);
  canopy.rotation.x = 0.1;
  canopy.castShadow = true;
  g.add(canopy);
  // wheels
  const wheelG = new THREE.CylinderGeometry(0.32, 0.32, 0.1, 12);
  for (const sx of [-0.9, 0.9]) {
    const w = mesh(wheelG, woodDark, sx, 0.32, 0.75);
    w.rotation.x = Math.PI / 2;
    g.add(w);
  }
  return g;
}

export function makeBuilding(w: number, h: number, d: number, color = 0x1c1638): THREE.Group {
  const g = new THREE.Group();
  g.add(mesh(box(w, h, d), std(color, 0.95), 0, h / 2, 0, true));
  g.add(mesh(box(w + 0.5, 0.4, d + 0.5), std(0x120e28, 0.95), 0, h + 0.2, 0));
  // glowing window strips (front + back)
  const winM = glow(0xffca7a, 0.9);
  const strip = new THREE.PlaneGeometry(w * 0.7, h * 0.16);
  for (const zz of [d / 2 + 0.02, -d / 2 - 0.02]) {
    for (const yy of [h * 0.35, h * 0.68]) {
      const p = new THREE.Mesh(strip, winM);
      p.position.set(0, yy, zz);
      if (zz < 0) p.rotation.y = Math.PI;
      g.add(p);
    }
  }
  return g;
}

export function makeTempleFacade(w = 16, h = 10): THREE.Group {
  const g = new THREE.Group();
  const stone = std(0x4a3f78, 0.85);
  const stoneD = std(0x322a55, 0.9);
  const goldM = glowStd(0xf5b942, 0x664400, 0.6);
  // steps
  for (let i = 0; i < 3; i++) {
    g.add(mesh(box(w + 4 - i * 1.2, 0.35, 2.2), stoneD, 0, 0.17 + i * 0.33, 3.2 - i * 1.1));
  }
  // platform + pillars
  g.add(mesh(box(w, 1.0, 8), stoneD, 0, 0.5, -1));
  for (let i = 0; i < 5; i++) {
    const x = -w / 2 + 1.5 + (i * (w - 3)) / 4;
    g.add(mesh(cyl(0.45, 0.55, h * 0.62, 12), stone, x, 1 + h * 0.31, 1.6, true));
    g.add(mesh(box(1.3, 0.35, 1.3), goldM, x, 1 + h * 0.62 + 0.17, 1.6));
  }
  // lintel + shikhara tower
  g.add(mesh(box(w + 1, 1.2, 3.4), stone, 0, 1 + h * 0.62 + 0.9, 0.4, true));
  let tw = w * 0.42;
  let ty = 1 + h * 0.62 + 1.5;
  for (let i = 0; i < 4; i++) {
    g.add(mesh(box(tw, 1.5, tw * 0.7), i % 2 ? stoneD : stone, 0, ty + 0.75, -1, true));
    ty += 1.5;
    tw *= 0.78;
  }
  g.add(mesh(sph(0.55, 12, 10), goldM, 0, ty + 0.5, -1));
  // glowing sanctum doorway (abstract light — no figures)
  g.add(mesh(box(3.4, 4.6, 0.4), std(0x0d0918, 1), 0, 3.2, 2.4));
  const glowPlane = new THREE.Mesh(new THREE.PlaneGeometry(2.6, 3.8), glow(0xffd9a0, 1.1));
  glowPlane.position.set(0, 3.0, 2.62);
  g.add(glowPlane);
  const halo = glowSprite(0xffc87a, 9, 0.5);
  halo.position.set(0, 3.4, 3.2);
  g.add(halo);
  return g;
}

export function makePillar(h = 6): THREE.Group {
  const g = new THREE.Group();
  g.add(mesh(cyl(0.4, 0.5, h, 12), std(0x5a4a8a, 0.8), 0, h / 2, 0, true));
  g.add(mesh(box(1.2, 0.3, 1.2), glowStd(0xf5b942, 0x664400, 0.5), 0, h + 0.15, 0));
  g.add(mesh(box(1.2, 0.3, 1.2), std(0x322a55, 0.9), 0, 0.15, 0));
  return g;
}

export function makeTree(s = 1): THREE.Group {
  const g = new THREE.Group();
  g.add(mesh(cyl(0.22, 0.34, 2.6, 8), std(0x3a2412, 0.95), 0, 1.3, 0, true));
  const leaf = std(0x1d5c40, 0.95);
  const leaf2 = std(0x276e4c, 0.95);
  g.add(mesh(sph(1.7, 10, 8), leaf, 0, 3.4, 0, true));
  g.add(mesh(sph(1.2, 10, 8), leaf2, 0.9, 2.8, 0.4));
  g.add(mesh(sph(1.0, 10, 8), leaf2, -0.9, 2.9, -0.3));
  g.scale.setScalar(s);
  return g;
}

export function makeLampPost(h = 4.2): THREE.Group {
  const g = new THREE.Group();
  g.add(mesh(cyl(0.07, 0.1, h, 8), std(0x2c1f14, 0.9), 0, h / 2, 0, true));
  g.add(mesh(box(0.7, 0.08, 0.08), std(0x2c1f14, 0.9), 0.3, h - 0.25, 0));
  const lamp = mesh(sph(0.2, 10, 8), glow(0xffd98a, 1.2), 0.6, h - 0.5, 0);
  g.add(lamp);
  const halo = glowSprite(0xffc87a, 2.4, 0.55);
  halo.position.set(0.6, h - 0.5, 0);
  g.add(halo);
  return g;
}

export function makeArchGate(w = 5, h = 4.6): THREE.Group {
  const g = new THREE.Group();
  const stone = std(0x5a4a8a, 0.8);
  for (const sx of [-w / 2, w / 2]) {
    g.add(mesh(box(0.7, h, 0.7), stone, sx, h / 2, 0, true));
    g.add(mesh(box(1.1, 0.3, 1.1), glowStd(0xf5b942, 0x664400, 0.5), sx, h + 0.15, 0));
  }
  g.add(mesh(box(w + 1.4, 0.8, 0.9), std(0x3d3464, 0.85), 0, h + 0.55, 0, true));
  return g;
}

export function makeBarrierDhol(): THREE.Group {
  const g = new THREE.Group();
  const drum = mesh(cyl(0.45, 0.45, 1.5, 14), std(0xc96b2b, 0.8), 0, 0.55, 0, true);
  drum.rotation.z = Math.PI / 2;
  g.add(drum);
  for (const sx of [-0.78, 0.78]) {
    const cap = mesh(cyl(0.46, 0.46, 0.06, 14), std(0xf5e3c2, 0.7), sx, 0.55, 0);
    cap.rotation.z = Math.PI / 2;
    g.add(cap);
  }
  return g;
}

export function makeCrate(s = 1): THREE.Mesh {
  const o = mesh(box(s, s, s), std(0x6b421f, 0.9), 0, 0, 0, true);
  return o;
}

export function makePuddle(r = 1.6): THREE.Mesh {
  const m = new THREE.Mesh(
    new THREE.CircleGeometry(r, 24),
    new THREE.MeshStandardMaterial({
      color: 0x14305c, roughness: 0.12, metalness: 0.85,
      transparent: true, opacity: 0.85,
    })
  );
  m.rotation.x = -Math.PI / 2;
  m.position.y = 0.02;
  return m;
}

export function makeBoat(): THREE.Group {
  const g = new THREE.Group();
  const wood = std(0x4a2c14, 0.9);
  g.add(mesh(box(3.4, 0.5, 1.5), wood, 0, 0.25, 0, true));
  g.add(mesh(box(3.6, 0.18, 1.7), std(0x6b421f, 0.9), 0, 0.55, 0));
  for (const sx of [-1.3, 1.3]) {
    for (const sz of [-0.6, 0.6]) g.add(mesh(cyl(0.05, 0.05, 1.5, 6), wood, sx, 1.3, sz));
  }
  const canopy = mesh(box(3.0, 0.14, 1.6), std(0xa41623, 0.85), 0, 2.1, 0, true);
  g.add(canopy);
  g.add(mesh(sph(0.16, 10, 8), glow(0xffd98a, 1.2), 0, 1.75, 0));
  return g;
}

export function makeChakraWheel(r = 1.1): { group: THREE.Group; face: THREE.Group } {
  const group = new THREE.Group();
  const face = new THREE.Group();
  // stand
  group.add(mesh(box(0.3, 1.6, 0.3), std(0x3a2c18, 0.9), 0, 0.8, 0, true));
  face.position.y = 2.2;
  // outer ring
  const ring = new THREE.Mesh(new THREE.TorusGeometry(r, 0.12, 10, 28), glowStd(0x9a7d3a, 0x332200, 0.5, 0.4));
  ring.castShadow = true;
  face.add(ring);
  const disc = new THREE.Mesh(new THREE.CircleGeometry(r - 0.05, 28), std(0x312a5a, 0.7));
  face.add(disc);
  // 8 petals, gold at index 0 (angle = top)
  for (let k = 0; k < 8; k++) {
    const isGold = k === 0;
    const petal = new THREE.Mesh(
      new THREE.SphereGeometry(0.22, 8, 8),
      isGold ? glowStd(0xffd43b, 0x664400, 0.8) : std(k % 2 ? 0xff6b8b : 0xc77dff, 0.6)
    );
    petal.scale.set(0.7, 1.3, 0.4);
    const a = Math.PI / 2 - (k / 8) * Math.PI * 2; // k=0 at top
    petal.position.set(Math.cos(a) * r * 0.58, Math.sin(a) * r * 0.58, 0.08);
    face.add(petal);
  }
  const hub = new THREE.Mesh(sph(0.2, 10, 8), glowStd(0xf5b942, 0x664400, 0.6));
  hub.position.z = 0.1;
  face.add(hub);
  // flame marker above (static, on group)
  const marker = mesh(new THREE.ConeGeometry(0.14, 0.4, 8), glow(0xff9d2e, 1.2), 0, 2.2 + r + 0.45, 0.1);
  group.add(marker);
  group.add(face);
  return { group, face };
}

export function makeRangoliDisc(r = 8): THREE.Mesh {
  const m = new THREE.Mesh(
    new THREE.CircleGeometry(r, 48),
    new THREE.MeshBasicMaterial({ map: rangoliTexture(), transparent: true })
  );
  m.rotation.x = -Math.PI / 2;
  m.position.y = 0.03;
  return m;
}

export function makeGround(w: number, d: number, color = 0x1b1740): THREE.Mesh {
  const m = new THREE.Mesh(
    new THREE.PlaneGeometry(w, d),
    new THREE.MeshStandardMaterial({ color, roughness: 0.95, metalness: 0 })
  );
  m.rotation.x = -Math.PI / 2;
  m.receiveShadow = true;
  return m;
}

export function makeStreet(w: number, d: number): THREE.Mesh {
  const m = new THREE.Mesh(
    new THREE.PlaneGeometry(w, d),
    new THREE.MeshStandardMaterial({ color: 0x2e2560, roughness: 0.9, metalness: 0 })
  );
  m.rotation.x = -Math.PI / 2;
  m.position.y = 0.015;
  m.receiveShadow = true;
  return m;
}
