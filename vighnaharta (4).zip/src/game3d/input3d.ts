// ============================================================
// 3D input state — keyboard + virtual joystick + camera drag.
// Written by React (GameView3D), consumed by the 3D fixed loop.
// ============================================================

export interface Input3DState {
  keys: Set<string>;
  /** joystick -1..1 (x right, y up=forward) */
  joyX: number;
  joyY: number;
  jumpQueued: boolean;
  interactQueued: boolean;
  pauseQueued: boolean;
  /** accumulated camera-drag pixels, consumed each frame */
  camDX: number;
  camDY: number;
  /** canvas tap in NDC for tap-to-interact raycast */
  tapNDC: { x: number; y: number } | null;
}

export function createInput3D(): Input3DState {
  return {
    keys: new Set<string>(),
    joyX: 0,
    joyY: 0,
    jumpQueued: false,
    interactQueued: false,
    pauseQueued: false,
    camDX: 0,
    camDY: 0,
    tapNDC: null,
  };
}

/** camera-relative wish direction from keys + joystick, length clamped to 1 */
export function wishDir(input: Input3DState): { x: number; z: number } {
  const k = input.keys;
  let x = input.joyX;
  let z = input.joyY;
  if (k.has("KeyA") || k.has("ArrowLeft")) x -= 1;
  if (k.has("KeyD") || k.has("ArrowRight")) x += 1;
  if (k.has("KeyW") || k.has("ArrowUp")) z += 1;
  if (k.has("KeyS") || k.has("ArrowDown")) z -= 1;
  const len = Math.hypot(x, z);
  if (len > 1) {
    x /= len;
    z /= len;
  }
  return { x, z };
}

export function consumeJump(input: Input3DState): boolean {
  if (!input.jumpQueued) return false;
  input.jumpQueued = false;
  return true;
}

export function consumeInteract(input: Input3DState): boolean {
  if (!input.interactQueued) return false;
  input.interactQueued = false;
  return true;
}

export function consumeTap(input: Input3DState): { x: number; y: number } | null {
  const t = input.tapNDC;
  input.tapNDC = null;
  return t;
}
