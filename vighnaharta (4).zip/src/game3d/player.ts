// ============================================================
// Third-person character controller: acceleration-based move,
// coyote time + jump buffer, AABB/circle collision, platforms,
// step-up for stairs, carry-delta for moving boats.
// Tuned snappy: fast accel, grippy stops, generous forgiveness.
// ============================================================
import * as THREE from "three";

export interface AABB {
  minX: number; maxX: number; minZ: number; maxZ: number;
}

export interface Top {
  minX: number; maxX: number; minZ: number; maxZ: number; topY: number;
}

export interface CircleHit {
  x: number; z: number; r: number;
}

export interface MoveParams {
  accel: number;
  maxSpeed: number;
  /** velocity retention per second (lower = icier) */
  grip: number;
  jumpV: number;
  gravity: number;
  stepH: number;
  /** sprint multiplier base (captured at runtime, do not set) */
  baseSpeed?: number;
}

export const NORMAL_MOVE: MoveParams = {
  accel: 42, maxSpeed: 6.6, grip: 11, jumpV: 8.2, gravity: 24, stepH: 0.55,
};

export const SLIPPERY_MOVE: MoveParams = {
  accel: 22, maxSpeed: 6.4, grip: 3.0, jumpV: 8.0, gravity: 24, stepH: 0.55,
};

export interface PlayerEvents {
  jumped: boolean;
  landed: boolean;
  fallSpeed: number;
}

export class PlayerController {
  pos = new THREE.Vector3();
  vel = new THREE.Vector3();
  grounded = true;
  faceYaw = 0;
  params: MoveParams = { ...NORMAL_MOVE };

  radius = 0.45;
  private coyote = 0;
  private buffer = 0;
  private jumpCutDone = true;

  reset(x: number, y: number, z: number, yaw = 0): void {
    this.pos.set(x, y, z);
    this.vel.set(0, 0, 0);
    this.grounded = true;
    this.faceYaw = yaw;
    this.coyote = 0;
    this.buffer = 0;
  }

  queueJump(): void {
    this.buffer = 0.2;
  }

  /** external push (moving platforms, knockback) */
  push(dx: number, dz: number): void {
    this.pos.x += dx;
    this.pos.z += dz;
  }

  update(
    dt: number,
    wishX: number,
    wishZ: number,
    jumpHeld: boolean,
    groundY: (x: number, z: number) => number,
    colliders: { bounds: AABB; solids: AABB[]; circles: CircleHit[]; tops: Top[] }
  ): PlayerEvents {
    const ev: PlayerEvents = { jumped: false, landed: false, fallSpeed: 0 };
    const P = this.params;

    // --- horizontal accel toward wish (accel/decel, no snapping) ---
    const wishLen = Math.hypot(wishX, wishZ);
    const tx = wishLen > 0.01 ? (wishX / Math.max(1, wishLen)) * P.maxSpeed * Math.min(1, wishLen) : 0;
    const tz = wishLen > 0.01 ? (wishZ / Math.max(1, wishLen)) * P.maxSpeed * Math.min(1, wishLen) : 0;
    const rate = wishLen > 0.01 ? P.accel / P.maxSpeed : P.grip;
    const k = Math.min(1, rate * dt);
    this.vel.x += (tx - this.vel.x) * k;
    this.vel.z += (tz - this.vel.z) * k;

    // --- facing (smooth turn toward motion) ---
    const sp = Math.hypot(this.vel.x, this.vel.z);
    if (sp > 0.8) {
      const target = Math.atan2(this.vel.x, this.vel.z);
      let d = target - this.faceYaw;
      while (d > Math.PI) d -= Math.PI * 2;
      while (d < -Math.PI) d += Math.PI * 2;
      this.faceYaw += d * Math.min(1, dt * 11);
    }

    // --- jumping ---
    if (this.buffer > 0) this.buffer -= dt;
    if (this.grounded) {
      this.coyote = 0.15;
      this.jumpCutDone = false;
    } else if (this.coyote > 0) {
      this.coyote -= dt;
    }
    if (this.buffer > 0 && (this.grounded || this.coyote > 0)) {
      this.vel.y = P.jumpV;
      this.grounded = false;
      this.coyote = 0;
      this.buffer = 0;
      ev.jumped = true;
    }
    // variable height: release early = shorter hop
    if (!jumpHeld && !this.jumpCutDone && !this.grounded && this.vel.y > 3) {
      this.vel.y *= 0.55;
      this.jumpCutDone = true;
    }

    // --- gravity + integrate ---
    this.vel.y -= P.gravity * dt;
    if (this.vel.y < -22) this.vel.y = -22;
    const prevY = this.pos.y;
    this.pos.x += this.vel.x * dt;
    this.pos.z += this.vel.z * dt;
    this.pos.y += this.vel.y * dt;

    // --- arena bounds ---
    const b = colliders.bounds;
    this.pos.x = Math.max(b.minX + this.radius, Math.min(b.maxX - this.radius, this.pos.x));
    this.pos.z = Math.max(b.minZ + this.radius, Math.min(b.maxZ - this.radius, this.pos.z));

    // --- solid AABBs (push-out, min axis) with step-up ---
    for (const s of colliders.solids) {
      const cx = Math.max(s.minX, Math.min(s.maxX, this.pos.x));
      const cz = Math.max(s.minZ, Math.min(s.maxZ, this.pos.z));
      const dx = this.pos.x - cx;
      const dz = this.pos.z - cz;
      const d2 = dx * dx + dz * dz;
      if (d2 >= this.radius * this.radius) continue;
      // step-up: if the ground just beyond is walkable, climb instead
      const aheadGy = groundY(cx, cz);
      if (aheadGy - this.pos.y <= P.stepH && aheadGy >= this.pos.y - 0.5) continue;
      const d = Math.sqrt(d2) || 0.0001;
      const push = this.radius - d;
      if (d < 0.0002) {
        // center inside: push along smallest penetration axis
        const px = Math.min(this.pos.x - s.minX, s.maxX - this.pos.x);
        const pz = Math.min(this.pos.z - s.minZ, s.maxZ - this.pos.z);
        if (px < pz) this.pos.x += this.pos.x - s.minX < s.maxX - this.pos.x ? -(px + this.radius) : px + this.radius;
        else this.pos.z += this.pos.z - s.minZ < s.maxZ - this.pos.z ? -(pz + this.radius) : pz + this.radius;
      } else {
        this.pos.x += (dx / d) * push;
        this.pos.z += (dz / d) * push;
      }
    }

    // --- circle blockers ---
    for (const c of colliders.circles) {
      const dx = this.pos.x - c.x;
      const dz = this.pos.z - c.z;
      const rr = c.r + this.radius;
      const d2 = dx * dx + dz * dz;
      if (d2 >= rr * rr || d2 < 1e-8) continue;
      const d = Math.sqrt(d2);
      this.pos.x = c.x + (dx / d) * rr;
      this.pos.z = c.z + (dz / d) * rr;
    }

    // --- ground: base height + platform tops (one-way) ---
    let gy = groundY(this.pos.x, this.pos.z);
    for (const t of colliders.tops) {
      if (this.pos.x > t.minX && this.pos.x < t.maxX && this.pos.z > t.minZ && this.pos.z < t.maxZ) {
        if (prevY >= t.topY - 0.35 && this.pos.y <= t.topY + 0.6) {
          gy = Math.max(gy, t.topY);
        } else if (this.pos.y > t.topY) {
          gy = Math.max(gy, t.topY);
        }
      }
    }
    if (this.pos.y <= gy) {
      if (!this.grounded && this.vel.y < -6) {
        ev.landed = true;
        ev.fallSpeed = -this.vel.y;
      }
      this.pos.y = gy;
      this.vel.y = 0;
      this.grounded = true;
    } else if (this.pos.y > gy + 0.02) {
      this.grounded = false;
    }

    return ev;
  }

  speed2D(): number {
    return Math.hypot(this.vel.x, this.vel.z);
  }
}
