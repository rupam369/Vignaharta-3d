// ============================================================
// LevelBase — shared 3D gameplay framework for all 5 levels.
// Loop: input → player → movers → collect → interact → camera
// → particles → render. Scoring/combo/hearts/checkpoints/win.
// Subclasses implement onBuild() + hookUpdate() + progress01().
// ============================================================
import * as THREE from "three";
import { audio } from "../game/audio";
import type { MusicMode } from "../game/audio";
import { Core3D } from "./core";
import { FollowCamera } from "./camera3d";
import { Mushak } from "./mushak";
import type { MushakAnim } from "./mushak";
import { PlayerController, NORMAL_MOVE } from "./player";
import type { AABB, CircleHit, Top } from "./player";
import { PointPool, RainSystem, MoteField } from "./particles3d";
import type { Mote } from "./particles3d";
import { Floaters } from "./floaters";
import { consumeInteract, consumeJump, consumeTap, wishDir } from "./input3d";
import type { Input3DState } from "./input3d";
import {
  BuntingField, DiyaField, PuffField,
  makeBeam, makeDiyaSingle, makeFlower3D, makeModak, makeToken,
} from "./art";
import type { EndPayload, EngineCallbacks } from "../game/engine";
import type { HudState, Settings } from "../game/types";

export type CollectKind = "modak" | "flower" | "token" | "diya" | "fragment" | "offering";

export interface Collectible {
  kind: CollectKind;
  group: THREE.Group;
  x: number; y: number; z: number;
  taken: boolean;
  phase: number;
  value: number;
  collectR: number;
  beam: THREE.Object3D | null;
  tag?: string;
}

export interface Mover {
  group: THREE.Group;
  way: { x: number; z: number }[];
  speed: number;
  seg: number;
  dir: 1 | -1;
  x: number; z: number;
  r: number;
  damage: boolean;
  topY: number | null;
  prevX: number; prevZ: number;
  bobPhase: number;
}

export interface Interactable {
  id: string;
  group: THREE.Group;
  x: number; z: number;
  r: number;
  prompt: string;
  enabled: boolean;
  onTrigger: () => void;
}

export interface LevelOpts {
  canvas: HTMLCanvasElement;
  overlay: HTMLElement;
  input: Input3DState;
  settings: Settings;
  daily?: { goalModaks: number; timeLimit: number } | null;
}

const VALUES: Record<CollectKind, number> = {
  modak: 100, flower: 25, token: 250, diya: 150, fragment: 500, offering: 150,
};

export abstract class LevelBase {
  protected opts: LevelOpts;
  protected cb: EngineCallbacks;
  protected core: Core3D;
  protected camera3d = new FollowCamera();
  protected player = new PlayerController();
  protected mushak = new Mushak();
  protected floaters: Floaters;
  protected sparks: PointPool;
  protected petals: PointPool;
  protected motes: MoteField;
  protected rain: RainSystem | null = null;

  protected diyas = new DiyaField();
  protected puffs = new PuffField();
  protected buntings = new BuntingField();
  protected moteList: Mote[] = [];

  protected bounds: AABB = { minX: -45, maxX: 45, minZ: -45, maxZ: 45 };
  protected solids: AABB[] = [];
  protected circles: CircleHit[] = [];
  protected tops: Top[] = [];
  protected groundFn: (x: number, z: number) => number = () => 0;

  protected collectibles: Collectible[] = [];
  protected movers: Mover[] = [];
  protected interactables: Interactable[] = [];
  protected checkpoints: { x: number; z: number; r: number; taken: boolean; name: string; y?: number }[] = [];
  protected exit = { x: 0, z: 0, r: 2.5, unlocked: false };

  protected spawn = { x: 0, y: 0, z: 0, yaw: 0 };
  protected respawn = { x: 0, y: 0, z: 0 };
  protected objective = "";
  protected musicMode: MusicMode = "street";
  protected hasInteract = false;

  protected t = 0;
  protected state: "ready" | "playing" | "won" | "lost" | "cine" = "ready";
  protected stateT = 0;
  protected timeScale = 1;
  protected slowT = 0;
  protected sent = false;
  protected paused = false;
  protected destroyed = false;

  protected score = 0;
  protected combo = 0;
  protected comboProg = 0;
  protected mult = 1;
  protected maxMult = 1;
  protected modaks = 0;
  protected diyaCount = 0;
  protected fragments = 0;
  protected hearts = 3;
  protected damageTaken = 0;
  protected useAccuracyStars = false;
  protected correctActs = 0;
  protected totalActs = 0;
  protected invuln = 0;
  protected msg = "";
  protected msgKey = 0;
  protected timeLeft = 0;
  protected stepAcc = 0;
  protected lastTickSecond = -1;

  private raf = 0;
  private last = 0;
  private raycaster = new THREE.Raycaster();
  private fadedOut = false;

  constructor(opts: LevelOpts, cb: EngineCallbacks) {
    this.opts = opts;
    this.cb = cb;
    this.core = new Core3D(opts.canvas);
    this.core.setupNight(this.nightOpts());
    this.floaters = new Floaters(opts.overlay);
    this.sparks = new PointPool(this.core.scene, { max: 340, additive: true, gravity: -9 });
    this.petals = new PointPool(this.core.scene, { max: 260, additive: false, gravity: -1.2, drag: 0.99 });
    this.sparks.reducedMotion = opts.settings.reducedMotion;
    this.petals.reducedMotion = opts.settings.reducedMotion;
    this.motes = new MoteField(this.core.scene);
    this.player.params = { ...NORMAL_MOVE };
    this.core.scene.add(this.mushak.group);
    if (opts.daily) this.timeLeft = opts.daily.timeLimit;
    // start behind a black veil → cinematic fade-in on start()
    this.floaters.fade("out", 0);
  }

  /** override: fog / light tuning per level */
  protected nightOpts(): Record<string, number> {
    return {};
  }

  // ---------- build template (called by GameView3D) ----------
  protected abstract onBuild(): void;
  protected abstract hookUpdate(dt: number): void;
  protected abstract progress01(): number;

  buildScene(): void {
    this.onBuild();
    this.finishBuild();
  }

  protected finishBuild(): void {
    this.diyas.build(this.core.scene);
    this.puffs.build(this.core.scene);
    this.buntings.build(this.core.scene);
    for (const f of this.diyas.flames) {
      this.moteList.push({ x: f.x, y: f.y, z: f.z, size: 1.5, color: 0xffb45e });
    }
    this.motes.setPoints(this.moteList);
    this.player.reset(this.spawn.x, this.spawn.y, this.spawn.z, this.spawn.yaw);
    this.respawn = { x: this.spawn.x, y: this.spawn.y, z: this.spawn.z };
    this.camera3d.reset(this.spawn.yaw, this.player.pos);
    this.state = "ready";
    this.stateT = 1.0;
  }

  // ---------- lifecycle ----------
  start(): void {
    this.last = performance.now();
    window.addEventListener("resize", this.onResize);
    audio.ensure();
    audio.playMusic(this.musicMode);
    this.floaters.fade("in", 900);
    const loop = (now: number) => {
      if (this.destroyed) return;
      const raw = Math.min(0.05, (now - this.last) / 1000);
      this.last = now;
      if (!this.paused) {
        if (this.slowT > 0) {
          this.slowT -= raw;
          this.timeScale = 0.3;
          if (this.slowT <= 0) this.timeScale = 1;
        }
        this.update(raw * this.timeScale, raw);
      }
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }

  destroy(): void {
    this.destroyed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener("resize", this.onResize);
    audio.stopMusic();
    audio.stopAmbience();
    this.floaters.destroy();
    this.core.dispose();
  }

  setPaused(p: boolean): void {
    this.paused = p;
    this.last = performance.now();
    if (p) {
      audio.pauseAll(true);
      // clear held keys so the player doesn't run off on resume
      this.opts.input.keys.clear();
      this.opts.input.jumpQueued = false;
      this.opts.input.camDX = 0;
      this.opts.input.camDY = 0;
    } else {
      audio.pauseAll(false);
    }
  }

  protected onResize = (): void => {
    this.core.resize();
  };

  needsTouch(): { move: boolean; jump: boolean; slide: boolean; interact: boolean } {
    return { move: true, jump: true, slide: false, interact: this.hasInteract };
  }

  getHud(): HudState {
    return {
      score: Math.floor(this.score),
      combo: this.combo,
      comboMult: this.mult,
      distance: this.fragments,
      goalDistance: 3,
      modaks: this.modaks,
      diyas: this.diyaCount,
      hearts: Math.max(0, this.hearts),
      maxHearts: 3,
      progress: this.progress01(),
      timer: this.opts.daily ? this.timeLeft : undefined,
      message: this.msg,
      messageKey: this.msgKey,
      phase: this.objective,
      accuracy: this.totalActs > 0 ? this.correctActs / this.totalActs : 1,
      prompt: this.currentPrompt,
      interact: this.hasInteract,
    };
  }

  protected currentPrompt: string | null = null;

  // ---------- builder helpers ----------
  protected setBounds(minX: number, maxX: number, minZ: number, maxZ: number): void {
    this.bounds = { minX, maxX, minZ, maxZ };
  }
  protected setSpawn(x: number, y: number, z: number, yaw = 0): void {
    this.spawn = { x, y, z, yaw };
  }
  protected addSolid(minX: number, minZ: number, maxX: number, maxZ: number): void {
    this.solids.push({ minX, maxX, minZ, maxZ });
  }
  protected addCircle(x: number, z: number, r: number): void {
    this.circles.push({ x, z, r });
  }
  protected addTop(minX: number, minZ: number, maxX: number, maxZ: number, topY: number): void {
    this.tops.push({ minX, maxX, minZ, maxZ, topY });
  }
  protected setExit(x: number, z: number, r = 2.6): void {
    this.exit = { x, z, r, unlocked: false };
  }
  protected addCheckpoint(x: number, z: number, name: string, r = 2.6, y?: number): void {
    this.checkpoints.push({ x, z, r, taken: false, name, y });
  }

  protected addCollectible(
    kind: CollectKind, x: number, y: number, z: number,
    opts: { value?: number; tag?: string; beam?: boolean } = {}
  ): Collectible {
    let group: THREE.Group;
    if (kind === "modak" || kind === "fragment" || kind === "offering") group = makeModak(kind === "fragment" ? 1.5 : 1);
    else if (kind === "token") group = makeToken();
    else if (kind === "flower") group = makeFlower3D();
    else group = makeDiyaSingle(1.1);
    group.position.set(x, y, z);
    let beam: THREE.Object3D | null = null;
    if (opts.beam || kind === "fragment") {
      beam = makeBeam(kind === "fragment" ? 0xffd489 : 0xffc87a, kind === "fragment" ? 0.5 : 0.3, kind === "fragment" ? 12 : 7);
      beam.position.set(x, y, z);
      this.core.scene.add(beam);
    }
    this.core.scene.add(group);
    const c: Collectible = {
      kind, group, x, y, z, taken: false, phase: Math.random() * 6.28,
      value: opts.value ?? VALUES[kind],
      collectR: kind === "fragment" ? 1.5 : 1.1,
      beam, tag: opts.tag,
    };
    this.collectibles.push(c);
    return c;
  }

  protected addMover(
    group: THREE.Group, way: { x: number; z: number }[], speed: number,
    r = 1.2, damage = true, topY: number | null = null
  ): Mover {
    group.position.set(way[0].x, group.position.y, way[0].z);
    this.core.scene.add(group);
    const m: Mover = {
      group, way, speed, seg: 0, dir: 1, x: way[0].x, z: way[0].z,
      r, damage, topY, prevX: way[0].x, prevZ: way[0].z, bobPhase: Math.random() * 6,
    };
    this.movers.push(m);
    return m;
  }

  protected addInteractable(
    id: string, group: THREE.Group, x: number, z: number,
    prompt: string, onTrigger: () => void, r = 3.2
  ): Interactable {
    this.core.scene.add(group);
    const it: Interactable = { id, group, x, z, r, prompt, enabled: true, onTrigger };
    this.interactables.push(it);
    this.hasInteract = true;
    return it;
  }

  protected say(m: string): void {
    this.msg = m;
    this.msgKey++;
  }

  protected markAct(ok: boolean): void {
    this.totalActs++;
    if (ok) this.correctActs++;
  }

  // ---------- scoring ----------
  protected bumpCombo(): void {
    this.combo++;
    this.comboProg++;
    if (this.comboProg >= 8 && this.mult < 5) {
      this.comboProg = 0;
      this.mult++;
      this.maxMult = Math.max(this.maxMult, this.mult);
      audio.playCombo(this.mult);
      this.floaters.spawn(this.player.pos.x, this.player.pos.y + 2.6, this.player.pos.z, `COMBO x${this.mult}!`, "gold");
      this.sparks.burst(this.player.pos.x, this.player.pos.y + 1.4, this.player.pos.z, 16, [0xffd43b, 0xff7a1a], 3.4);
      if (this.mult >= 5) {
        audio.playComboFlourish();
        this.cb.onAchievement("combo_master");
      }
    }
  }

  protected collect(c: Collectible): void {
    c.taken = true;
    c.group.visible = false;
    if (c.beam) c.beam.visible = false;
    this.bumpCombo();
    this.markAct(true);
    const pts = c.value * this.mult;
    this.score += pts;
    const p = this.player.pos;
    if (c.kind === "modak" || c.kind === "offering") {
      this.modaks++;
      audio.playCollect(this.combo);
      this.floaters.spawn(p.x, p.y + 2.2, p.z, `+${pts}`, "");
      this.sparks.burst(c.x, c.y + 0.6, c.z, 12, [0xfff6e3, 0xf5b942, 0xffd43b], 3);
      this.cb.onAchievement("first_modak");
      this.onModak(c);
    } else if (c.kind === "flower") {
      audio.playFlower();
      this.floaters.spawn(p.x, p.y + 2.2, p.z, `+${pts}`, "petal");
      this.petals.petals(c.x, c.y + 0.8, c.z, 5, 1.5);
    } else if (c.kind === "token") {
      audio.playToken();
      this.floaters.spawn(p.x, p.y + 2.2, p.z, `+${pts}`, "gold");
      this.sparks.burst(c.x, c.y + 0.6, c.z, 16, [0xffd43b, 0xfff3c4], 3.6);
    } else if (c.kind === "diya") {
      this.diyaCount++;
      audio.playDiya();
      this.floaters.spawn(p.x, p.y + 2.2, p.z, `+${pts}`, "gold");
      this.sparks.burst(c.x, c.y + 0.6, c.z, 12, [0xffcf6e, 0xff9d2e], 3);
      this.onDiya(c);
    } else if (c.kind === "fragment") {
      this.fragments++;
      this.modaks++;
      audio.playFragment();
      this.floaters.spawn(p.x, p.y + 2.4, p.z, `FRAGMENT ${this.fragments}! +${pts}`, "gold big");
      this.sparks.burst(c.x, c.y + 1, c.z, 30, [0xffd43b, 0xfff3c4, 0xff7a1a], 4.5);
      this.petals.petals(c.x, c.y + 1.5, c.z, 14, 3);
      this.onFragment(c);
    }
  }

  /** level hooks for special pickups */
  protected onModak(_c: Collectible): void { /* override */ }
  protected onDiya(_c: Collectible): void { /* override */ }
  protected onFragment(_c: Collectible): void { /* override */ }

  // ---------- damage ----------
  damageFrom(x: number, z: number, knock = 9): void {
    if (this.invuln > 0 || this.state !== "playing") return;
    this.damage();
    const dx = this.player.pos.x - x;
    const dz = this.player.pos.z - z;
    const d = Math.hypot(dx, dz) || 1;
    this.player.vel.x = (dx / d) * knock;
    this.player.vel.z = (dz / d) * knock;
    this.player.vel.y = 4.5;
    this.player.grounded = false;
  }

  protected damage(): void {
    if (this.invuln > 0 || this.state !== "playing") return;
    this.hearts--;
    this.damageTaken++;
    this.combo = 0;
    this.comboProg = 0;
    this.mult = 1;
    this.invuln = 1.3;
    this.markAct(false);
    this.camera3d.addShake(0.7);
    this.floaters.hitFlash();
    this.mushak.hitFlash();
    this.sparks.burst(this.player.pos.x, this.player.pos.y + 1.2, this.player.pos.z, 14, [0xe63956, 0xffb3c1], 3.4);
    if (this.hearts <= 0) {
      audio.playGameOver();
      this.lose("Out of hearts…");
    } else {
      audio.playCollision();
      audio.playHeartLost();
      this.floaters.spawn(this.player.pos.x, this.player.pos.y + 2.4, this.player.pos.z, "OUCH!", "hurt");
    }
  }

  // ---------- win / lose ----------
  protected win(title: string, sub = ""): void {
    if (this.state !== "playing") return;
    this.state = "won";
    this.stateT = 2.0;
    this.slowT = 0.7;
    this.say(title);
    if (sub) this.floaters.bigTitle(title, sub);
    audio.playLevelComplete();
    this.sparks.burst(this.player.pos.x, this.player.pos.y + 2, this.player.pos.z, 40, [0xffd43b, 0xff6b8b, 0x7ec8ff], 5);
    this.petals.petals(this.player.pos.x, this.player.pos.y + 3, this.player.pos.z, 24, 6);
  }

  protected lose(reason: string): void {
    if (this.state !== "playing") return;
    this.state = "lost";
    this.stateT = 1.8;
    this.slowT = 0.6;
    this.say(reason);
  }

  protected finish(victory: boolean): void {
    const acc = this.totalActs > 0 ? this.correctActs / this.totalActs : 1;
    let stars = 0;
    if (victory) {
      stars = this.useAccuracyStars
        ? acc >= 0.9 ? 3 : acc >= 0.6 ? 2 : 1
        : this.hearts >= 3 ? 3 : this.hearts === 2 ? 2 : 1;
    } else if (this.progress01() > 0.5) stars = 1;
    if (victory && this.damageTaken === 0) this.cb.onAchievement("no_miss");
    const payload: EndPayload = {
      victory,
      score: Math.floor(this.score),
      modaks: this.modaks,
      diyas: this.diyaCount,
      distance: this.fragments,
      maxCombo: this.maxMult,
      accuracy: acc,
      heartsLeft: Math.max(0, this.hearts),
      damageTaken: this.damageTaken,
      stars,
    };
    this.cb.onEnd(payload);
  }

  // ============================================================
  // MAIN UPDATE
  // ============================================================
  private update(dt: number, _raw: number): void {
    this.t += dt;
    const input = this.opts.input;

    // ready beat
    if (this.state === "ready") {
      this.stateT -= dt;
      this.idleWorld(dt);
      if (this.stateT <= 0) {
        this.state = "playing";
        this.say(this.objective);
        audio.playCheckpoint();
      }
      this.renderFrame(dt);
      return;
    }

    // won / lost tail
    if (this.state === "won" || this.state === "lost") {
      this.stateT -= dt;
      this.winTail(dt);
      if (this.state === "won" && this.stateT < 0.6 && !this.fadedOut) {
        this.fadedOut = true;
        this.floaters.fade("out", 550);
      }
      if (this.stateT <= 0 && !this.sent) {
        this.sent = true;
        this.finish(this.state === "won");
      }
      this.renderFrame(dt);
      return;
    }

    // cine state (finale celebration drives its own logic)
    if (this.state === "cine") {
      this.hookUpdate(dt);
      this.renderFrame(dt);
      return;
    }

    // ---------------- playing ----------------
    // camera look
    this.camera3d.applyDrag(input.camDX, input.camDY);
    input.camDX = 0;
    input.camDY = 0;

    // movement wish (camera-relative)
    const w = wishDir(input);
    const yaw = this.camera3d.yaw;
    const fx = Math.sin(yaw);
    const fz = Math.cos(yaw);
    const wishX = -fz * w.x + fx * w.z;
    const wishZ = fx * w.x + fz * w.z;

    // sprint: Shift on desktop, full-tilt stick on touch
    const joyLen = Math.hypot(input.joyX, input.joyY);
    const sprint = input.keys.has("ShiftLeft") || input.keys.has("ShiftRight") || joyLen > 0.92;
    const P = this.player.params;
    if (P.baseSpeed === undefined) P.baseSpeed = P.maxSpeed;
    P.maxSpeed = P.baseSpeed * (sprint ? 1.45 : 1);

    if (consumeJump(input)) this.player.queueJump();
    const jumpHeld = input.keys.has("Space") || input.keys.has("ArrowUp") || input.keys.has("KeyW");

    const ev = this.player.update(dt, wishX, wishZ, jumpHeld, this.groundFn, {
      bounds: this.bounds, solids: this.solids, circles: this.circles, tops: this.tops,
    });
    if (ev.jumped) audio.playJump();
    if (ev.landed) {
      audio.playLand();
      const lp = this.player.pos;
      this.sparks.burst(lp.x, lp.y + 0.3, lp.z, 8, [0x9a8fb5, 0x6e6390], 2.2);
    }

    // footsteps matched to stride (+ sprint sparkle)
    const spd = this.player.speed2D();
    if (this.player.grounded && spd > 1.2) {
      this.stepAcc += spd * dt;
      if (this.stepAcc > 2.1) {
        this.stepAcc = 0;
        audio.playFootstep(spd > 4.6);
        if (sprint) {
          const fp = this.player.pos;
          this.sparks.burst(fp.x, fp.y + 0.3, fp.z, 2, [0xffd43b, 0xfff3c4], 1.6);
        }
      }
    } else {
      this.stepAcc = 1.2;
    }

    if (this.invuln > 0) this.invuln -= dt;

    this.updateMovers(dt);
    this.updateCollectibles(dt);
    this.updateInteract(input);
    this.updateCheckpoints();

    // daily timer
    if (this.opts.daily) {
      this.timeLeft -= dt;
      const whole = Math.ceil(this.timeLeft);
      if (whole <= 5 && whole > 0 && whole !== this.lastTickSecond) {
        this.lastTickSecond = whole;
        audio.playTick();
      }
      if (this.timeLeft <= 0) {
        this.timeLeft = 0;
        this.onTimeUp();
      }
    }

    this.hookUpdate(dt);

    // exit zone
    if (this.exit.unlocked) {
      const dx = this.player.pos.x - this.exit.x;
      const dz = this.player.pos.z - this.exit.z;
      if (Math.hypot(dx, dz) < this.exit.r) this.onEnterExit();
    }

    // camera + character visuals (sprint = subtle FOV kick)
    const wantKick = sprint && spd > 3 ? 8 : 0;
    this.camera3d.update(dt, this.core.camera, this.player.pos, this.player.faceYaw,
      spd > 1, this.groundFn, this.opts.settings.reducedMotion, wantKick);
    this.syncMushak(dt, spd);

    this.renderFrame(dt);
  }

  protected onTimeUp(): void {
    // override (daily)
    this.lose("Time's up!");
  }

  protected onEnterExit(): void {
    this.win("LEVEL COMPLETE!");
  }

  protected idleWorld(dt: number): void {
    // gentle world motion during the ready beat
    this.updateCollectibles(dt, true);
    this.camera3d.update(dt, this.core.camera, this.player.pos, this.player.faceYaw,
      false, this.groundFn, this.opts.settings.reducedMotion);
    this.syncMushak(dt, 0);
  }

  protected winTail(dt: number): void {
    // fireworks + happy mushak while results prepare
    if (this.state === "won") {
      if (Math.random() < dt * 2.2) {
        this.sparks.firework(
          this.player.pos.x + (Math.random() - 0.5) * 22,
          8 + Math.random() * 6,
          this.player.pos.z + (Math.random() - 0.5) * 22,
          [0xffd43b, 0xff6b8b, 0x7ec8ff, 0x2f9e6e][(Math.random() * 4) | 0]
        );
      }
      this.syncMushak(dt, 0, true);
    }
    this.updateCollectibles(dt, true);
    this.camera3d.update(dt, this.core.camera, this.player.pos, this.player.faceYaw,
      false, this.groundFn, this.opts.settings.reducedMotion);
  }

  protected syncMushak(dt: number, speed: number, celebrate = false): void {
    this.mushak.group.position.copy(this.player.pos);
    this.mushak.group.rotation.y = this.player.faceYaw;
    let anim: MushakAnim = "idle";
    if (celebrate || this.state === "won") anim = "celebrate";
    else if (!this.player.grounded) anim = "jump";
    else if (speed > 0.6) anim = "move";
    else if (this.invuln > 0.6) anim = "hit";
    this.mushak.update(dt, this.t, speed, this.player.grounded, anim);
    // invulnerability blink
    const g = this.mushak.group;
    if (this.invuln > 0 && this.state === "playing") {
      g.visible = Math.floor(this.t * 14) % 2 === 0;
    } else {
      g.visible = true;
    }
  }

  protected updateMovers(dt: number): void {
    for (const m of this.movers) {
      m.prevX = m.x;
      m.prevZ = m.z;
      const a = m.way[m.seg];
      const b = m.way[(m.seg + m.dir + m.way.length) % m.way.length];
      const dx = b.x - m.x;
      const dz = b.z - m.z;
      const d = Math.hypot(dx, dz);
      const step = m.speed * dt;
      if (d < Math.max(0.3, step)) {
        m.seg = (m.seg + m.dir + m.way.length) % m.way.length;
        if (m.way.length === 2) m.dir = (m.dir * -1) as 1 | -1;
      } else {
        m.x += (dx / d) * step;
        m.z += (dz / d) * step;
      }
      m.group.position.x = m.x;
      m.group.position.z = m.z;
      m.group.rotation.y = Math.atan2(dx, dz);
      if (m.topY !== null) {
        m.group.position.y = m.topY + Math.sin(this.t * 1.6 + m.bobPhase) * 0.12;
      }
      // carry the rider — land on boats from a jump, ride, hop off
      if (m.topY !== null && this.player.vel.y <= 0.5) {
        const px = this.player.pos.x - m.x;
        const pz = this.player.pos.z - m.z;
        const py = this.player.pos.y;
        if (Math.hypot(px, pz) < m.r + 0.4 && py <= m.topY + 1.1 && py >= m.topY - 0.6) {
          this.player.push(m.x - m.prevX, m.z - m.prevZ);
          this.player.pos.y = m.topY;
          this.player.vel.y = 0;
          this.player.grounded = true;
        }
      }
      // damage touch
      if (m.damage && this.state === "playing") {
        const ddx = this.player.pos.x - m.x;
        const ddz = this.player.pos.z - m.z;
        if (Math.hypot(ddx, ddz) < m.r + 0.45) this.damageFrom(m.x, m.z);
      }
    }
  }

  protected updateCollectibles(dt: number, ambientOnly = false): void {
    for (const c of this.collectibles) {
      if (c.taken) continue;
      c.group.rotation.y += dt * (c.kind === "token" ? 2.6 : 1.2);
      c.group.position.y = c.y + Math.sin(this.t * 2.2 + c.phase) * 0.12;
      if (c.beam) c.beam.rotation.y += dt * 0.5;
      if (ambientOnly || this.state !== "playing") continue;
      const dx = this.player.pos.x - c.x;
      const dz = this.player.pos.z - c.z;
      const dy = this.player.pos.y + 0.9 - c.y;
      if (Math.hypot(dx, dz) < c.collectR && Math.abs(dy) < 1.8) this.collect(c);
    }
  }

  protected updateInteract(input: Input3DState): void {
    // nearest available
    let best: Interactable | null = null;
    let bestD = 1e9;
    for (const it of this.interactables) {
      if (!it.enabled) continue;
      const d = Math.hypot(this.player.pos.x - it.x, this.player.pos.z - it.z);
      if (d < it.r && d < bestD) {
        bestD = d;
        best = it;
      }
    }
    const coarse = this.isTouch();
    this.currentPrompt = best ? `${coarse ? "USE — " : "E — "}${best.prompt}` : null;
    this.floaters.setPrompt(this.currentPrompt);

    if (consumeInteract(input) && best) {
      best.onTrigger();
      return;
    }
    // tap-to-interact raycast
    const tap = consumeTap(input);
    if (tap && this.state === "playing") {
      const ndc = new THREE.Vector2(tap.x, tap.y);
      this.raycaster.setFromCamera(ndc, this.core.camera);
      const targets = this.interactables.filter((i) => i.enabled).map((i) => i.group);
      const hits = this.raycaster.intersectObjects(targets, true);
      if (hits.length > 0) {
        let obj: THREE.Object3D | null = hits[0].object;
        while (obj) {
          const found = this.interactables.find((i) => i.enabled && i.group === obj);
          if (found) {
            const d = Math.hypot(this.player.pos.x - found.x, this.player.pos.z - found.z);
            if (d < found.r + 3.5) {
              found.onTrigger();
            } else {
              this.say("Go closer…");
              audio.playHover();
            }
            break;
          }
          obj = obj.parent;
        }
      }
    }
  }

  protected updateCheckpoints(): void {
    for (const c of this.checkpoints) {
      if (c.taken) continue;
      if (Math.hypot(this.player.pos.x - c.x, this.player.pos.z - c.z) < c.r) {
        c.taken = true;
        this.respawn = { x: c.x, y: c.y ?? this.groundFn(c.x, c.z), z: c.z };
        this.say(`${c.name} — checkpoint!`);
        audio.playCheckpoint();
        this.score += 150 * this.mult;
        this.sparks.burst(c.x, 2, c.z, 18, [0x7ec8ff, 0xfff3c4], 3.4);
      }
    }
  }

  protected renderFrame(dt: number): void {
    this.sparks.update(dt, this.t);
    this.petals.update(dt, this.t);
    this.motes.update(this.t);
    if (this.rain) this.rain.update(dt, this.player.pos.x, this.player.pos.z);
    const w = this.opts.canvas.clientWidth || window.innerWidth;
    const h = this.opts.canvas.clientHeight || window.innerHeight;
    this.floaters.update(dt, this.core.camera, w, h);
    this.core.followShadow(this.player.pos);
    this.core.render();
  }

  protected isTouch(): boolean {
    try {
      return !!window.matchMedia && window.matchMedia("(pointer: coarse)").matches;
    } catch {
      return false;
    }
  }
}
