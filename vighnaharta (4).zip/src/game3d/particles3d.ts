// ============================================================
// 3D particles — pooled CPU-sim point clouds with one tiny
// custom shader (per-point size + alpha fade + vertex color).
// Systems: sparks (additive), petals (soft), fireworks, rain.
// ============================================================
import * as THREE from "three";

const VERT = /* glsl */ `
attribute float aSize;
attribute float aAlpha;
varying float vAlpha;
varying vec3 vColor;
uniform float uPixelRatio;
void main() {
  vColor = color;
  vAlpha = aAlpha;
  vec4 mv = modelViewMatrix * vec4(position, 1.0);
  gl_PointSize = aSize * uPixelRatio * (240.0 / -mv.z);
  gl_Position = projectionMatrix * mv;
}
`;

const FRAG = /* glsl */ `
varying float vAlpha;
varying vec3 vColor;
void main() {
  vec2 uv = gl_PointCoord - vec2(0.5);
  float d = length(uv);
  if (d > 0.5) discard;
  float soft = smoothstep(0.5, 0.08, d);
  gl_FragColor = vec4(vColor, vAlpha * soft);
}
`;

interface P {
  alive: boolean;
  x: number; y: number; z: number;
  vx: number; vy: number; vz: number;
  life: number; maxLife: number;
  size: number;
  r: number; g: number; b: number;
  gravity: number;
  drag: number;
  flutter: number;
  phase: number;
}

export interface PoolOpts {
  max?: number;
  additive?: boolean;
  gravity?: number;
  drag?: number;
  depthWrite?: boolean;
}

/** generic pooled point cloud */
export class PointPool {
  points: THREE.Points;
  private geo: THREE.BufferGeometry;
  private pos: Float32Array;
  private col: Float32Array;
  private sizeAttr: Float32Array;
  private alphaAttr: Float32Array;
  private pool: P[] = [];
  private mat: THREE.ShaderMaterial;
  private baseGravity: number;
  private baseDrag: number;
  reducedMotion = false;

  constructor(scene: THREE.Scene, opts: PoolOpts = {}) {
    const max = opts.max ?? 320;
    this.baseGravity = opts.gravity ?? 0;
    this.baseDrag = opts.drag ?? 1;
    for (let i = 0; i < max; i++) {
      this.pool.push({
        alive: false, x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0,
        life: 0, maxLife: 1, size: 1, r: 1, g: 1, b: 1,
        gravity: 0, drag: 1, flutter: 0, phase: Math.random() * 6.28,
      });
    }
    this.geo = new THREE.BufferGeometry();
    this.pos = new Float32Array(max * 3);
    this.col = new Float32Array(max * 3);
    this.sizeAttr = new Float32Array(max);
    this.alphaAttr = new Float32Array(max);
    this.geo.setAttribute("position", new THREE.BufferAttribute(this.pos, 3));
    this.geo.setAttribute("color", new THREE.BufferAttribute(this.col, 3));
    this.geo.setAttribute("aSize", new THREE.BufferAttribute(this.sizeAttr, 1));
    this.geo.setAttribute("aAlpha", new THREE.BufferAttribute(this.alphaAttr, 1));
    this.mat = new THREE.ShaderMaterial({
      vertexShader: VERT,
      fragmentShader: FRAG,
      uniforms: { uPixelRatio: { value: Math.min(window.devicePixelRatio || 1, 2) } },
      transparent: true,
      depthWrite: opts.depthWrite ?? false,
      blending: opts.additive === false ? THREE.NormalBlending : THREE.AdditiveBlending,
      vertexColors: true,
    });
    this.points = new THREE.Points(this.geo, this.mat);
    this.points.frustumCulled = false;
    this.points.renderOrder = 5;
    scene.add(this.points);
  }

  private next(): P | null {
    for (const p of this.pool) if (!p.alive) return p;
    return null;
  }

  spawn(
    x: number, y: number, z: number,
    vx: number, vy: number, vz: number,
    life: number, size: number,
    color: THREE.Color | { r: number; g: number; b: number },
    opts: { gravity?: number; drag?: number; flutter?: number } = {}
  ): void {
    const p = this.next();
    if (!p) return;
    p.alive = true;
    p.x = x; p.y = y; p.z = z;
    p.vx = vx; p.vy = vy; p.vz = vz;
    p.life = life; p.maxLife = life;
    p.size = size;
    p.r = color.r; p.g = color.g; p.b = color.b;
    p.gravity = opts.gravity ?? this.baseGravity;
    p.drag = opts.drag ?? this.baseDrag;
    p.flutter = opts.flutter ?? 0;
  }

  burst(
    x: number, y: number, z: number,
    count: number, colors: number[], speed: number,
    life = 0.8, size = 1.6, up = 2.2
  ): void {
    const n = this.reducedMotion ? Math.ceil(count / 3) : count;
    const c = new THREE.Color();
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = speed * (0.3 + Math.random() * 0.9);
      c.setHex(colors[(Math.random() * colors.length) | 0]);
      this.spawn(x, y, z,
        Math.cos(a) * s, Math.random() * up + speed * 0.25, Math.sin(a) * s,
        life * (0.6 + Math.random() * 0.7), size * (0.6 + Math.random() * 0.8), c);
    }
  }

  petals(x: number, y: number, z: number, count: number, spread = 3): void {
    const cols = [0xff6b8b, 0xffa94d, 0xffd43b, 0xff8787, 0xc77dff];
    const c = new THREE.Color();
    const n = this.reducedMotion ? Math.ceil(count / 2) : count;
    for (let i = 0; i < n; i++) {
      c.setHex(cols[(Math.random() * cols.length) | 0]);
      this.spawn(
        x + (Math.random() - 0.5) * spread, y + Math.random() * 2, z + (Math.random() - 0.5) * spread,
        (Math.random() - 0.5) * 1.4, -0.8 - Math.random() * 1.2, (Math.random() - 0.5) * 1.4,
        2.6 + Math.random() * 1.6, 1.1 + Math.random() * 0.9, c,
        { gravity: -0.35, flutter: 2.4 }
      );
    }
  }

  firework(x: number, y: number, z: number, color: number): void {
    const c = new THREE.Color(color);
    const white = new THREE.Color(0xffffff);
    const n = this.reducedMotion ? 16 : 46;
    for (let i = 0; i < n; i++) {
      const th = Math.random() * Math.PI * 2;
      const ph = Math.acos(2 * Math.random() - 1);
      const s = 7 + Math.random() * 9;
      this.spawn(x, y, z,
        Math.sin(ph) * Math.cos(th) * s, Math.cos(ph) * s, Math.sin(ph) * Math.sin(th) * s,
        1.1 + Math.random() * 0.7, 1.7, i % 5 === 0 ? white : c,
        { gravity: -5.5, drag: 0.985 });
    }
  }

  update(dt: number, t: number): void {
    const pos = this.geo.getAttribute("position") as THREE.BufferAttribute;
    const col = this.geo.getAttribute("color") as THREE.BufferAttribute;
    const siz = this.geo.getAttribute("aSize") as THREE.BufferAttribute;
    const alp = this.geo.getAttribute("aAlpha") as THREE.BufferAttribute;
    for (let i = 0; i < this.pool.length; i++) {
      const p = this.pool[i];
      if (!p.alive) {
        alp.setX(i, 0);
        continue;
      }
      p.life -= dt;
      if (p.life <= 0) {
        p.alive = false;
        alp.setX(i, 0);
        continue;
      }
      p.vy += p.gravity * dt;
      const d = Math.pow(p.drag, dt * 60);
      p.vx *= d; p.vy *= d; p.vz *= d;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.z += p.vz * dt;
      if (p.flutter > 0) p.x += Math.sin(t * 3 + p.phase) * p.flutter * dt;
      const f = p.life / p.maxLife;
      pos.setXYZ(i, p.x, p.y, p.z);
      col.setXYZ(i, p.r, p.g, p.b);
      siz.setX(i, p.size);
      alp.setX(i, Math.min(1, f * 2.2));
    }
    pos.needsUpdate = true;
    col.needsUpdate = true;
    siz.needsUpdate = true;
    alp.needsUpdate = true;
  }
}

// ---------------- rain ----------------
export class RainSystem {
  points: THREE.Points;
  private geo: THREE.BufferGeometry;
  private pos: Float32Array;
  private count: number;
  private area = 46;
  private speed = 26;

  constructor(scene: THREE.Scene, count = 700) {
    this.count = count;
    this.geo = new THREE.BufferGeometry();
    this.pos = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      this.pos[i * 3] = (Math.random() - 0.5) * this.area;
      this.pos[i * 3 + 1] = Math.random() * 24;
      this.pos[i * 3 + 2] = (Math.random() - 0.5) * this.area;
    }
    this.geo.setAttribute("position", new THREE.BufferAttribute(this.pos, 3));
    const mat = new THREE.PointsMaterial({
      color: 0x9fd4ff, size: 0.09, transparent: true, opacity: 0.55,
      depthWrite: false, sizeAttenuation: true,
    });
    this.points = new THREE.Points(this.geo, mat);
    this.points.frustumCulled = false;
    this.points.renderOrder = 6;
    scene.add(this.points);
  }

  update(dt: number, cx: number, cz: number): void {
    const dy = this.speed * dt;
    const half = this.area / 2;
    for (let i = 0; i < this.count; i++) {
      let y = this.pos[i * 3 + 1] - dy;
      if (y < 0) y += 24;
      this.pos[i * 3 + 1] = y;
      // keep the volume glued around the camera focus
      this.pos[i * 3] += (cx - this.clampC(this.pos[i * 3], cx, half)) * 0;
    }
    // recenter volume (cheap drift toward focus)
    this.points.position.x = cx;
    this.points.position.z = cz;
    (this.geo.getAttribute("position") as THREE.BufferAttribute).needsUpdate = true;
  }

  private clampC(_v: number, _c: number, _half: number): number {
    return 0;
  }
}

// ---------------- flickering glow motes (diya flames, fireflies) ----------------
const MOTE_VERT = /* glsl */ `
attribute float aSize;
attribute float aPhase;
attribute float aSpeed;
varying vec3 vColor;
varying float vTw;
uniform float uTime;
uniform float uPixelRatio;
void main() {
  vColor = color;
  float tw = 0.72 + 0.28 * sin(uTime * aSpeed + aPhase);
  vTw = tw;
  vec4 mv = modelViewMatrix * vec4(position, 1.0);
  gl_PointSize = aSize * tw * uPixelRatio * (240.0 / -mv.z);
  gl_Position = projectionMatrix * mv;
}
`;
const MOTE_FRAG = /* glsl */ `
varying vec3 vColor;
varying float vTw;
void main() {
  vec2 uv = gl_PointCoord - vec2(0.5);
  float d = length(uv);
  if (d > 0.5) discard;
  float core = smoothstep(0.5, 0.0, d);
  core *= core;
  gl_FragColor = vec4(vColor * (0.8 + 0.6 * vTw), core * 0.95);
}
`;

export interface Mote {
  x: number; y: number; z: number;
  size: number;
  color: number;
  phase?: number;
  speed?: number;
}

export class MoteField {
  points: THREE.Points | null = null;
  private mat: THREE.ShaderMaterial;
  private scene: THREE.Scene;

  constructor(scene: THREE.Scene) {
    this.scene = scene;
    this.mat = new THREE.ShaderMaterial({
      vertexShader: MOTE_VERT,
      fragmentShader: MOTE_FRAG,
      uniforms: {
        uTime: { value: 0 },
        uPixelRatio: { value: Math.min(window.devicePixelRatio || 1, 2) },
      },
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      vertexColors: true,
    });
  }

  setPoints(motes: Mote[]): void {
    if (this.points) {
      this.scene.remove(this.points);
      this.points.geometry.dispose();
      this.points = null;
    }
    if (motes.length === 0) return;
    const geo = new THREE.BufferGeometry();
    const pos = new Float32Array(motes.length * 3);
    const col = new Float32Array(motes.length * 3);
    const size = new Float32Array(motes.length);
    const phase = new Float32Array(motes.length);
    const speed = new Float32Array(motes.length);
    const c = new THREE.Color();
    for (let i = 0; i < motes.length; i++) {
      const m = motes[i];
      pos[i * 3] = m.x; pos[i * 3 + 1] = m.y; pos[i * 3 + 2] = m.z;
      c.setHex(m.color);
      col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b;
      size[i] = m.size;
      phase[i] = m.phase ?? Math.random() * 6.28;
      speed[i] = m.speed ?? (8 + Math.random() * 4);
    }
    geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    geo.setAttribute("color", new THREE.BufferAttribute(col, 3));
    geo.setAttribute("aSize", new THREE.BufferAttribute(size, 1));
    geo.setAttribute("aPhase", new THREE.BufferAttribute(phase, 1));
    geo.setAttribute("aSpeed", new THREE.BufferAttribute(speed, 1));
    this.points = new THREE.Points(geo, this.mat);
    this.points.frustumCulled = false;
    this.points.renderOrder = 4;
    this.scene.add(this.points);
  }

  update(t: number): void {
    (this.mat.uniforms.uTime as { value: number }).value = t;
  }
}
