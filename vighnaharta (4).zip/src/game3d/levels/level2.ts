// ============================================================
// LEVEL 2 — RANGOLI COURTYARD (3D)
// Walk the glowing rangoli, light the 6 flame pillars in order.
// Stand by the marked flame and press E (or tap it) — time it
// when the ring turns GOLD for Perfect.
// ============================================================
import * as THREE from "three";
import { audio } from "../../game/audio";
import type { MusicMode } from "../../game/audio";
import { LevelBase } from "../levelbase";
import {
  glowSprite, makeArchGate, makeBuilding, makeGround, makeLampPost,
  makePillar, makeRangoliDisc, makeTempleFacade, makeTree, numeralTexture, std,
} from "../art";

interface Pillar {
  i: number;
  x: number; z: number;
  group: THREE.Group;
  beam: THREE.Mesh;
  flame: THREE.Sprite;
  lit: boolean;
  perfect: boolean;
}

export class Level2Rangoli extends LevelBase {
  protected musicMode: MusicMode = "rangoli";
  protected useAccuracyStars = true;

  private order = [0, 2, 4, 1, 5, 3];
  private pillars: Pillar[] = [];
  private step = 0;
  private ringT = 0;
  private window = 3.2;
  private fails = 0;
  private done = false;
  private ring!: THREE.Mesh;
  private marker!: THREE.Sprite;
  private shock: THREE.Mesh | null = null;
  private shockT = -1;
  private barrierMat: THREE.MeshBasicMaterial | null = null;

  protected nightOpts(): Record<string, number> {
    return { fogNear: 30, fogFar: 120 };
  }

  protected onBuild(): void {
    const S = this.core.scene;
    this.setBounds(-25, 25, -25, 25);
    this.setSpawn(0, 0, 20, Math.PI);
    this.objective = "Go to golden-marked flame 1, press E!";
    this.ringT = this.window;

    S.add(makeGround(120, 120, 0x1a1440));

    // boundary walls
    const wallM = std(0x2a2350, 0.95);
    const wall = (w: number, d: number, x: number, z: number) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, 3, d), wallM);
      m.position.set(x, 1.5, z);
      S.add(m);
    };
    wall(54, 2, 0, -27);
    wall(54, 2, 0, 27);
    wall(2, 54, -27, 0);
    wall(2, 54, 27, 0);

    // temple backdrop (north)
    const temple = makeTempleFacade(14, 8);
    temple.position.set(0, 0, -32);
    S.add(temple);
    this.core.addDiyaLight(0, 4, -26, 0xffc87a, 20, 22);

    // pillar colonnades (east/west)
    for (const z of [-14, -7, 0, 7, 14]) {
      for (const x of [-19, 19]) {
        const p = makePillar(5);
        p.position.set(x, 0, z);
        S.add(p);
        this.addCircle(x, z, 0.7);
      }
    }

    // trees + lamps at corners
    for (const [x, z] of [[-22, -22], [22, -22], [-22, 22], [22, 22]] as const) {
      const t = makeTree(1.1);
      t.position.set(x, 0, z);
      S.add(t);
      this.addCircle(x, z, 0.7);
      const l = makeLampPost(3.6);
      l.position.set(x * 0.78, 0, z * 0.78);
      S.add(l);
    }
    this.core.addDiyaLight(0, 5, 0, 0xffb45e, 26, 24);

    // buildings silhouettes outside
    for (const [x, z] of [[-36, 0], [36, 0], [0, -40], [-20, 36], [20, 36]] as const) {
      const b = makeBuilding(12, 10, 10);
      b.position.set(x, 0, z);
      S.add(b);
    }

    // bunting + diyas
    for (let i = 0; i < 5; i++) {
      const z = -16 + i * 8;
      this.buntings.span(-19, 6.4, z, 19, 6.4, z, 1.6, 12);
    }
    for (let i = 0; i < 16; i++) {
      const a = (i / 16) * Math.PI * 2;
      this.diyas.add(Math.cos(a) * 10.5, 0.02, Math.sin(a) * 10.5, 1);
    }
    for (let i = 0; i < 8; i++) {
      this.diyas.add(-14 + i * 4, 0.02, -22, 0.9);
      this.diyas.add(-14 + i * 4, 0.02, 22, 0.9);
    }

    // THE rangoli
    const disc = makeRangoliDisc(8);
    S.add(disc);
    const small = makeRangoliDisc(2.4);
    small.position.set(-15, 0.03, 14);
    S.add(small);

    // 6 flame pillars around the rangoli
    const R = 5.6;
    for (let i = 0; i < 6; i++) {
      const a = -Math.PI / 2 + (i / 6) * Math.PI * 2;
      const x = Math.cos(a) * R;
      const z = Math.sin(a) * R;
      const g = new THREE.Group();
      // pedestal
      const ped = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.65, 0.9, 12), std(0x3d3464, 0.85));
      ped.position.y = 0.45;
      ped.castShadow = true;
      g.add(ped);
      // diya bowl + flame sprite
      const bowl = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.24, 0.24, 12), std(0x8a4b1f, 0.85));
      bowl.position.y = 1.0;
      g.add(bowl);
      const flame = glowSprite(0xff9d5e, 1.6, 0.55);
      flame.position.y = 1.55;
      g.add(flame);
      // beam (hidden until lit)
      const beam = new THREE.Mesh(
        new THREE.CylinderGeometry(0.3, 0.5, 8, 10),
        new THREE.MeshBasicMaterial({ color: 0xffd489, transparent: true, opacity: 0.3, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide })
      );
      beam.position.y = 5;
      beam.visible = false;
      g.add(beam);
      // sequence numeral
      const seqPos = this.order.indexOf(i) + 1;
      const num = new THREE.Sprite(new THREE.SpriteMaterial({
        map: numeralTexture(seqPos), transparent: true, depthWrite: false, opacity: 0.95,
      }));
      num.scale.set(1.1, 1.1, 1);
      num.position.y = 2.9;
      g.add(num);
      g.position.set(x, 0, z);
      S.add(g);
      this.addCircle(x, z, 0.8);
      const pillar: Pillar = { i, x, z, group: g, beam, flame, lit: false, perfect: false };
      this.pillars.push(pillar);
      this.addInteractable(`pillar-${i}`, g, x, z, `Light flame ${seqPos}`, () => this.touchPillar(i), 3.8);
    }

    // timing ring
    this.ring = new THREE.Mesh(
      new THREE.TorusGeometry(1, 0.08, 10, 40),
      new THREE.MeshBasicMaterial({ color: 0xfff3d6, transparent: true, opacity: 0.95 })
    );
    this.ring.rotation.x = -Math.PI / 2;
    S.add(this.ring);

    // golden marker hovering over the current target flame
    this.marker = glowSprite(0xffd43b, 3.2, 0.85);
    S.add(this.marker);

    // exit arch (south), locked
    const exit = makeArchGate(5, 4.4);
    exit.position.set(0, 0, 23.5);
    S.add(exit);
    this.setExit(0, 23.5, 2.2);
    this.addSolid(-2.9, 23.1, -2.1, 23.9);
    this.addSolid(2.1, 23.1, 2.9, 23.9);
    this.barrierMat = new THREE.MeshBasicMaterial({ color: 0xe63956, transparent: true, opacity: 0.4, side: THREE.DoubleSide });
    const bp = new THREE.Mesh(new THREE.PlaneGeometry(4, 3.2), this.barrierMat);
    bp.position.set(0, 1.9, 23.5);
    S.add(bp);

    // bonus pickups
    for (const [x, z] of [[-12, -16], [12, -16], [-16, 4], [16, 4], [-8, 14], [8, 14]] as const) {
      this.addCollectible("flower", x, 0.9, z);
    }
    this.addCollectible("token", -21, 1.0, 0);
    this.addCollectible("token", 21, 1.0, 0);
    this.addCollectible("modak", -10, 1.0, -20);
    this.addCollectible("modak", 10, 1.0, -20);
  }

  private targetPillar(): Pillar | null {
    if (this.done || this.step >= this.order.length) return null;
    return this.pillars[this.order[this.step]] ?? null;
  }

  private touchPillar(i: number): void {
    if (this.done || this.state !== "playing") return;
    const expected = this.order[this.step];
    if (i === expected) {
      const frac = this.ringT / this.window;
      if (frac < 0.38) this.advanceStep("perfect");
      else if (frac < 0.68) this.advanceStep("good");
      else this.advanceStep("ok");
    } else {
      this.combo = 0;
      this.mult = 1;
      this.markAct(false);
      audio.playRangoliWrong();
      this.camera3d.addShake(0.3);
      const p = this.pillars[i];
      this.floaters.spawn(p.x, 3.2, p.z, "Not that one!", "hurt");
    }
  }

  private advanceStep(q: "perfect" | "good" | "ok"): void {
    const p = this.targetPillar();
    if (!p) return;
    p.lit = true;
    p.perfect = q === "perfect";
    p.beam.visible = true;
    (p.flame.material as THREE.SpriteMaterial).opacity = 1;
    p.flame.scale.set(2.4, 2.4, 1);
    this.bumpCombo();
    this.markAct(true);
    if (q === "perfect") {
      this.score += 150 * this.mult;
      audio.playRangoliPerfect();
      this.floaters.spawn(p.x, 3.4, p.z, `PERFECT +${150 * this.mult}`, "gold");
      this.sparks.burst(p.x, 1.8, p.z, 22, [0xffd43b, 0xfff3c4], 3.6);
    } else if (q === "good") {
      this.score += 80 * this.mult;
      audio.playRangoliGood();
      this.floaters.spawn(p.x, 3.4, p.z, `+${80 * this.mult}`, "");
    } else {
      this.score += 40 * this.mult;
      audio.playFlower();
      this.floaters.spawn(p.x, 3.4, p.z, `+${40 * this.mult}`, "");
    }
    this.step++;
    this.fails = 0;
    this.ringT = this.window;
    if (this.step >= this.order.length) {
      this.complete();
    } else {
      this.objective = `Light the 6 flames in order (${this.step + 1}/6)`;
      this.say(`Now go to golden-marked flame ${this.step + 1}!`);
    }
  }

  private complete(): void {
    this.done = true;
    const bonus = 400 * this.mult;
    this.score += bonus;
    audio.playRangoliFlourish();
    this.say(`GOLDEN RANGOLI! Enter the golden beam! 🎉`);
    // shockwave ring
    this.shock = new THREE.Mesh(
      new THREE.TorusGeometry(1, 0.16, 10, 48),
      new THREE.MeshBasicMaterial({ color: 0xffd43b, transparent: true, opacity: 0.9 })
    );
    this.shock.rotation.x = -Math.PI / 2;
    this.shock.position.y = 0.4;
    this.core.scene.add(this.shock);
    this.shockT = 0;
    // celebration bursts on every pillar
    for (const p of this.pillars) {
      this.sparks.burst(p.x, 2, p.z, 16, p.perfect ? [0xffd43b, 0xfff3c4] : [0xff6b8b, 0xc77dff], 3.6);
    }
    this.petals.petals(0, 5, 0, 30, 14);
    // open exit — mark it with a tall golden beam + light so nobody misses it
    this.exit.unlocked = true;
    if (this.barrierMat) this.barrierMat.opacity = 0;
    const exitBeam = new THREE.Mesh(
      new THREE.CylinderGeometry(0.7, 1.0, 16, 12),
      new THREE.MeshBasicMaterial({ color: 0xffd489, transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide })
    );
    exitBeam.position.set(0, 8, 23.5);
    this.core.scene.add(exitBeam);
    this.core.addDiyaLight(0, 4, 23.5, 0xffd43b, 26, 22);
    this.objective = "Beautiful! Walk SOUTH into the golden beam! ⬇";
    if (this.step >= this.order.length) {
      const acc = this.totalActs > 0 ? this.correctActs / this.totalActs : 1;
      if (acc >= 0.999) this.cb.onAchievement("perfect_rangoli");
    }
  }

  protected hookUpdate(dt: number): void {
    // target pulse + shrinking ring
    const target = this.targetPillar();
    if (target && !this.done && this.state === "playing") {
      // the countdown only runs while you stand near the flame —
      // no unfair fails while running across the courtyard
      const pd = Math.hypot(this.player.pos.x - target.x, this.player.pos.z - target.z);
      if (pd < 5.0) this.ringT -= dt;
      const frac = Math.max(0, this.ringT / this.window);
      const s = 0.55 + frac * 1.8;
      this.ring.position.set(target.x, 0.18, target.z);
      this.ring.scale.set(s, s, s);
      const inGold = frac < 0.38;
      (this.ring.material as THREE.MeshBasicMaterial).color.setHex(inGold ? 0xffd43b : 0xfff3d6);
      target.flame.scale.setScalar(1.6 + Math.sin(this.t * 9) * 0.3 + (inGold ? 0.5 : 0));
      // golden guide marker over the current target
      this.marker.visible = true;
      this.marker.position.set(target.x, 4.4 + Math.sin(this.t * 3) * 0.25, target.z);
      if (this.ringT <= 0) {
        this.fails++;
        this.combo = 0;
        this.mult = 1;
        this.markAct(false);
        audio.playRangoliWrong();
        this.floaters.spawn(target.x, 3.2, target.z, "Too slow!", "hurt");
        if (this.fails >= 4) {
          this.fails = 0;
          this.advanceStep("ok");
        } else {
          this.ringT = this.window;
        }
      }
    } else {
      this.ring.scale.set(0.001, 0.001, 0.001);
      if (this.marker) {
        if (this.done && this.state === "playing") {
          // point the way out
          this.marker.visible = true;
          this.marker.position.set(0, 5.5 + Math.sin(this.t * 3) * 0.3, 23.5);
        } else {
          this.marker.visible = false;
        }
      }
    }
    // shockwave
    if (this.shock && this.shockT >= 0) {
      this.shockT += dt;
      const k = this.shockT / 1.4;
      if (k >= 1) {
        this.core.scene.remove(this.shock);
        this.shock = null;
        this.shockT = -1;
      } else {
        const r = 1 + k * 13;
        this.shock.scale.set(r, r, r);
        (this.shock.material as THREE.MeshBasicMaterial).opacity = 0.9 * (1 - k);
      }
    }
    // lit beams sway
    for (const p of this.pillars) {
      if (p.lit) p.beam.rotation.y += dt * 0.6;
    }
  }

  protected progress01(): number {
    return (this.step / this.order.length) * 0.9 + (this.done ? 0.1 : 0);
  }

  protected onEnterExit(): void {
    this.win("RANGOLI COMPLETE! 🌸");
  }
}
