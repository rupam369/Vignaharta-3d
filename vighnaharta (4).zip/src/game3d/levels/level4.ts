// ============================================================
// LEVEL 4 — TEMPLE COURTYARD (3D) · EASY + NEVER-STUCK
// STEP 1: watch the 5 giant north diyas, repeat the short order.
// STEP 2: tap the 3 east chakras until gold meets flame (max 3 taps).
// STEP 3: enter the glowing east gate. A golden marker always
// points at the current objective. Short orders (2-3-4), slow
// show, 2-fail mercy, 4-step chakras, first-show hold, input-idle
// mercy and a 30s chakra kindness timer — the level ALWAYS ends.
// ============================================================
import * as THREE from "three";
import { audio } from "../../game/audio";
import type { MusicMode } from "../../game/audio";
import { LevelBase } from "../levelbase";
import {
  glowSprite, makeArchGate, makeBuilding, makeChakraWheel, makeGround,
  makeLampPost, makePillar, makeRangoliDisc, makeTempleFacade, makeTree, std,
} from "../art";

interface BigDiya {
  i: number;
  x: number; z: number;
  flame: THREE.Sprite;
  lit: boolean;
}

interface Wheel {
  face: THREE.Group;
  rot: number;
  targetZ: number;
  aligned: boolean;
}

const SEQ_LENS = [2, 3, 4];

export class Level4Temple extends LevelBase {
  protected musicMode: MusicMode = "temple";
  protected useAccuracyStars = true;

  private phase: "show" | "input" | "wheels" | "done" = "show";
  private round = 0;
  private seq: number[] = [];
  private showIdx = -1;
  private showT = 1.6;
  private showing = true;
  private stepIdx = 0;
  private fails = 0;
  private diyas5: BigDiya[] = [];
  private wheels: Wheel[] = [];
  private wheelGroups: THREE.Group[] = [];
  private diyaLight: THREE.PointLight | null = null;
  private litIdx = -1;
  private litT = 0;
  private barrier: THREE.Object3D | null = null;
  private marker!: THREE.Sprite;
  private inputIdleT = 0;
  private idleReshows = 0;
  private wheelsT = 0;

  protected nightOpts(): Record<string, number> {
    return { fogNear: 35, fogFar: 150 };
  }

  protected onBuild(): void {
    const S = this.core.scene;
    this.setBounds(-40, 40, -40, 40);
    this.setSpawn(0, 0, 33, Math.PI);
    this.objective = "STEP 1/3 · Go NORTH — watch the big diyas… 👁";
    this.newSequence();
    audio.startAmbience("temple");

    S.add(makeGround(150, 150, 0x1a1440));

    // boundary walls
    const wallM = std(0x322a55, 0.95);
    const wall = (w: number, d: number, x: number, z: number) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, 3.2, d), wallM);
      m.position.set(x, 1.6, z);
      m.receiveShadow = true;
      S.add(m);
    };
    wall(86, 2, 0, -42);
    wall(86, 2, 0, 42);
    wall(2, 86, -42, 0);
    wall(2, 86, 42, 0);

    // grand temple (north)
    const temple = makeTempleFacade(20, 12);
    temple.position.set(0, 0, -38);
    S.add(temple);
    this.addSolid(-11, -42, 11, -33);
    this.core.addDiyaLight(0, 4.5, -32, 0xffc87a, 30, 26);

    // pillar rows flanking the court
    for (const z of [-18, -10, -2, 6, 14, 22]) {
      for (const x of [-24, 24]) {
        const p = makePillar(5.5);
        p.position.set(x, 0, z);
        S.add(p);
        this.addCircle(x, z, 0.7);
      }
    }

    // trees + lamps
    for (const [x, z] of [[-34, -28], [34, -28], [-34, 28], [34, 28], [-34, 0], [34, 12]] as const) {
      const t = makeTree(1.15);
      t.position.set(x, 0, z);
      S.add(t);
      this.addCircle(x, z, 0.7);
    }
    for (const [x, z] of [[-12, 28], [12, 28], [-20, -6], [20, 14], [-8, -28], [8, -28]] as const) {
      const l = makeLampPost();
      l.position.set(x, 0, z);
      S.add(l);
    }
    this.core.addDiyaLight(0, 5, 8, 0xffb45e, 26, 26);

    // buildings outside
    for (const [x, z] of [[-52, 0], [52, 0], [0, -52], [-30, 52], [30, 52]] as const) {
      const b = makeBuilding(14, 11, 12);
      b.position.set(x, 0, z);
      S.add(b);
    }

    // bunting + diya rows + rangoli
    for (let i = 0; i < 6; i++) {
      const z = -24 + i * 9;
      this.buntings.span(-24, 7, z, 24, 7, z, 1.8, 14);
    }
    for (let x = -20; x <= 20; x += 4) {
      this.diyas.add(x, 0.02, -29, 1);
      this.diyas.add(x + 2, 0.02, 29, 1);
    }
    const r1 = makeRangoliDisc(3.4);
    r1.position.set(-14, 0.03, 12);
    const r2 = makeRangoliDisc(3.4);
    r2.position.set(14, 0.03, 12);
    S.add(r1, r2);

    // ---- 5 GIANT DIYAS (memory puzzle, NORTH row) ----
    for (let i = 0; i < 5; i++) {
      const x = -16 + i * 8;
      const z = -22;
      const g = new THREE.Group();
      const ped = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 1.1, 1.1, 12), std(0x3d3464, 0.85));
      ped.position.y = 0.55;
      ped.castShadow = true;
      g.add(ped);
      const bowl = new THREE.Mesh(new THREE.CylinderGeometry(1.0, 0.55, 0.5, 14), std(0x8a4b1f, 0.85));
      bowl.position.y = 1.35;
      bowl.castShadow = true;
      g.add(bowl);
      const flame = glowSprite(0xff9d5e, 2.2, 0.6);
      flame.position.y = 2.2;
      g.add(flame);
      // number plate
      const plate = new THREE.Mesh(
        new THREE.BoxGeometry(0.7, 0.7, 0.1),
        new THREE.MeshStandardMaterial({ color: 0xf5b942, roughness: 0.5 })
      );
      plate.position.set(0, 0.62, 1.05);
      g.add(plate);
      g.position.set(x, 0, z);
      S.add(g);
      this.addCircle(x, z, 1.3);
      this.diyas5.push({ i, x, z, flame, lit: false });
      this.addInteractable(`diya-${i}`, g, x, z, `Touch diya ${i + 1}`, () => this.pressDiya(i), 3.6);
    }
    this.diyaLight = this.core.addDiyaLight(0, 3, -22, 0xffc87a, 34, 24);

    // golden guide marker — always floats over the current objective
    this.marker = glowSprite(0xffd43b, 3.4, 0.9);
    S.add(this.marker);

    // ---- 3 CHAKRA WHEELS (EAST row, near gate) — 4 steps, max 3 taps ----
    for (let i = 0; i < 3; i++) {
      const z = -8 + i * 8;
      const { group, face } = makeChakraWheel(1.15);
      group.position.set(27, 0, z);
      group.rotation.y = -Math.PI / 2;
      S.add(group);
      this.wheelGroups.push(group);
      this.addCircle(27, z, 0.8);
      const rot = 1 + ((Math.random() * 3) | 0); // 1..3 → aligned within 3 taps
      face.rotation.z = (-rot / 4) * Math.PI * 2;
      this.wheels.push({ face, rot, targetZ: face.rotation.z, aligned: false });
      const it = this.addInteractable(`wheel-${i}`, group, 27, z, `Turn chakra ${["I", "II", "III"][i]} — tap till ALIGNED!`, () => this.rotateWheel(i), 3.4);
      it.enabled = false; // unlocked in STEP 2
    }

    // ---- east gate (exit) ----
    const gate = makeArchGate(5.5, 4.8);
    gate.rotation.y = Math.PI / 2;
    gate.position.set(36, 0, 0);
    S.add(gate);
    this.setExit(36, 0, 3.0);
    this.addSolid(35.6, -3.4, 36.4, -2.6);
    this.addSolid(35.6, 2.6, 36.4, 3.4);
    const bp = new THREE.Mesh(
      new THREE.PlaneGeometry(4.4, 3.4),
      new THREE.MeshBasicMaterial({ color: 0xe63956, transparent: true, opacity: 0.4, side: THREE.DoubleSide })
    );
    bp.rotation.y = Math.PI / 2;
    bp.position.set(36, 1.9, 0);
    S.add(bp);
    this.barrier = bp;
    this.puffs.strand(36, 5.4, -2.7, 36, 5.4, 2.7, 0.5);

    // ---- bonus pickups ----
    for (const [x, z] of [[-28, 20], [-20, 24], [20, 24], [28, 20], [-30, -14], [30, 22]] as const) {
      this.addCollectible("flower", x, 0.9, z);
    }
    this.addCollectible("token", -34, 1.0, 34);
    this.addCollectible("token", 12, 1.0, 34);
    this.addCollectible("modak", -12, 1.0, 30);
    this.addCollectible("modak", 0, 1.0, 30);
    this.addCollectible("modak", 12, 1.0, -14);
  }

  private newSequence(): void {
    const len = SEQ_LENS[this.round] ?? 2;
    this.seq = [];
    for (let i = 0; i < len; i++) this.seq.push((Math.random() * 5) | 0);
    this.stepIdx = 0;
    this.showIdx = -1;
    this.showing = true;
    this.showT = 1.6;
  }

  private lightDiya(i: number, big: boolean): void {
    this.litIdx = i;
    this.litT = big ? 0.75 : 0.5;
    const d = this.diyas5[i];
    if (d && this.diyaLight) {
      this.diyaLight.position.set(d.x, 3.2, d.z);
      this.diyaLight.intensity = big ? 55 : 40;
    }
  }

  private pressDiya(i: number): void {
    if (this.state !== "playing") return;
    this.inputIdleT = 0;
    if (this.phase === "show") {
      this.say("Watch first… your turn next! 👀");
      return;
    }
    if (this.phase !== "input") return;
    this.idleReshows = 0;
    this.lightDiya(i, false);
    audio.playDiyaNote(i);
    if (i === this.seq[this.stepIdx]) {
      this.markAct(true);
      this.stepIdx++;
      this.bumpCombo();
      this.score += 120 * this.mult;
      const d = this.diyas5[i];
      this.floaters.spawn(d.x, 3.6, d.z, `+${120 * this.mult}`, "gold");
      this.sparks.burst(d.x, 2.2, d.z, 10, [0xffcf6e, 0xfff3c4], 2.6);
      if (this.stepIdx >= this.seq.length) {
        const bonus = 250 * (this.round + 1) * this.mult;
        this.score += bonus;
        audio.playSuccess();
        if (this.round >= SEQ_LENS.length - 1) {
          this.say(`All orders remembered! +${bonus}`);
          this.startWheels();
        } else {
          this.say(`Order ${this.round + 1} complete! +${bonus}`);
          this.round++;
          this.fails = 0;
          this.newSequence();
          this.phase = "show";
          this.objective = `STEP 1/3 · Watch order ${this.round + 1} of 3… 👁`;
        }
      } else {
        this.objective = `STEP 1/3 · Your turn — order ${this.round + 1} of 3 (step ${this.stepIdx + 1}/${this.seq.length})`;
      }
    } else {
      this.markAct(false);
      this.combo = 0;
      this.mult = 1;
      this.fails++;
      audio.playMistake();
      this.camera3d.addShake(0.35);
      const d = this.diyas5[i];
      this.floaters.spawn(d.x, 3.6, d.z, "Wrong order!", "hurt");
      if (this.fails >= 2) {
        this.mercyAdvance();
      } else {
        this.stepIdx = 0;
        this.showIdx = -1;
        this.showing = true;
        this.showT = 1.2;
        this.phase = "show";
        this.say("Watch again…");
      }
    }
  }

  // the temple never lets anyone stay stuck — advance no matter what
  private mercyAdvance(): void {
    this.fails = 0;
    this.idleReshows = 0;
    this.inputIdleT = 0;
    this.say("The temple guides you onward… ✨");
    if (this.round >= SEQ_LENS.length - 1) this.startWheels();
    else {
      this.round++;
      this.newSequence();
      this.phase = "show";
      this.objective = `STEP 1/3 · Watch order ${this.round + 1} of 3… 👁`;
    }
  }

  private startWheels(): void {
    this.phase = "wheels";
    this.wheelsT = 0;
    this.objective = "STEP 2/3 · EAST side: tap 3 chakras till ALIGNED! ☸";
    this.say("STEP 2/3 · Chakras are EAST — follow the marker! ➡");
    audio.playCheckpoint();
    for (const it of this.interactables) {
      if (it.id.startsWith("wheel-")) it.enabled = true;
      if (it.id.startsWith("diya-")) it.enabled = false;
    }
  }

  private rotateWheel(i: number): void {
    if (this.phase !== "wheels" || this.state !== "playing") return;
    const w = this.wheels[i];
    if (!w || w.aligned) return;
    w.rot = (w.rot + 1) % 4;
    w.targetZ -= Math.PI / 2;
    this.markAct(true);
    audio.playRotate();
    this.sparks.burst(27, 2.4, -8 + i * 8, 5, [0xf5b942], 1.6);
    if (w.rot === 0) this.alignWheel(i);
  }

  private alignWheel(i: number, auto = false): void {
    const w = this.wheels[i];
    if (!w || w.aligned) return;
    // animate any remaining quarter-turns, then lock at visual zero
    const need = (4 - w.rot) % 4;
    w.targetZ -= need * Math.PI / 2;
    w.rot = 0;
    w.aligned = true;
    this.wheelsT = 0;
    this.bumpCombo();
    this.score += 250 * this.mult;
    audio.playDiya();
    this.floaters.spawn(27, 4.2, -8 + i * 8, auto ? "ALIGNED — blessed! ✨" : `ALIGNED! +${250 * this.mult}`, "gold");
    this.sparks.burst(27, 2.4, -8 + i * 8, 22, [0xffd43b, 0xfff3c4], 3.2);
    if (this.wheels.every((x) => x.aligned)) {
      this.score += 500 * this.mult;
      this.phase = "done";
      this.exit.unlocked = true;
      if (this.barrier) this.barrier.visible = false;
      // golden beam + light over the open gate
      const gateBeam = new THREE.Mesh(
        new THREE.CylinderGeometry(0.7, 1.0, 16, 12),
        new THREE.MeshBasicMaterial({ color: 0xffd489, transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide })
      );
      gateBeam.position.set(36, 8, 0);
      this.core.scene.add(gateBeam);
      this.core.addDiyaLight(36, 4, 0, 0xffd43b, 26, 22);
      this.objective = "STEP 3/3 · The temple glows — enter the EAST gate! ➡";
      this.say("STEP 3/3 · EAST GATE OPEN — GO! ➡");
      audio.playVictory();
    } else {
      const left = this.wheels.filter((x) => !x.aligned).length;
      this.say(auto ? `The temple aligns a chakra… ${left} left! ✨` : `Chakra aligned! ${left} left! ☸`);
    }
  }

  protected hookUpdate(dt: number): void {
    // flame flicker restore + diya light decay
    if (this.litT > 0) {
      this.litT -= dt;
      if (this.diyaLight) this.diyaLight.intensity = Math.max(26, this.diyaLight.intensity - dt * 60);
    }
    for (const d of this.diyas5) {
      const lit = this.litIdx === d.i && this.litT > 0;
      const s = lit ? 3.4 : 2.2 + Math.sin(this.t * 8 + d.i) * 0.25;
      d.flame.scale.set(s, s, 1);
    }

    // live diya prompts tell you watch vs play + your step counter
    if (this.state === "playing") {
      for (const it of this.interactables) {
        if (!it.id.startsWith("diya-")) continue;
        const n = Number(it.id.slice(5)) + 1;
        if (this.phase === "show") it.prompt = `👀 Watch diya ${n}…`;
        else if (this.phase === "input") it.prompt = `Touch diya ${n} — step ${Math.min(this.stepIdx + 1, this.seq.length)}/${this.seq.length}`;
        else it.prompt = `Diya ${n} done! ✨`;
      }
    }

    // playback (slow & clear) — the first show waits till you reach the diyas
    if (this.phase === "show" && this.state === "playing") {
      const holdingFirst = this.round === 0 && this.showIdx === -1 &&
        Math.hypot(this.player.pos.x, this.player.pos.z + 22) > 25;
      if (!holdingFirst) this.showT -= dt;
      if (this.showT <= 0 && !holdingFirst) {
        if (this.showing) {
          this.showIdx++;
          if (this.showIdx >= this.seq.length) {
            this.phase = "input";
            this.inputIdleT = 0;
            this.objective = `STEP 1/3 · Your turn — order ${this.round + 1} of 3 (step 1/${this.seq.length})`;
            this.say("Your turn — repeat the order!");
            audio.playTick();
          } else {
            const di = this.seq[this.showIdx];
            this.lightDiya(di, true);
            audio.playDiyaNote(di);
            const d = this.diyas5[di];
            this.sparks.burst(d.x, 2.2, d.z, 8, [0xffcf6e], 2);
            this.showing = false;
            this.showT = 0.45;
          }
        } else {
          this.showing = true;
          this.showT = 0.5;
        }
      }
    }

    // input idle mercy — stuck or away? the temple re-shows, then advances
    if (this.phase === "input" && this.state === "playing") {
      this.inputIdleT += dt;
      if (this.inputIdleT > 20) {
        this.inputIdleT = 0;
        if (this.idleReshows >= 1) {
          this.mercyAdvance();
        } else {
          this.idleReshows++;
          this.stepIdx = 0;
          this.showIdx = -1;
          this.showing = true;
          this.showT = 1.2;
          this.phase = "show";
          this.objective = `STEP 1/3 · Watch order ${this.round + 1} of 3… 👁`;
          this.say("Watch again… 👀");
        }
      }
    }

    // wheel spin animation
    for (const w of this.wheels) {
      const d = w.targetZ - w.face.rotation.z;
      if (Math.abs(d) > 0.001) {
        w.face.rotation.z += d * Math.min(1, dt * 8);
      }
      if (w.aligned) w.face.rotation.z += dt * 0.4;
    }

    // wheels kindness timer — every 30s the temple aligns the next chakra
    if (this.phase === "wheels" && this.state === "playing") {
      this.wheelsT += dt;
      if (this.wheelsT > 30) {
        this.wheelsT = 0;
        const next = this.wheels.findIndex((w) => !w.aligned);
        if (next >= 0) {
          this.markAct(true);
          this.alignWheel(next, true);
        }
      }
    }

    // guide marker follows the current objective
    if (this.marker) {
      if (this.state === "playing") {
        let mx = 0, mz = 0, my = 5.5, show = true;
        if (this.phase === "show" || this.phase === "input") {
          mx = 0; mz = -22; my = 5.5;
        } else if (this.phase === "wheels") {
          const next = this.wheels.findIndex((w) => !w.aligned);
          if (next >= 0) { mx = 27; mz = -8 + next * 8; my = 5; }
          else show = false;
        } else if (this.phase === "done") {
          mx = 36; mz = 0; my = 6;
        } else {
          show = false;
        }
        this.marker.visible = show;
        if (show) this.marker.position.set(mx, my + Math.sin(this.t * 3) * 0.3, mz);
      } else {
        this.marker.visible = false;
      }
    }
  }

  protected progress01(): number {
    if (this.phase === "done") return 1;
    if (this.phase === "wheels") {
      const a = this.wheels.filter((w) => w.aligned).length;
      return 0.62 + (a / 3) * 0.33;
    }
    return (this.round / SEQ_LENS.length) * 0.62 + (this.stepIdx / Math.max(1, this.seq.length)) * 0.2;
  }

  protected onEnterExit(): void {
    this.win("TEMPLE BLESSED! 🛕");
  }
}
