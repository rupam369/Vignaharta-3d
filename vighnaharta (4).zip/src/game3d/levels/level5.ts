// ============================================================
// LEVEL 5 — GRAND FESTIVAL FINALE (3D)
// STEP 1: collect 6 offerings → STEP 2: light 3 flames in order →
// STEP 3: unlock the 4-diya mandap lock → STEP 4: bring the Modak
// home → CINEMATIC. NEVER-STUCK: diyas enable on lock, first-show
// hold, 2-fail mercy, 20s idle mercy — the mandap ALWAYS unlocks.
// ============================================================
import * as THREE from "three";
import { audio } from "../../game/audio";
import type { MusicMode } from "../../game/audio";
import { LevelBase } from "../levelbase";
import {
  glow, glowSprite, makeArchGate, makeBeam, makeBuilding, makeCrate,
  makeGround, makeLampPost, makeModak, makeRangoliDisc, makeStall,
  makeStreet, makeTempleFacade, makeTree, numeralTexture, std,
} from "../art";

interface Flame {
  x: number; z: number;
  beam: THREE.Mesh;
  flame: THREE.Sprite;
  lit: boolean;
}

export class Level5Finale extends LevelBase {
  protected musicMode: MusicMode = "finale";

  private phase: "collect" | "flames" | "show" | "input" | "walk" | "cine" = "collect";
  private offerings = 0;
  private offeringsNeeded = 6;
  private flames: Flame[] = [];
  private flameStep = 0;
  private seq: number[] = [];
  private showIdx = -1;
  private showT = 0;
  private showing = true;
  private stepIdx = 0;
  private fails = 0;
  private diyaFlames: THREE.Sprite[] = [];
  private diyaPos: { x: number; z: number }[] = [];
  private litIdx = -1;
  private litT = 0;
  private cineT = 0;
  private cineSaid2 = false;
  private fireT = 0;
  private inputIdleT = 0;
  private idleReshows = 0;
  private mandap = { x: 0, z: -38 };

  protected nightOpts(): Record<string, number> {
    return { fogNear: 40, fogFar: 170 };
  }

  protected onBuild(): void {
    const S = this.core.scene;
    this.setBounds(-46, 46, -46, 46);
    this.setSpawn(0, 0, 40, Math.PI);
    this.objective = `STEP 1/4 · Gather 6 offerings (0/${this.offeringsNeeded})`;

    S.add(makeGround(170, 170, 0x16122e));
    const avenue = makeStreet(16, 100);
    avenue.position.set(0, 0.015, -2);
    S.add(avenue);

    // boundary walls
    const wallM = std(0x2a2350, 0.95);
    const wall = (w: number, d: number, x: number, z: number) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, 3, d), wallM);
      m.position.set(x, 1.5, z);
      m.receiveShadow = true;
      S.add(m);
    };
    wall(98, 2, 0, -48);
    wall(98, 2, 0, 48);
    wall(2, 98, -48, 0);
    wall(2, 98, 48, 0);

    // temple backdrop far north
    const temple = makeTempleFacade(22, 13);
    temple.position.set(0, 0, -56);
    S.add(temple);
    this.addSolid(-12, -48, 12, -44);
    this.core.addDiyaLight(0, 5, -44, 0xffc87a, 30, 26);

    // side stalls
    for (const [x, z] of [[-14, 24], [14, 24], [-14, 4], [14, 4], [-14, -14], [14, -14]] as const) {
      const st = makeStall(x < 0 ? "#e63956" : "#7a2bd0", "#ffe9c4");
      st.position.set(x, 0, z);
      st.rotation.y = x < 0 ? Math.PI / 2 : -Math.PI / 2;
      S.add(st);
      this.addSolid(x - 1.1, z - 1.6, x + 1.1, z + 1.6);
    }

    // buildings, trees, lamps
    for (const [x, z] of [[-56, 20], [56, 20], [-56, -20], [56, -20], [-30, 56], [30, 56]] as const) {
      const b = makeBuilding(15, 11, 12);
      b.position.set(x, 0, z);
      S.add(b);
    }
    for (const [x, z] of [[-34, -34], [34, -34], [-34, 34], [34, 34], [-38, 0], [38, 0]] as const) {
      const t = makeTree(1.2);
      t.position.set(x, 0, z);
      S.add(t);
      this.addCircle(x, z, 0.7);
    }
    for (const z of [-28, -12, 4, 20, 34]) {
      for (const x of [-9.6, 9.6]) {
        const l = makeLampPost();
        l.position.set(x, 0, z);
        S.add(l);
      }
    }
    this.core.addDiyaLight(0, 4, 20, 0xffb45e, 16, 18);
    this.core.addDiyaLight(0, 4, -12, 0xffb45e, 16, 18);

    // bunting + diyas + rangoli
    for (let i = 0; i < 7; i++) {
      const z = -30 + i * 10;
      this.buntings.span(-10, 7.4, z, 10, 7.4, z, 1.4, 10);
    }
    for (let z = -36; z <= 40; z += 4) {
      this.diyas.add(-8.4, 0.02, z, 1);
      this.diyas.add(8.4, 0.02, z + 2, 1);
    }
    for (const [x, z, r] of [[-20, 30, 3], [20, 12, 3], [-20, -6, 3], [20, -24, 3]] as const) {
      const d = makeRangoliDisc(r);
      d.position.set(x, 0.03, z);
      S.add(d);
    }

    // phase gates (visual arches)
    for (const z of [18, -12] as const) {
      const g = makeArchGate();
      g.position.set(0, 0, z);
      S.add(g);
      this.addSolid(-2.9, z - 0.4, -2.1, z + 0.4);
      this.addSolid(2.1, z - 0.4, 2.9, z + 0.4);
      this.puffs.strand(-2.5, 5.2, z, 2.5, 5.2, z, 0.5);
    }
    this.addCheckpoint(0, 18, "Flower Gate");
    this.addCheckpoint(0, -12, "Flame Plaza");

    // crates
    const crate = (x: number, y: number, z: number, s: number) => {
      const c = makeCrate(s);
      c.position.set(x, y + s / 2, z);
      S.add(c);
      this.addTop(x - s / 2, z - s / 2, x + s / 2, z + s / 2, y + s);
    };
    crate(-12, 0, 28, 1.3);
    crate(-12, 1.3, 28, 1.0);
    crate(12, 0, -20, 1.3);
    crate(13.4, 0, -19.2, 1.3);

    // patrol carts
    const cartM = () => {
      const c = makeStall("#e63956", "#ffd98a");
      c.scale.setScalar(0.85);
      return c;
    };
    this.addMover(cartM(), [{ x: -4, z: 30 }, { x: -4, z: -28 }], 3.4, 1.5, true);
    this.addMover(cartM(), [{ x: 4, z: -28 }, { x: 4, z: 30 }], 3.0, 1.5, true);

    // ---- 6 offerings ----
    const off: [number, number, number][] = [
      [0, 1.0, 30], [-12, 3.0, 28], [12, 2.0, -20],
      [-6, 1.0, 6], [6, 1.0, -6], [0, 1.0, -22],
    ];
    for (const [x, y, z] of off) this.addCollectible("offering", x, y, z, { beam: true });

    // bonus pickups
    for (const [x, z] of [[-24, 34], [24, 34], [-24, -30], [24, -30], [-6, 24], [6, 12]] as const) {
      this.addCollectible("flower", x, 0.9, z);
    }
    this.addCollectible("token", -26, 1.0, 0);
    this.addCollectible("token", 26, 1.0, -8);
    this.addCollectible("modak", -4, 1.0, 36);
    this.addCollectible("modak", 4, 1.0, 36);

    // ---- 3 flame pillars (STEP 2) ----
    for (let i = 0; i < 3; i++) {
      const x = -8 + i * 8;
      const z = -12;
      const g = new THREE.Group();
      const ped = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.7, 1.0, 12), std(0x3d3464, 0.85));
      ped.position.y = 0.5;
      ped.castShadow = true;
      g.add(ped);
      const bowl = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.3, 0.26, 12), std(0x8a4b1f, 0.85));
      bowl.position.y = 1.1;
      g.add(bowl);
      const flame = glowSprite(0xff9d5e, 1.8, 0.55);
      flame.position.y = 1.7;
      g.add(flame);
      const beam = makeBeam(0xffd489, 0.32, 8);
      beam.visible = false;
      g.add(beam);
      const num = new THREE.Sprite(new THREE.SpriteMaterial({ map: numeralTexture(i + 1), transparent: true, depthWrite: false }));
      num.scale.set(1, 1, 1);
      num.position.y = 3.1;
      g.add(num);
      g.position.set(x, 0, z);
      this.core.scene.add(g);
      this.addCircle(x, z, 0.9);
      this.flames.push({ x, z, beam, flame, lit: false });
      const it = this.addInteractable(`flame-${i}`, g, x, z, `Light flame ${i + 1} — in order!`, () => this.touchFlame(i), 3.2);
      it.enabled = false;
    }

    // ---- 4 mandap diyas (STEP 3) ----
    for (let i = 0; i < 4; i++) {
      const x = -9 + i * 6;
      const z = -30;
      const g = new THREE.Group();
      const ped = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 0.85, 1.0, 12), std(0x3d3464, 0.85));
      ped.position.y = 0.5;
      ped.castShadow = true;
      g.add(ped);
      const bowl = new THREE.Mesh(new THREE.CylinderGeometry(0.66, 0.36, 0.34, 12), std(0x8a4b1f, 0.85));
      bowl.position.y = 1.15;
      g.add(bowl);
      const flame = glowSprite(0xff9d5e, 1.9, 0.6);
      flame.position.y = 1.85;
      g.add(flame);
      g.position.set(x, 0, z);
      this.core.scene.add(g);
      this.addCircle(x, z, 1.0);
      this.diyaPos.push({ x, z });
      this.diyaFlames.push(flame);
      const it = this.addInteractable(`mdiya-${i}`, g, x, z, `Touch diya ${i + 1}`, () => this.pressDiya(i), 3.4);
      it.enabled = false; // enabled when the lock awakens (STEP 3)
    }
    this.core.addDiyaLight(0, 3.5, -30, 0xffc87a, 26, 22);

    // ---- THE MANDAP + LOST MODAK ----
    const mx = this.mandap.x;
    const mz = this.mandap.z;
    for (const [px, pz] of [[-5, -3], [5, -3], [-5, 3], [5, 3]] as const) {
      const pil = new THREE.Mesh(new THREE.BoxGeometry(0.8, 7, 0.8), std(0x5a4a8a, 0.8));
      pil.position.set(mx + px, 3.5, mz + pz);
      pil.castShadow = true;
      S.add(pil);
      this.addSolid(mx + px - 0.5, mz + pz - 0.5, mx + px + 0.5, mz + pz + 0.5);
      const cap = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.35, 1.2), glow(0xf5b942, 0.8));
      cap.position.set(mx + px, 7.15, mz + pz);
      S.add(cap);
      this.diyas.add(mx + px, 7.4, mz + pz, 0.9);
    }
    const canopy = new THREE.Mesh(new THREE.BoxGeometry(13, 0.7, 9), std(0xa41623, 0.85));
    canopy.position.set(mx, 7.6, mz);
    canopy.castShadow = true;
    S.add(canopy);
    // eternal golden beacon over the mandap — the finale landmark
    const mandapBeam = new THREE.Mesh(
      new THREE.CylinderGeometry(0.9, 1.3, 20, 12),
      new THREE.MeshBasicMaterial({ color: 0xffd489, transparent: true, opacity: 0.32, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide })
    );
    mandapBeam.position.set(mx, 10, mz);
    S.add(mandapBeam);
    this.puffs.strand(mx - 6, 7.1, mz + 4, mx + 6, 7.1, mz + 4, 0.7);
    // pedestal + giant modak
    const ped2 = new THREE.Mesh(new THREE.BoxGeometry(3.4, 1.4, 3.4), std(0x4a3f78, 0.8));
    ped2.position.set(mx, 0.7, mz);
    ped2.castShadow = true;
    S.add(ped2);
    this.addSolid(mx - 1.8, mz - 1.8, mx + 1.8, mz + 1.8);
    const giant = makeModak(3.2);
    giant.position.set(mx, 1.4, mz);
    S.add(giant);
    const halo = glowSprite(0xffd9a0, 12, 0.55);
    halo.position.set(mx, 4.5, mz);
    S.add(halo);
    const beamUp = makeBeam(0xffe2ae, 0.8, 16);
    beamUp.position.set(mx, 1.4, mz);
    S.add(beamUp);
    this.core.addDiyaLight(mx, 5, mz, 0xffd9a0, 34, 24);
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2;
      this.diyas.add(mx + Math.cos(a) * 5, 0.02, mz + Math.sin(a) * 5, 1.1);
    }
  }

  // ---------- STEP 1 → 2 ----------
  protected onModak(c: { kind: string }): void {
    if (this.phase !== "collect") return;
    if (c.kind !== "offering") return;
    this.offerings++;
    if (this.offerings >= this.offeringsNeeded) {
      this.phase = "flames";
      this.objective = "STEP 2/4 · Light the 3 flames in order (1/3)";
      this.say("Offerings gathered! Light the flames in order! 🔥");
      audio.playSuccess();
      for (const it of this.interactables) {
        if (it.id.startsWith("flame-")) it.enabled = true;
      }
    } else {
      this.objective = `STEP 1/4 · Gather 6 offerings (${this.offerings}/${this.offeringsNeeded})`;
    }
  }

  // ---------- STEP 2: flames in order ----------
  private touchFlame(i: number): void {
    if (this.phase !== "flames" || this.state !== "playing") return;
    if (i === this.flameStep) {
      const f = this.flames[i];
      f.lit = true;
      f.beam.visible = true;
      (f.flame.material as THREE.SpriteMaterial).opacity = 1;
      f.flame.scale.set(2.6, 2.6, 1);
      this.bumpCombo();
      this.markAct(true);
      this.score += 200 * this.mult;
      audio.playRangoliPerfect();
      this.floaters.spawn(f.x, 3.6, f.z, `FLAME ${i + 1}! +${200 * this.mult}`, "gold");
      this.sparks.burst(f.x, 2, f.z, 20, [0xffd43b, 0xff7a1a], 3.6);
      this.flameStep++;
      if (this.flameStep >= 3) {
        this.phase = "show";
        this.seq = [0, 1, 2, 3].map(() => (Math.random() * 4) | 0);
        this.showIdx = -1;
        this.showing = true;
        this.showT = 1.2;
        this.stepIdx = 0;
        this.inputIdleT = 0;
        this.idleReshows = 0;
        // THE FIX: wake the 4 lock diyas, sleep the flames
        for (const it of this.interactables) {
          if (it.id.startsWith("mdiya-")) it.enabled = true;
          if (it.id.startsWith("flame-")) it.enabled = false;
        }
        this.objective = "STEP 3/4 · Final lock: watch the diya order… 👁";
        this.say("The mandap lock awakens — go NORTH to the diyas!");
        audio.playSuccess();
      } else {
        this.objective = `STEP 2/4 · Light the 3 flames in order (${this.flameStep + 1}/3)`;
      }
    } else {
      this.combo = 0;
      this.mult = 1;
      this.markAct(false);
      audio.playRangoliWrong();
      this.camera3d.addShake(0.3);
      const f = this.flames[i];
      this.floaters.spawn(f.x, 3.4, f.z, "In order!", "hurt");
    }
  }

  // ---------- STEP 3: diya lock ----------
  private pressDiya(i: number): void {
    if (this.state !== "playing") return;
    this.inputIdleT = 0;
    if (this.phase === "show") {
      this.say("Watch first… your turn next! 👀");
      return;
    }
    if (this.phase !== "input") return;
    this.idleReshows = 0;
    this.litIdx = i;
    this.litT = 0.5;
    audio.playDiyaNote(i);
    const d = this.diyaPos[i];
    if (i === this.seq[this.stepIdx]) {
      this.markAct(true);
      this.stepIdx++;
      this.bumpCombo();
      this.score += 150 * this.mult;
      this.floaters.spawn(d.x, 3.4, d.z, `+${150 * this.mult}`, "gold");
      this.sparks.burst(d.x, 2, d.z, 10, [0xffcf6e], 2.6);
      if (this.stepIdx >= this.seq.length) {
        this.score += 600 * this.mult;
        audio.playSuccess();
        this.goWalk("THE WAY IS OPEN!");
      } else {
        this.objective = `STEP 3/4 · Your turn — unlock the mandap! (step ${this.stepIdx + 1}/${this.seq.length})`;
      }
    } else {
      this.markAct(false);
      this.combo = 0;
      this.mult = 1;
      this.fails++;
      audio.playMistake();
      this.camera3d.addShake(0.35);
      this.floaters.spawn(d.x, 3.4, d.z, "Wrong order!", "hurt");
      if (this.fails >= 2) {
        this.goWalk("Bappa guides you onward… ✨");
      } else {
        this.phase = "show";
        this.showIdx = -1;
        this.showing = true;
        this.showT = 1.2;
        this.stepIdx = 0;
        this.say("Watch again…");
      }
    }
  }

  private goWalk(line: string): void {
    this.phase = "walk";
    this.objective = "STEP 4/4 · Bring the Modak home — walk to the mandap! 🙏";
    this.say(line);
    for (const it of this.interactables) it.enabled = false;
  }

  protected hookUpdate(dt: number): void {
    // diya flame flicker
    if (this.litT > 0) this.litT -= dt;
    for (let i = 0; i < this.diyaFlames.length; i++) {
      const f = this.diyaFlames[i];
      const lit = this.litIdx === i && this.litT > 0;
      const s = lit ? 3.2 : 1.9 + Math.sin(this.t * 8 + i) * 0.2;
      f.scale.set(s, s, 1);
    }

    // live diya prompts: watch vs play + step counter
    if (this.state === "playing") {
      for (const it of this.interactables) {
        if (!it.id.startsWith("mdiya-")) continue;
        const n = Number(it.id.slice(6)) + 1;
        if (this.phase === "show") it.prompt = `👀 Watch diya ${n}…`;
        else if (this.phase === "input") it.prompt = `Touch diya ${n} — step ${Math.min(this.stepIdx + 1, this.seq.length)}/${this.seq.length}`;
        else it.prompt = `Diya ${n} done! ✨`;
      }
    }

    // lock playback (slow & clear) — waits till you reach the diyas
    if (this.phase === "show" && this.state === "playing") {
      const holdingFirst = this.showIdx === -1 &&
        Math.hypot(this.player.pos.x, this.player.pos.z + 30) > 18;
      if (!holdingFirst) this.showT -= dt;
      if (this.showT <= 0 && !holdingFirst) {
        if (this.showing) {
          this.showIdx++;
          if (this.showIdx >= this.seq.length) {
            this.phase = "input";
            this.inputIdleT = 0;
            this.objective = `STEP 3/4 · Your turn — unlock the mandap! (step 1/${this.seq.length})`;
            this.say("Your turn — unlock the mandap!");
          } else {
            const di = this.seq[this.showIdx];
            this.litIdx = di;
            this.litT = 0.75;
            audio.playDiyaNote(di);
            const d = this.diyaPos[di];
            this.sparks.burst(d.x, 2, d.z, 8, [0xffcf6e], 2);
            this.showing = false;
            this.showT = 0.45;
          }
        } else {
          this.showing = true;
          this.showT = 0.5;
        }
      }
    }

    // input idle mercy — stuck or away? re-show once, then Bappa opens the way
    if (this.phase === "input" && this.state === "playing") {
      this.inputIdleT += dt;
      if (this.inputIdleT > 20) {
        this.inputIdleT = 0;
        if (this.idleReshows >= 1) {
          this.goWalk("Bappa guides you onward… ✨");
        } else {
          this.idleReshows++;
          this.stepIdx = 0;
          this.showIdx = -1;
          this.showing = true;
          this.showT = 1.2;
          this.phase = "show";
          this.objective = "STEP 3/4 · Final lock: watch the diya order… 👁";
          this.say("Watch again… 👀");
        }
      }
    }

    // walk-to-mandap trigger
    if (this.phase === "walk" && this.state === "playing") {
      const dx = this.player.pos.x - this.mandap.x;
      const dz = this.player.pos.z - (this.mandap.z + 3.4);
      if (Math.hypot(dx, dz) < 3.2) this.startCine();
    }

    // celebration cinematic
    if (this.state === "cine") {
      this.cineT += dt;
      this.fireT -= dt;
      if (this.fireT <= 0) {
        this.fireT = 0.3;
        this.sparks.firework(
          this.mandap.x + (Math.random() - 0.5) * 30,
          9 + Math.random() * 7,
          this.mandap.z + (Math.random() - 0.5) * 24,
          [0xffd43b, 0xff6b8b, 0x7ec8ff, 0x2f9e6e, 0xc77dff][(Math.random() * 5) | 0]
        );
      }
      if (Math.random() < dt * 14) {
        this.petals.petals(this.mandap.x + (Math.random() - 0.5) * 26, 9, this.mandap.z + (Math.random() - 0.5) * 20, 3, 4);
      }
      if (this.cineT > 2.6 && !this.cineSaid2) {
        this.cineSaid2 = true;
        this.floaters.bigTitle("GANAPATI BAPPA MORYA!", "🙏 The Utsav is complete 🙏");
      }
      this.syncMushak(dt, 0, true);
      this.camera3d.update(dt, this.core.camera, this.player.pos, this.player.faceYaw, false, this.groundFn, this.opts.settings.reducedMotion);
      if (this.cineT > 7.0 && !this.fadedOutCine) {
        this.fadedOutCine = true;
        this.floaters.fade("out", 700);
      }
      if (this.cineT > 7.9 && !this.sent) {
        this.sent = true;
        this.cb.onAchievement("vighnaharta");
        this.finish(true);
      }
    }
  }

  private fadedOutCine = false;

  private startCine(): void {
    if (this.state !== "playing") return;
    this.state = "cine";
    this.phase = "cine";
    this.cineT = 0;
    this.floaters.setPrompt(null);
    this.floaters.bigTitle("THE MODAK HAS RETURNED", "Mushak did it — the offering is home");
    this.camera3d.startCine(8, this.mandap.x, this.mandap.z, 14, 6.5);
    audio.playFinaleCinematic();
    this.say("THE MODAK HAS RETURNED");
  }

  protected progress01(): number {
    if (this.phase === "collect") return (this.offerings / this.offeringsNeeded) * 0.4;
    if (this.phase === "flames") return 0.4 + (this.flameStep / 3) * 0.2;
    if (this.phase === "show" || this.phase === "input") return 0.6 + (this.stepIdx / Math.max(1, this.seq.length)) * 0.2;
    if (this.phase === "walk") return 0.85;
    return 0.9 + Math.min(0.1, this.cineT / 80);
  }

  protected onEnterExit(): void {
    /* no exit zone in the finale */
  }
}
