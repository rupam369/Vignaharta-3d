// ============================================================
// LEVEL 1 — FESTIVAL STREETS (3D)
// Explore a night Utsav street, find 2 Modak fragments, dodge
// patrol carts, reach the glowing gate. Daily mode: timed hunt.
// ============================================================
import * as THREE from "three";
import { audio } from "../../game/audio";
import type { MusicMode } from "../../game/audio";
import { LevelBase } from "../levelbase";
import {
  glow, glowSprite, makeArchGate, makeBarrierDhol, makeBuilding, makeCrate,
  makeGround, makeLampPost, makeRangoliDisc, makeStall, makeStreet,
  makeTempleFacade, makeTree, std,
} from "../art";

export class Level1Streets extends LevelBase {
  protected musicMode: MusicMode = "street";
  private barrier: THREE.Group | null = null;
  private exitBeams: THREE.Object3D[] = [];

  protected nightOpts(): Record<string, number> {
    return { fogNear: 35, fogFar: 150 };
  }

  protected onBuild(): void {
    const S = this.core.scene;
    const daily = this.opts.daily;
    this.setBounds(-44, 44, -44, 44);
    this.setSpawn(0, 0, 38, Math.PI);
    this.objective = daily ? `Collect ${daily.goalModaks} Modaks!` : "Find 2 Modak fragments — follow the golden beams! (0/2)";

    // ---- ground + streets ----
    S.add(makeGround(150, 150, 0x16122e));
    const main = makeStreet(15, 96);
    S.add(main);
    const side = makeStreet(80, 9);
    side.position.set(0, 0.02, 6);
    S.add(side);

    // ---- boundary walls ----
    const wallM = std(0x2a2350, 0.95);
    const wall = (w: number, d: number, x: number, z: number) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, 2.6, d), wallM);
      m.position.set(x, 1.3, z);
      m.receiveShadow = true;
      S.add(m);
      const trim = new THREE.Mesh(new THREE.BoxGeometry(w === 2 ? 2.4 : w, 0.25, d === 2 ? 2.4 : d), glow(0xf5b942, 0.7));
      trim.position.set(x, 2.7, z);
      S.add(trim);
    };
    wall(94, 2, 0, -46);
    wall(94, 2, 0, 46);
    wall(2, 94, -46, 0);
    wall(2, 94, 46, 0);

    // ---- temple (north backdrop) ----
    const temple = makeTempleFacade(18, 11);
    temple.position.set(0, 0, -41);
    S.add(temple);
    this.addSolid(-10, -46, 10, -36.5);
    this.core.addDiyaLight(0, 4, -36, 0xffc87a, 22, 20);

    // ---- stalls (east/west rows) ----
    const stallAt = (x: number, z: number, flip: boolean) => {
      const st = makeStall();
      st.position.set(x, 0, z);
      st.rotation.y = flip ? Math.PI / 2 : -Math.PI / 2;
      S.add(st);
      this.addSolid(x - 1.1, z - 1.6, x + 1.1, z + 1.6);
    };
    for (const z of [-12, 0, 12]) {
      stallAt(-13, z, false);
      stallAt(13, z, true);
    }

    // ---- buildings outside the walls ----
    const bPos: [number, number, number][] = [
      [-54, -20, 0], [-54, 8, 1], [-54, 32, 0], [54, -20, 1], [54, 8, 0],
      [54, 32, 1], [-24, -54, 0], [24, -54, 1], [-24, 54, 1], [24, 54, 0],
    ];
    for (const [x, z, v] of bPos) {
      const b = makeBuilding(14 + v * 4, 10 + v * 5, 12, v ? 0x201a44 : 0x1c1638);
      b.position.set(x, 0, z);
      S.add(b);
    }

    // ---- trees + lamps ----
    for (const [x, z, s] of [[-32, -32, 1.2], [32, -32, 1], [-32, 32, 1], [32, 32, 1.25], [-34, 0, 0.9], [34, 0, 0.9]] as const) {
      const t = makeTree(s);
      t.position.set(x, 0, z);
      S.add(t);
      this.addCircle(x, z, 0.7);
      // fairy lights in the branches (zero extra draw calls via motes)
      for (let i = 0; i < 5; i++) {
        this.moteList.push({
          x: x + (Math.random() - 0.5) * 3, y: 2.6 + Math.random() * 2.2, z: z + (Math.random() - 0.5) * 3,
          size: 0.9, color: [0xffd43b, 0xff6b8b, 0x7ec8ff][i % 3], speed: 3,
        });
      }
    }
    for (const z of [-30, -15, 0, 15, 30]) {
      for (const x of [-8.6, 8.6]) {
        const l = makeLampPost();
        l.position.set(x, 0, z);
        S.add(l);
        this.addCircle(x, z, 0.3);
      }
    }
    this.core.addDiyaLight(0, 4, 20, 0xffb45e, 14, 16);
    this.core.addDiyaLight(0, 4, 0, 0xffb45e, 14, 16);
    this.core.addDiyaLight(0, 4, -20, 0xffb45e, 14, 16);

    // ---- bunting across the street ----
    for (const z of [-28, -16, -4, 8, 20, 30]) {
      this.buntings.span(-9.5, 7.2, z, 9.5, 7.2, z, 1.4, 10);
    }
    this.buntings.span(-30, 7.5, 6, -10, 7.5, 6, 1.2, 8);
    this.buntings.span(10, 7.5, 6, 30, 7.5, 6, 1.2, 8);

    // ---- diya rows (instanced) ----
    for (let z = -34; z <= 34; z += 4) {
      this.diyas.add(-7.6, 0.02, z, 1);
      this.diyas.add(7.6, 0.02, z + 2, 1);
    }
    for (let i = 0; i < 7; i++) this.diyas.add(-9 + i * 3, 0.02, -34.5, 1.1);
    this.diyas.add(-3, 0.02, -30.5, 1.2);
    this.diyas.add(3, 0.02, -30.5, 1.2);

    // ---- marigold garlands on arches + stalls ----
    this.puffs.strand(-9.5, 7.0, -16, 9.5, 7.0, -16, 1.0);
    this.puffs.strand(-9.5, 7.0, 8, 9.5, 7.0, 8, 1.0);

    // ---- rangoli decals ----
    const r1 = makeRangoliDisc(4);
    r1.position.set(0, 0.03, 20);
    const r2 = makeRangoliDisc(3);
    r2.position.set(-20, 0.03, -8);
    const r3 = makeRangoliDisc(2.6);
    r3.position.set(22, 0.03, 22);
    S.add(r1, r2, r3);

    // ---- static dhol barriers ----
    for (const [x, z] of [[-5, -6], [5, 16], [-5, 26], [5, -24]] as const) {
      const d = makeBarrierDhol();
      d.position.set(x, 0, z);
      d.rotation.y = Math.random() * 0.6;
      S.add(d);
      this.addSolid(x - 0.9, z - 0.6, x + 0.9, z + 0.6);
    }

    // ---- checkpoint arches ----
    const gate1 = makeArchGate();
    gate1.position.set(0, 0, 20);
    S.add(gate1);
    this.addCheckpoint(0, 20, "Flower Gate", 3.4);
    this.addSolid(-2.9, 19.6, -2.1, 20.4);
    this.addSolid(2.1, 19.6, 2.9, 20.4);
    this.puffs.strand(-2.5, 5.2, 20, 2.5, 5.2, 20, 0.5);
    const gate2 = makeArchGate();
    gate2.position.set(0, 0, -14);
    S.add(gate2);
    this.addCheckpoint(0, -14, "Temple Steps", 3.4);
    this.addSolid(-2.9, -14.4, -2.1, -13.6);
    this.addSolid(2.1, -14.4, 2.9, -13.6);
    this.puffs.strand(-2.5, 5.2, -14, 2.5, 5.2, -14, 0.5);

    // ---- exit gate (north, locked until 2 fragments) ----
    const exit = makeArchGate(6, 5.2);
    exit.position.set(0, 0, -31);
    S.add(exit);
    this.setExit(0, -31, 3.0);
    this.addSolid(-3.4, -31.4, -2.6, -30.6);
    this.addSolid(2.6, -31.4, 3.4, -30.6);
    this.puffs.strand(-3, 5.8, -31, 3, 5.8, -31, 0.6);
    if (!daily) {
      const bg = new THREE.Group();
      const plane = new THREE.Mesh(
        new THREE.PlaneGeometry(4.6, 3.6),
        new THREE.MeshBasicMaterial({ color: 0xe63956, transparent: true, opacity: 0.4, side: THREE.DoubleSide })
      );
      plane.position.y = 2;
      bg.add(plane);
      const halo = glowSprite(0xff5d73, 6, 0.5);
      halo.position.y = 2;
      bg.add(halo);
      bg.position.set(0, 0, -31);
      S.add(bg);
      this.barrier = bg;
    } else {
      this.exit.unlocked = true;
      const beam = glowSprite(0x7ec8ff, 7, 0.6);
      beam.position.set(0, 2.5, -31);
      S.add(beam);
    }

    // ---- crate stack (parkour, east) ----
    const crate = (x: number, y: number, z: number, s: number) => {
      const c = makeCrate(s);
      c.position.set(x, y + s / 2, z);
      S.add(c);
      this.addTop(x - s / 2, z - s / 2, x + s / 2, z + s / 2, y + s);
    };
    crate(20, 0, 8, 1.3);
    crate(21.5, 0, 8.8, 1.3);
    crate(20.7, 1.3, 8.4, 1.0);
    crate(-24, 0, -20, 1.3);
    crate(30, 0, -2, 1.3);
    crate(30, 1.3, -2, 1.0);

    // ---- patrol carts (gentle movers — slower and slimmer now) ----
    const cartM = () => {
      const c = makeStall("#7a2bd0", "#ffe9c4");
      c.scale.setScalar(0.85);
      return c;
    };
    const sp = daily ? 3.4 : 2.4;
    this.addMover(cartM(), [{ x: 0, z: -24 }, { x: 0, z: 24 }], sp, 1.3, true);
    this.addMover(cartM(), [{ x: 18, z: -18 }, { x: 18, z: 18 }, { x: -18, z: 18 }, { x: -18, z: -18 }], daily ? 2.8 : 2.0, 1.3, true);

    // ---- pickups ----
    for (let z = -26; z <= 30; z += 8) this.addCollectible("modak", 0, 1.0, z);
    for (const [x, z] of [[-9.5, -10], [9.5, -2], [-9.5, 2], [9.5, 12], [-9.5, 24], [9.5, -22]] as const) {
      this.addCollectible("modak", x, 1.0, z);
    }
    for (const [x, z] of [[-28, -28], [-26, -30], [-30, -26], [28, 28], [26, 30], [30, 26], [-28, 30], [28, -30], [-32, 8], [32, -10]] as const) {
      this.addCollectible("flower", x, 0.9, z);
    }
    this.addCollectible("token", 3.5, 1.2, -33);
    this.addCollectible("token", -15, 1.0, 11.5);
    this.addCollectible("token", -34, 1.0, -28);
    this.addCollectible("token", 20.7, 2.9, 8.4);
    for (const [x, z] of [[-3.4, 20], [3.4, 20], [-3.4, -14], [3.4, -14], [-3.6, -31], [3.6, -31]] as const) {
      this.addCollectible("diya", x, 1.1, z);
    }

    if (!daily) {
      // ---- 3 fragments placed near the main path (any 2 open the gate) ----
      this.addCollectible("fragment", 20.7, 3.1, 8.4); // atop crates
      this.addCollectible("fragment", -8, 1.2, -30); // west of the gate path
      this.addCollectible("fragment", 12, 1.2, -18); // east plaza, easy to spot
    } else {
      // daily: extra modaks everywhere
      const spots: [number, number][] = [
        [-20, -24], [-12, -30], [12, -28], [24, -14], [-26, -6], [26, 4],
        [-18, 14], [18, 26], [-6, 30], [8, -36], [-34, 20], [34, 14],
        [-4, -8], [4, -2], [-24, 28], [24, -34],
      ];
      for (const [x, z] of spots) this.addCollectible("modak", x, 1.0, z);
    }
  }

  protected hookUpdate(_dt: number): void {
    if (this.barrier) {
      this.barrier.rotation.y += _dt * 0.4;
      const s = 1 + Math.sin(this.t * 3) * 0.03;
      this.barrier.scale.set(s, 1, s);
    }
  }

  protected progress01(): number {
    if (this.opts.daily) {
      return Math.min(1, this.modaks / Math.max(1, this.opts.daily.goalModaks));
    }
    return Math.min(1, this.fragments / 2);
  }

  protected onFragment(): void {
    const f = this.fragments;
    if (f >= 2) {
      this.exit.unlocked = true;
      if (this.barrier) this.barrier.visible = false;
      this.objective = "All fragments found — reach the glowing gate!";
      if (f === 2) {
        this.say("The gate is open! Go north! 🙏");
        audio.playSuccess();
      } else {
        this.say("Bonus fragment! Extra score! ✨");
      }
    } else {
      this.objective = `Find 2 Modak fragments — follow the golden beams! (${f}/2)`;
      this.say(`Fragment ${f}/2 found!`);
    }
  }

  protected onModak(): void {
    const d = this.opts.daily;
    if (d && this.modaks >= d.goalModaks && this.state === "playing") {
      this.win("CHALLENGE COMPLETE! 🎉");
    }
  }

  protected onTimeUp(): void {
    const d = this.opts.daily;
    if (d && this.modaks >= d.goalModaks) this.win("CHALLENGE COMPLETE! 🎉");
    else this.lose("Time's up!");
  }

  protected onEnterExit(): void {
    if (!this.opts.daily) this.win("STREET CLEARED — MORYA! 🎉");
  }
}
