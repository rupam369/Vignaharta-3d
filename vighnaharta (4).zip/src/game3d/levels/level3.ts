// ============================================================
// LEVEL 3 — MONSOON GHAT (3D)
// Swim the rain river, hop slippery platforms, ride boats.
// Catch 8 floating diyas, then reach the pavilion.
// ============================================================
import * as THREE from "three";
import { audio } from "../../game/audio";
import type { MusicMode } from "../../game/audio";
import { LevelBase } from "../levelbase";
import { SLIPPERY_MOVE } from "../player";
import { RainSystem } from "../particles3d";
import {
  glowSprite, makeArchGate, makeBoat, makeBuilding, makeGround, makeLampPost,
  makePuddle, makeTempleFacade, makeTree, std, waterTexture,
} from "../art";

export class Level3Ghat extends LevelBase {
  protected musicMode: MusicMode = "ghat";
  private diyasNeeded = 8;
  private waterTex: THREE.CanvasTexture | null = null;
  private flashDiv: HTMLDivElement | null = null;
  private flashA = 0;
  private nextBolt = 6;
  private barrier: THREE.Object3D | null = null;
  private walkBase = 0;
  private rippleT = 0;
  private wasSwim = false;

  protected nightOpts(): Record<string, number> {
    return { fogColor: 0x0c1430, fogNear: 16, fogFar: 95 };
  }

  protected onBuild(): void {
    const S = this.core.scene;
    this.player.params = { ...SLIPPERY_MOVE };
    this.setBounds(-13, 13, -69, 29);
    this.setSpawn(0, 0, 25, Math.PI);
    this.objective = `Swim + hop, catch 8 floating diyas (0/${this.diyasNeeded})`;
    // swim level over the river with smooth beaches at both lands
    this.groundFn = (_x, z) => {
      if (z >= 11) return 0;
      if (z <= -55) return 0;
      if (z > 9) return -1.05 + 1.05 * (z - 9) / 2;
      if (z < -53) return -1.05 * (z + 55) / 2;
      return -1.05;
    };

    S.add(makeGround(160, 200, 0x101a38));

    // ---- river ----
    this.waterTex = waterTexture();
    this.waterTex.repeat.set(4, 6);
    const water = new THREE.Mesh(
      new THREE.PlaneGeometry(60, 120),
      new THREE.MeshStandardMaterial({
        map: this.waterTex, color: 0x9fc8ff, roughness: 0.25, metalness: 0.6,
        transparent: true, opacity: 0.94,
      })
    );
    water.rotation.x = -Math.PI / 2;
    water.position.set(0, -1.2, -22);
    S.add(water);

    // ---- start + end land ----
    const stone = std(0x4a4468, 0.85);
    const land1 = new THREE.Mesh(new THREE.BoxGeometry(30, 2, 20), stone);
    land1.position.set(0, -1, 21);
    land1.receiveShadow = true;
    S.add(land1);
    const land2 = new THREE.Mesh(new THREE.BoxGeometry(30, 2, 16), stone);
    land2.position.set(0, -1, -63);
    land2.receiveShadow = true;
    S.add(land2);

    // ---- ghat steps (banks, visual + solid walls) ----
    for (const side of [-1, 1]) {
      for (let i = 0; i < 3; i++) {
        const st = new THREE.Mesh(new THREE.BoxGeometry(2.4, 1.1, 110), std(0x37335a, 0.9));
        st.position.set(side * (10.6 + i * 2.2), 0.9 - i * 0.9, -20);
        st.receiveShadow = true;
        S.add(st);
      }
      this.addSolid(side > 0 ? 9.2 : -14, -70, side > 0 ? 14 : -9.2, 30);
      for (const z of [-50, -30, -10, 10, 24]) {
        const l = makeLampPost(3.4);
        l.position.set(side * 10.4, 1.45, z);
        S.add(l);
      }
    }

    // ---- stone platforms (gaps tuned to jump range — all hops easy) ----
    const plats: [number, number][] = [
      [-2.5, 7], [2.5, 2], [-2.5, -3.5], [2, -9], [-2.5, -19.5],
      [2.5, -25], [0, -35.5], [-2.5, -41], [2.5, -46.5], [0, -52],
    ];
    for (const [x, z] of plats) {
      const p = new THREE.Mesh(new THREE.BoxGeometry(3.4, 1.2, 3.4), stone);
      p.position.set(x, -0.2, z);
      p.castShadow = true;
      p.receiveShadow = true;
      S.add(p);
      const moss = new THREE.Mesh(new THREE.BoxGeometry(3.44, 0.1, 3.44), std(0x2f9e6e, 0.95));
      moss.position.set(x, 0.42, z);
      S.add(moss);
      this.addTop(x - 1.7, z - 1.7, x + 1.7, z + 1.7, 0.47);
    }

    // ---- moving boats (rideable stepping stones) ----
    const boatA = makeBoat();
    this.addMover(boatA, [{ x: -5, z: -14.5 }, { x: 5, z: -14.5 }], 1.7, 1.9, false, 0.75);
    const boatB = makeBoat();
    this.addMover(boatB, [{ x: 5, z: -31 }, { x: -5, z: -31 }], 2.0, 1.9, false, 0.75);

    // ---- pavilion + exit (north) ----
    const pav = makeTempleFacade(10, 7);
    pav.position.set(0, 0, -73);
    S.add(pav);
    const exit = makeArchGate(5, 4.4);
    exit.position.set(0, 0, -63);
    S.add(exit);
    this.setExit(0, -63, 2.4);
    this.addSolid(-2.9, -63.4, -2.1, -62.6);
    this.addSolid(2.1, -63.4, 2.9, -62.6);
    this.core.addDiyaLight(0, 4, -62, 0xffc87a, 24, 22);
    const bp = new THREE.Mesh(
      new THREE.PlaneGeometry(4, 3.2),
      new THREE.MeshBasicMaterial({ color: 0x7ec8ff, transparent: true, opacity: 0.4, side: THREE.DoubleSide })
    );
    bp.position.set(0, 1.9, -63);
    S.add(bp);
    this.barrier = bp;
    this.puffs.strand(-2.5, 5, -63, 2.5, 5, -63, 0.5);

    // ---- checkpoints ----
    this.addCheckpoint(-2.5, -19.5, "Mid-river rest", 2.4, 0.47);
    this.addCheckpoint(0, -52, "Far bank", 2.4, 0.47);
    // (checkpoint flags)
    for (const [x, z] of [[-4.1, -19.5], [1.6, -52]] as const) {
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.08, 3, 8), std(0x3a2c18, 0.9));
      pole.position.set(x, 1.9, z);
      S.add(pole);
      const flag = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.5, 0.05), std(0xff7a1a, 0.8));
      flag.position.set(x + 0.45, 3.1, z);
      S.add(flag);
    }

    // ---- trees + buildings + bunting + diyas ----
    for (const [x, z] of [[-11, 26], [11, 26], [-11, -60], [11, -60]] as const) {
      const t = makeTree(1);
      t.position.set(x, 1.4, z);
      S.add(t);
    }
    for (const [x, z] of [[-24, 20], [24, 20], [-24, -60], [24, -60], [0, -84]] as const) {
      const b = makeBuilding(12, 9, 10);
      b.position.set(x, 0, z);
      S.add(b);
    }
    for (const z of [-46, -28, -10, 4]) {
      this.buntings.span(-9, 6.6, z, 9, 6.6, z, 1.3, 10);
    }
    for (let z = 14; z <= 28; z += 3.5) {
      this.diyas.add(-6.5, 0.02, z, 1);
      this.diyas.add(6.5, 0.02, z + 1.7, 1);
    }
    for (let z = -68; z <= -58; z += 3.5) {
      this.diyas.add(-6.5, 0.02, z, 1);
      this.diyas.add(6.5, 0.02, z + 1.7, 1);
    }
    this.core.addDiyaLight(0, 3.5, 22, 0xffb45e, 16, 16);

    // ---- puddles ----
    for (const [x, z] of [[-4, 18], [5, 24], [-5, -60], [4, -66]] as const) {
      const puddle = makePuddle(1.5);
      puddle.position.set(x, 0.02, z);
      S.add(puddle);
    }

    // ---- floating diyas (10 along the path, need 8 — grab by swimming!) ----
    const floats: [number, number][] = [
      [-1, 9], [0, 4.5], [0, -1], [-0.5, -6.5], [0.5, -12],
      [-1, -17.5], [0, -22.5], [1, -28.5], [0, -33.5], [-1.5, -38.5],
    ];
    for (const [x, z] of floats) {
      this.addCollectible("diya", x, 0.8, z);
      this.moteList.push({ x, y: 1.15, z, size: 1.6, color: 0xffb45e });
    }

    // ---- bonus pickups ----
    this.addCollectible("modak", -2.5, 1.4, -3.5);
    this.addCollectible("modak", -2.5, 1.4, -19.5);
    this.addCollectible("modak", 0, 1.4, -35.5);
    this.addCollectible("modak", 2, 1.1, 20);
    this.addCollectible("token", -2.5, 1.4, -41);
    this.addCollectible("token", 5, 1.1, -61);
    for (const [x, z] of [[-8, 16], [8, 26], [-8, -58], [8, -68]] as const) {
      this.addCollectible("flower", x, 0.9, z);
    }
    // farewell diyas at pavilion
    this.addCollectible("diya", -3, 1.1, -63);
    this.addCollectible("diya", 3, 1.1, -63);

    // ---- rain + ambience ----
    this.rain = new RainSystem(S, 700);
    audio.startAmbience("rain");

    // lightning flash veil
    this.flashDiv = document.createElement("div");
    this.flashDiv.className = "bolt-veil";
    this.opts.overlay.appendChild(this.flashDiv);
  }

  protected hookUpdate(dt: number): void {
    // flowing water
    if (this.waterTex) this.waterTex.offset.y -= dt * 0.06;

    // lightning
    this.nextBolt -= dt;
    if (this.nextBolt <= 0 && this.state === "playing") {
      this.nextBolt = 8 + Math.random() * 8;
      this.flashA = 0.55;
      audio.playThunder();
    }
    if (this.flashA > 0) {
      this.flashA = Math.max(0, this.flashA - dt * 1.6);
      if (this.flashDiv) this.flashDiv.style.opacity = String(this.flashA);
    }

    // ---- swimming ----
    if (this.state === "playing") {
      const p = this.player.pos;
      const swimming = p.z < 11 && p.z > -55 && p.y < -0.3;
      // paddle speed in water (restored on land)
      if (!this.walkBase) this.walkBase = this.player.params.baseSpeed ?? this.player.params.maxSpeed;
      this.player.params.baseSpeed = this.walkBase * (swimming ? 0.55 : 1);
      if (swimming && !this.wasSwim) this.say("Swimming! Paddle to the glowing diyas! 🏊");
      this.wasSwim = swimming;
      if (swimming) {
        // ripple splash
        this.rippleT -= dt;
        if (this.rippleT <= 0) {
          this.rippleT = 0.28;
          this.sparks.burst(p.x, -0.9, p.z, 3, [0x7ec8ff, 0xcfe8ff], 1.4);
        }
        // swim into a platform to clamber out
        for (const t of this.tops) {
          if (p.x > t.minX - 0.4 && p.x < t.maxX + 0.4 && p.z > t.minZ - 0.4 && p.z < t.maxZ + 0.4) {
            if (p.y < t.topY) {
              p.y = Math.min(t.topY, p.y + 2.5 * dt);
              this.player.vel.y = 0;
            }
          }
        }
      }
      // safety net (should never trigger)
      if (p.y < -2.4) {
        p.set(this.respawn.x, this.respawn.y + 0.5, this.respawn.z);
        this.player.vel.set(0, 0, 0);
      }
    }
  }

  protected onDiya(): void {
    if (this.diyaCount >= this.diyasNeeded && !this.exit.unlocked) {
      this.exit.unlocked = true;
      if (this.barrier) this.barrier.visible = false;
      this.objective = "All diyas caught — reach the pavilion! 🪔";
      this.say("The pavilion glows — go north!");
      audio.playSuccess();
    } else if (!this.exit.unlocked) {
      this.objective = `Catch 8 floating diyas (${Math.min(this.diyaCount, 8)}/${this.diyasNeeded})`;
    }
  }

  protected progress01(): number {
    const swim = Math.min(1, (26 - this.player.pos.z) / 90);
    return Math.min(1, (this.diyaCount / this.diyasNeeded) * 0.75 + swim * 0.25);
  }

  protected onEnterExit(): void {
    this.win("THE GHAT IS CROSSED! 🌧️");
  }
}
