// ============================================================
// Core3D — renderer / scene / night light-rig / shadows / fog.
// Bright festive night (never pitch-dark): strong moon with
// shadows, warm sky fill, a lantern glued to the player,
// capped diya points + emissive sprites (perf-safe).
// ============================================================
import * as THREE from "three";

export interface NightOpts {
  fogColor?: number;
  fogNear?: number;
  fogFar?: number;
  moonIntensity?: number;
  hemiIntensity?: number;
  shadowExtent?: number;
  maxDiyaLights?: number;
  /** warm lantern glow that travels with the player */
  lantern?: number;
  lanternColor?: number;
}

const MAX_DIYA_DEFAULT = 7;

export function isCoarsePointer(): boolean {
  try {
    return typeof window !== "undefined" &&
      !!window.matchMedia &&
      window.matchMedia("(pointer: coarse)").matches;
  } catch {
    return false;
  }
}

export class Core3D {
  renderer: THREE.WebGLRenderer;
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  canvas: HTMLCanvasElement;
  maxDiyaLights: number;

  private hemi!: THREE.HemisphereLight;
  private moon!: THREE.DirectionalLight;
  private moonTarget!: THREE.Object3D;
  private lantern: THREE.PointLight | null = null;
  private diyaCount = 0;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: "high-performance" });
    const cap = isCoarsePointer() ? 1.5 : 2;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, cap));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.32;
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(58, 1, 0.1, 400);
    this.maxDiyaLights = MAX_DIYA_DEFAULT;
    this.resize();
  }

  setupNight(o: NightOpts = {}): void {
    const fogColor = o.fogColor ?? 0x131a45;
    this.scene.background = new THREE.Color(0x0b1132);
    this.scene.fog = new THREE.Fog(fogColor, o.fogNear ?? 30, o.fogFar ?? 140);
    this.maxDiyaLights = o.maxDiyaLights ?? MAX_DIYA_DEFAULT;

    // generous warm skylight — a bright festive night, never muddy
    this.hemi = new THREE.HemisphereLight(0x6f80d8, 0x3a2a4a, o.hemiIntensity ?? 0.95);
    this.scene.add(this.hemi);

    this.moon = new THREE.DirectionalLight(0xcfd8ff, o.moonIntensity ?? 1.05);
    this.moon.castShadow = true;
    const ext = o.shadowExtent ?? 38;
    this.moon.shadow.mapSize.set(1024, 1024);
    this.moon.shadow.camera.left = -ext;
    this.moon.shadow.camera.right = ext;
    this.moon.shadow.camera.top = ext;
    this.moon.shadow.camera.bottom = -ext;
    this.moon.shadow.camera.near = 1;
    this.moon.shadow.camera.far = 120;
    this.moon.shadow.bias = -0.0004;
    this.moon.shadow.normalBias = 0.03;
    this.moonTarget = new THREE.Object3D();
    this.scene.add(this.moonTarget);
    this.moon.target = this.moonTarget;
    this.scene.add(this.moon);

    // warm lantern that travels with the player (1 cheap light, no shadow)
    this.lantern = new THREE.PointLight(o.lanternColor ?? 0xffb45e, o.lantern ?? 13, 22, 2);
    this.scene.add(this.lantern);

    this.followShadow(new THREE.Vector3(0, 0, 0));
  }

  /** keep the shadow frustum + lantern glued to the player */
  followShadow(p: THREE.Vector3): void {
    if (!this.moon) return;
    this.moon.position.set(p.x + 20, 34, p.z + 12);
    this.moonTarget.position.set(p.x, 0, p.z);
    if (this.lantern) this.lantern.position.set(p.x, p.y + 3.4, p.z);
  }

  /** pooled warm point light; returns null once the cap is hit */
  addDiyaLight(x: number, y: number, z: number, color = 0xffb45e, intensity = 16, dist = 15): THREE.PointLight | null {
    if (this.diyaCount >= this.maxDiyaLights) return null;
    this.diyaCount++;
    const l = new THREE.PointLight(color, intensity, dist, 2);
    l.position.set(x, y, z);
    this.scene.add(l);
    return l;
  }

  resize(): void {
    const w = this.canvas.clientWidth || window.innerWidth;
    const h = this.canvas.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / Math.max(1, h);
    this.camera.updateProjectionMatrix();
  }

  render(): void {
    this.renderer.render(this.scene, this.camera);
  }

  dispose(): void {
    disposeScene(this.scene);
    this.renderer.dispose();
  }
}

/** frees GPU memory so level switches never leak */
export function disposeScene(scene: THREE.Scene): void {
  scene.traverse((obj) => {
    const mesh = obj as THREE.Mesh;
    if (mesh.geometry) mesh.geometry.dispose();
    const mat = (mesh as THREE.Mesh).material as THREE.Material | THREE.Material[] | undefined;
    if (Array.isArray(mat)) {
      for (const m of mat) disposeMaterial(m);
    } else if (mat) {
      disposeMaterial(mat);
    }
  });
}

function disposeMaterial(m: THREE.Material): void {
  const withMaps = m as THREE.Material & { map?: THREE.Texture | null };
  if (withMaps.map) withMaps.map.dispose();
  m.dispose();
}
