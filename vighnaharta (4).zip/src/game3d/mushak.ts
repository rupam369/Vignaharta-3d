// ============================================================
// Mushak — procedural low-poly 3D mouse character.
// Body / head / ears / eyes / tail / legs / saffron scarf.
// Anim states: idle · move · jump · hit · celebrate.
// ============================================================
import * as THREE from "three";

export type MushakAnim = "idle" | "move" | "jump" | "hit" | "celebrate";

const FUR = 0x8b95c4;
const FUR_DARK = 0x6d76a3;
const BELLY = 0xe6ebff;
const PINK = 0xffb3c1;

export class Mushak {
  group: THREE.Group;
  private legFL: THREE.Mesh;
  private legFR: THREE.Mesh;
  private legBL: THREE.Mesh;
  private legBR: THREE.Mesh;
  private tail: THREE.Group;
  private earL: THREE.Mesh;
  private earR: THREE.Mesh;
  private body: THREE.Mesh;
  private scarf1: THREE.Mesh;
  private scarf2: THREE.Mesh;
  private headG: THREE.Group;
  private phase = 0;
  private hitT = 0;
  private mats: THREE.MeshStandardMaterial[] = [];

  constructor() {
    const g = new THREE.Group();
    const mat = (c: number, e = 0, ei = 0): THREE.MeshStandardMaterial => {
      const m = new THREE.MeshStandardMaterial({ color: c, roughness: 0.75, metalness: 0.05 });
      if (e) {
        m.emissive = new THREE.Color(e);
        m.emissiveIntensity = ei;
      }
      this.mats.push(m);
      return m;
    };
    const fur = mat(FUR);
    const furD = mat(FUR_DARK);
    const bellyM = mat(BELLY);
    const pinkM = mat(PINK);
    const darkM = mat(0x141a33, 0x000000, 0);
    const goldM = mat(0xf5b942, 0x664400, 0.25);
    const saffronM = mat(0xff7a1a, 0x661f00, 0.3);

    const S = (geo: THREE.BufferGeometry, m: THREE.Material, x = 0, y = 0, z = 0): THREE.Mesh => {
      const ms = new THREE.Mesh(geo, m);
      ms.position.set(x, y, z);
      ms.castShadow = true;
      return ms;
    };

    // body (elongated dome)
    this.body = S(new THREE.SphereGeometry(0.42, 20, 16), fur, 0, 0.62, 0);
    this.body.scale.set(1, 0.95, 1.25);
    g.add(this.body);
    // belly patch
    const belly = S(new THREE.SphereGeometry(0.3, 16, 12), bellyM, 0, 0.55, 0.22);
    belly.scale.set(0.85, 0.9, 0.9);
    g.add(belly);

    // head group (front = +Z)
    this.headG = new THREE.Group();
    this.headG.position.set(0, 1.0, 0.38);
    const head = S(new THREE.SphereGeometry(0.3, 20, 16), fur);
    this.headG.add(head);
    const snout = S(new THREE.SphereGeometry(0.16, 14, 12), fur, 0, -0.06, 0.24);
    snout.scale.set(1, 0.85, 1);
    this.headG.add(snout);
    this.headG.add(S(new THREE.SphereGeometry(0.055, 10, 8), pinkM, 0, -0.04, 0.4));
    // eyes
    for (const sx of [-1, 1]) {
      const eye = S(new THREE.SphereGeometry(0.07, 10, 8), darkM, sx * 0.14, 0.08, 0.24);
      this.headG.add(eye);
      const glint = new THREE.Mesh(
        new THREE.SphereGeometry(0.022, 6, 6),
        new THREE.MeshBasicMaterial({ color: 0xffffff })
      );
      glint.position.set(sx * 0.14 + 0.025, 0.105, 0.3);
      this.headG.add(glint);
    }
    // tilak
    const tilak = S(new THREE.SphereGeometry(0.04, 8, 8), mat(0xe63956, 0x550000, 0.4), 0, 0.22, 0.2);
    tilak.scale.set(0.8, 1.2, 0.6);
    this.headG.add(tilak);
    // ears
    const earGeo = new THREE.SphereGeometry(0.16, 14, 12);
    this.earL = S(earGeo, fur, -0.2, 0.32, -0.02);
    this.earL.scale.set(1, 1, 0.45);
    this.earR = S(earGeo.clone(), fur, 0.2, 0.32, -0.02);
    this.earR.scale.set(1, 1, 0.45);
    this.headG.add(this.earL, this.earR);
    const innerGeo = new THREE.SphereGeometry(0.08, 10, 8);
    const inL = S(innerGeo, pinkM, -0.2, 0.32, 0.05);
    inL.scale.set(1, 1, 0.4);
    const inR = S(innerGeo.clone(), pinkM, 0.2, 0.32, 0.05);
    inR.scale.set(1, 1, 0.4);
    this.headG.add(inL, inR);
    g.add(this.headG);

    // gold collar + saffron scarf ribbons (trail behind, -Z)
    const collar = S(new THREE.TorusGeometry(0.24, 0.055, 8, 18), goldM, 0, 0.82, 0.3);
    collar.rotation.x = Math.PI / 2 - 0.35;
    g.add(collar);
    const ribGeo = new THREE.BoxGeometry(0.12, 0.03, 0.5);
    this.scarf1 = S(ribGeo, saffronM, -0.1, 0.82, -0.05);
    this.scarf2 = S(ribGeo.clone(), saffronM, 0.1, 0.8, -0.05);
    g.add(this.scarf1, this.scarf2);

    // tail (curved tube, wagged at runtime)
    this.tail = new THREE.Group();
    this.tail.position.set(0, 0.55, -0.5);
    const curve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, 0, 0),
      new THREE.Vector3(-0.18, -0.05, -0.3),
      new THREE.Vector3(-0.3, 0.12, -0.55),
      new THREE.Vector3(-0.22, 0.3, -0.72),
    ]);
    const tailMesh = new THREE.Mesh(new THREE.TubeGeometry(curve, 12, 0.045, 8), furD);
    tailMesh.castShadow = true;
    this.tail.add(tailMesh);
    g.add(this.tail);

    // legs
    const legGeo = new THREE.CylinderGeometry(0.09, 0.11, 0.42, 10);
    const mkLeg = (x: number, z: number): THREE.Mesh => {
      const pivot = new THREE.Group();
      pivot.position.set(x, 0.42, z);
      const m = S(legGeo, furD, 0, -0.18, 0);
      pivot.add(m);
      g.add(pivot);
      // return pivot disguised as mesh for rotation API
      return pivot as unknown as THREE.Mesh;
    };
    this.legFL = mkLeg(-0.22, 0.28);
    this.legFR = mkLeg(0.22, 0.28);
    this.legBL = mkLeg(-0.22, -0.3);
    this.legBR = mkLeg(0.22, -0.3);

    this.group = g;
  }

  hitFlash(): void {
    this.hitT = 0.5;
  }

  update(dt: number, t: number, speed: number, grounded: boolean, anim: MushakAnim): void {
    this.phase += dt * (4 + speed * 2.4);
    const p = this.phase;
    const running = speed > 0.6 && grounded;

    // legs
    if (!grounded) {
      // tucked jump pose
      this.legFL.rotation.x = -0.7;
      this.legFR.rotation.x = -0.7;
      this.legBL.rotation.x = 0.55;
      this.legBR.rotation.x = 0.55;
    } else if (running) {
      const s = Math.sin(p) * 0.85;
      this.legFL.rotation.x = s;
      this.legBR.rotation.x = s;
      this.legFR.rotation.x = -s;
      this.legBL.rotation.x = -s;
    } else {
      this.legFL.rotation.x *= 0.85;
      this.legFR.rotation.x *= 0.85;
      this.legBL.rotation.x *= 0.85;
      this.legBR.rotation.x *= 0.85;
    }

    // body bob / squash
    if (!grounded) {
      this.body.scale.set(1, 1.02, 1.3);
      this.body.position.y = 0.66;
    } else if (running) {
      const b = Math.abs(Math.sin(p)) * 0.06;
      this.body.scale.set(1, 0.95, 1.25);
      this.body.position.y = 0.62 + b;
    } else {
      // idle breathing
      const br = Math.sin(t * 2.2) * 0.018;
      this.body.scale.set(1 + br, 0.95 - br, 1.25);
      this.body.position.y = 0.62 + Math.sin(t * 2.2) * 0.012;
    }

    // head look + ear wiggle
    this.headG.rotation.x = !grounded ? -0.18 : running ? Math.sin(p) * 0.05 : Math.sin(t * 1.3) * 0.06;
    const wig = running ? Math.sin(p * 1.5) * 0.1 : Math.sin(t * 3) * 0.04;
    this.earL.rotation.z = 0.15 + wig;
    this.earR.rotation.z = -0.15 - wig;

    // tail wag
    this.tail.rotation.y = Math.sin(t * (running ? 9 : 4)) * (running ? 0.35 : 0.18);
    this.tail.rotation.x = !grounded ? -0.3 : 0;

    // scarf flutter (streams with speed)
    const fl = Math.sin(t * (6 + speed * 2)) * 0.16;
    const lift = Math.min(0.5, speed * 0.09);
    this.scarf1.rotation.x = -0.5 - lift + fl;
    this.scarf2.rotation.x = -0.45 - lift - fl;
    this.scarf1.rotation.y = 0.15 + fl * 0.5;
    this.scarf2.rotation.y = -0.15 - fl * 0.5;

    // celebrate: happy bounce + spin handled by level (yaw), bounce here
    if (anim === "celebrate") {
      this.group.position.y += Math.abs(Math.sin(t * 7)) * 0.02;
      this.headG.rotation.x = -0.35;
    }

    // hit flash (red emissive pulse)
    if (this.hitT > 0) {
      this.hitT -= dt;
      const k = Math.max(0, this.hitT) * 2;
      for (const m of this.mats) {
        m.emissive.setRGB(0.55 * k, 0.06 * k, 0.08 * k);
      }
    } else if (anim === "hit") {
      for (const m of this.mats) m.emissive.setRGB(0.3, 0.03, 0.04);
    } else {
      for (const m of this.mats) {
        // restore only flash-tinted mats (gold/saffron/tilak keep theirs)
        if (m.emissiveIntensity === 0 && m.color.getHex() !== 0xf5b942 && m.color.getHex() !== 0xff7a1a && m.color.getHex() !== 0xe63956) {
          m.emissive.setRGB(0, 0, 0);
        }
      }
    }
  }
}
