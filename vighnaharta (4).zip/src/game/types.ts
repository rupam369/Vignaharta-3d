// ============================================================
// VIGHNAHARTA — THE LOST MODAK · shared types & constants
// ============================================================

export type WorldId = 1 | 2 | 3 | 4 | 5;
export type PlayId = WorldId | "daily";
export type Screen = "title" | "story" | "map" | "game";

export interface Settings {
  sound: boolean;
  music: boolean;
  reducedMotion: boolean;
  highContrast: boolean;
  playerName: string;
  masterVolume: number;
  musicVolume: number;
  sfxVolume: number;
}

export interface HudState {
  score: number;
  combo: number;
  comboMult: number;
  distance: number;
  goalDistance: number;
  modaks: number;
  diyas: number;
  hearts: number;
  maxHearts: number;
  /** 0..1 overall level progress */
  progress: number;
  /** seconds remaining (daily challenge) */
  timer?: number;
  /** transient banner text, e.g. "CHECKPOINT!" */
  message?: string;
  messageKey?: number;
  /** current phase label, e.g. "Phase 2 · Timing" */
  phase?: string;
  /** accuracy 0..1 for puzzle worlds */
  accuracy?: number;
  /** 3D: current interact prompt (null = hidden) */
  prompt?: string | null;
  /** 3D: level uses the INTERACT button */
  interact?: boolean;
}

export interface LevelResult {
  worldId: PlayId;
  victory: boolean;
  score: number;
  best: number;
  isNewBest: boolean;
  modaks: number;
  diyas: number;
  distance: number;
  maxCombo: number;
  accuracy: number;
  heartsLeft: number;
  damageTaken: number;
  stars: number;
}

export interface WorldBest {
  stars: number;
  bestScore: number;
  bestCombo: number;
  modaks: number;
  completed: boolean;
}

export interface Progress {
  unlockedWorld: number; // 1..5
  worlds: Record<string, WorldBest>;
  totalModaks: number;
  totalDiyas: number;
  achievements: string[];
  dailyBest: Record<string, number>;
  settings: Settings;
  seenIntro: boolean;
  hasPlayed: boolean;
}

export interface AchievementDef {
  id: string;
  name: string;
  desc: string;
  icon: string;
}

export const ACHIEVEMENTS: AchievementDef[] = [
  { id: "first_modak", name: "First Modak", desc: "Collect your first Modak", icon: "🍬" },
  { id: "perfect_rangoli", name: "Perfect Rangoli", desc: "Complete a Rangoli with 100% accuracy", icon: "🌸" },
  { id: "light_the_night", name: "Light the Night", desc: "Light 20 diyas across journeys", icon: "🪔" },
  { id: "master_streets", name: "Master of the Streets", desc: "Finish Festival Streets with full hearts", icon: "🏮" },
  { id: "no_miss", name: "No Miss Run", desc: "Finish a runner world without damage", icon: "✨" },
  { id: "combo_master", name: "Combo Master", desc: "Reach a x5 combo multiplier", icon: "🔥" },
  { id: "explorer", name: "Festival Explorer", desc: "Unlock all five worlds", icon: "🗺️" },
  { id: "vighnaharta", name: "Vighnaharta", desc: "Recover the Lost Modak", icon: "🙏" },
];

export interface WorldMeta {
  id: WorldId;
  name: string;
  tag: string;
  desc: string;
  icon: string;
  controlHint: string;
}

export const WORLD_META: WorldMeta[] = [
  {
    id: 1,
    name: "Festival Streets",
    tag: "Explore · Light · Climb",
    desc: "Wander the moonlit bazaar. Find 2 brass fragments, light festival diyas, and climb the flag-steps.",
    icon: "🏮",
    controlHint: "WASD / joystick · Space jump · drag to look",
  },
  {
    id: 2,
    name: "Rangoli Courtyard",
    tag: "Memory · Pattern",
    desc: "Bloom the sacred rangoli. Walk to the glowing flames and light them in the order shown.",
    icon: "🌸",
    controlHint: "Walk up + E / tap flames in order",
  },
  {
    id: 3,
    name: "Monsoon Ghat",
    tag: "Platforms · Rain",
    desc: "Swim the moonlit river, hop stones and ride boats. Catch 8 floating diyas — falling in never hurts!",
    icon: "🌧️",
    controlHint: "WASD · swim · hop · catch!",
  },
  {
    id: 4,
    name: "Temple Courtyard",
    tag: "Memory · Harmony",
    desc: "STEP 1: replay the north diya order. STEP 2: tap the 3 east chakras till ALIGNED. STEP 3: enter the glowing east gate!",
    icon: "🛕",
    controlHint: "Follow the marker · E / tap",
  },
  {
    id: 5,
    name: "Grand Finale",
    tag: "Everything · Celebration",
    desc: "One final journey through all you learned. Bring the Lost Modak home to Bappa.",
    icon: "🎆",
    controlHint: "Explore · light · unlock · celebrate",
  },
];

export const STORY_LINES: string[] = [
  "Tonight, the final offering was prepared…",
  "Rows of diyas. Fresh marigold. Sweet modaks.",
  "But something is missing.",
  "A single Modak — the special one for Bappa — is gone!",
  "A trail of flower petals leads into the festival night…",
  "Mushak, the journey begins.",
];
