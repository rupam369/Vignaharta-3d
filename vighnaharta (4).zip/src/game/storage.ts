// ============================================================
// Persistent progression via localStorage
// ============================================================
import type { LevelResult, Progress, Settings, WorldBest } from "./types";

const SAVE_KEY = "vighnaharta-save-v1";

export const DEFAULT_SETTINGS: Settings = {
  sound: true,
  music: true,
  reducedMotion: false,
  highContrast: false,
  playerName: "",
  masterVolume: 90,
  musicVolume: 70,
  sfxVolume: 80,
};

function blankWorld(): WorldBest {
  return { stars: 0, bestScore: 0, bestCombo: 0, modaks: 0, completed: false };
}

export function defaultProgress(): Progress {
  return {
    unlockedWorld: 1,
    worlds: { "1": blankWorld(), "2": blankWorld(), "3": blankWorld(), "4": blankWorld(), "5": blankWorld() },
    totalModaks: 0,
    totalDiyas: 0,
    achievements: [],
    dailyBest: {},
    settings: { ...DEFAULT_SETTINGS },
    seenIntro: false,
    hasPlayed: false,
  };
}

export function loadProgress(): Progress {
  const base = defaultProgress();
  try {
    if (typeof window === "undefined") return base;
    const raw = window.localStorage.getItem(SAVE_KEY);
    if (!raw) return base;
    const data = JSON.parse(raw) as Partial<Progress>;
    return {
      ...base,
      ...data,
      worlds: { ...base.worlds, ...(data.worlds ?? {}) },
      settings: { ...base.settings, ...(data.settings ?? {}) },
      dailyBest: { ...(data.dailyBest ?? {}) },
      achievements: Array.isArray(data.achievements) ? data.achievements : [],
    };
  } catch {
    return base;
  }
}

export function saveProgress(p: Progress): void {
  try {
    if (typeof window === "undefined") return;
    window.localStorage.setItem(SAVE_KEY, JSON.stringify(p));
  } catch {
    /* storage unavailable — game still works for the session */
  }
}

export function resetProgress(): Progress {
  const fresh = defaultProgress();
  saveProgress(fresh);
  return fresh;
}

/** Merge a finished run into progression. Returns updated progress + whether a new world unlocked. */
export function recordLevelResult(
  prev: Progress,
  result: LevelResult
): { progress: Progress; newlyUnlocked: number | null } {
  const progress: Progress = {
    ...prev,
    worlds: { ...prev.worlds },
    dailyBest: { ...prev.dailyBest },
    hasPlayed: true,
    totalModaks: prev.totalModaks + result.modaks,
    totalDiyas: prev.totalDiyas + result.diyas,
  };

  let newlyUnlocked: number | null = null;

  if (result.worldId === "daily") {
    const key = todayKey();
    const old = progress.dailyBest[key] ?? 0;
    if (result.score > old) progress.dailyBest[key] = result.score;
    return { progress, newlyUnlocked };
  }

  const id = String(result.worldId);
  const old = progress.worlds[id] ?? blankWorld();
  const stars = Math.max(old.stars, result.stars);
  progress.worlds[id] = {
    stars,
    bestScore: Math.max(old.bestScore, result.score),
    bestCombo: Math.max(old.bestCombo, result.maxCombo),
    modaks: old.modaks + result.modaks,
    completed: old.completed || result.victory,
  };

  if (result.victory && result.worldId < 5 && progress.unlockedWorld <= result.worldId) {
    progress.unlockedWorld = result.worldId + 1;
    newlyUnlocked = progress.unlockedWorld;
  }

  return { progress, newlyUnlocked };
}

/** Awards an achievement. Returns [progress, isNew]. */
export function awardAchievement(prev: Progress, id: string): [Progress, boolean] {
  if (prev.achievements.includes(id)) return [prev, false];
  const progress = { ...prev, achievements: [...prev.achievements, id] };
  return [progress, true];
}

export function totalStars(p: Progress): number {
  return [1, 2, 3, 4, 5].reduce((s, i) => s + (p.worlds[String(i)]?.stars ?? 0), 0);
}

export function worldsCompleted(p: Progress): number {
  return [1, 2, 3, 4, 5].filter((i) => p.worlds[String(i)]?.completed).length;
}

export function todayKey(d = new Date()): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}
