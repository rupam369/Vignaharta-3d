// ============================================================
// Shared game-engine helpers: math, camera, canvas art.
// All visuals are procedural/vector — no external artwork.
// ============================================================
import type { LevelResult, PlayId } from "./types";

// ---------------- math ----------------
export const clamp = (v: number, a: number, b: number): number => (v < a ? a : v > b ? b : v);
export const lerp = (a: number, b: number, t: number): number => a + (b - a) * t;

/** deterministic RNG */
export function mulberry32(seed: number): () => number {
  let s = seed >>> 0;
  return () => {
    s |= 0;
    s = (s + 0x6d2b79f5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function hashSeed(str: string): number {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export function formatScore(n: number): string {
  return Math.floor(n).toLocaleString("en-IN");
}

export function formatTime(sec: number): string {
  const s = Math.max(0, Math.ceil(sec));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}

// ---------------- engine plumbing ----------------
export interface EndPayload {
  victory: boolean;
  score: number;
  modaks: number;
  diyas: number;
  distance: number;
  maxCombo: number;
  accuracy: number;
  heartsLeft: number;
  damageTaken: number;
  stars: number;
}

export interface EngineCallbacks {
  onEnd: (r: EndPayload) => void;
  onAchievement: (id: string) => void;
}

export function toResult(worldId: PlayId, e: EndPayload, best: number): LevelResult {
  return {
    worldId,
    victory: e.victory,
    score: Math.floor(e.score),
    best: Math.max(best, Math.floor(e.score)),
    isNewBest: Math.floor(e.score) > best,
    modaks: e.modaks,
    diyas: e.diyas,
    distance: Math.floor(e.distance),
    maxCombo: e.maxCombo,
    accuracy: e.accuracy,
    heartsLeft: e.heartsLeft,
    damageTaken: e.damageTaken,
    stars: e.stars,
  };
}

/** trauma-based screen shake camera */
export class Camera {
  x = 0;
  y = 0;
  trauma = 0;
  private sx = 0;
  private sy = 0;
  reducedMotion = false;

  addShake(amount: number): void {
    if (this.reducedMotion) return;
    this.trauma = clamp(this.trauma + amount, 0, 1);
  }

  update(dt: number): void {
    this.trauma = Math.max(0, this.trauma - dt * 1.6);
    const s = this.trauma * this.trauma * 14;
    this.sx = (Math.random() * 2 - 1) * s;
    this.sy = (Math.random() * 2 - 1) * s;
  }

  apply(ctx: CanvasRenderingContext2D): void {
    ctx.translate(this.sx, this.sy);
  }
}

export interface Star {
  x: number; // 0..1
  y: number; // 0..1
  r: number;
  phase: number;
}

export function makeStars(count: number, seed: number): Star[] {
  const rnd = mulberry32(seed);
  const out: Star[] = [];
  for (let i = 0; i < count; i++) {
    out.push({ x: rnd(), y: rnd() * 0.62, r: 0.5 + rnd() * 1.4, phase: rnd() * Math.PI * 2 });
  }
  return out;
}

// ---------------- palette ----------------
export const C = {
  nightTop: "#070b26",
  nightMid: "#10163a",
  gold: "#f5b942",
  saffron: "#ff7a1a",
  deepRed: "#a41623",
  cream: "#ffe9c4",
  diya: "#ffcf6e",
  leaf: "#2f9e6e",
  pink: "#ff6b8b",
  sky: "#7ec8ff",
};

// ============================================================
// FESTIVAL ART — procedural canvas drawing
// ============================================================

export function drawSky(ctx: CanvasRenderingContext2D, w: number, h: number, top = C.nightTop, mid = C.nightMid): void {
  const g = ctx.createLinearGradient(0, 0, 0, h);
  g.addColorStop(0, top);
  g.addColorStop(0.62, mid);
  g.addColorStop(1, "#1d1440");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
}

export function drawStars(ctx: CanvasRenderingContext2D, stars: Star[], w: number, h: number, t: number): void {
  ctx.save();
  for (const s of stars) {
    const tw = 0.45 + 0.55 * Math.abs(Math.sin(t * 1.4 + s.phase));
    ctx.globalAlpha = tw;
    ctx.fillStyle = "#fff7e6";
    ctx.beginPath();
    ctx.arc(s.x * w, s.y * h, s.r, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

export function drawMoon(ctx: CanvasRenderingContext2D, x: number, y: number, r: number): void {
  const halo = ctx.createRadialGradient(x, y, r * 0.4, x, y, r * 3);
  halo.addColorStop(0, "rgba(255,244,214,0.5)");
  halo.addColorStop(1, "rgba(255,244,214,0)");
  ctx.fillStyle = halo;
  ctx.beginPath();
  ctx.arc(x, y, r * 3, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#fdf3d8";
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "rgba(210,190,150,0.5)";
  ctx.beginPath();
  ctx.arc(x - r * 0.3, y - r * 0.2, r * 0.22, 0, Math.PI * 2);
  ctx.arc(x + r * 0.25, y + r * 0.3, r * 0.15, 0, Math.PI * 2);
  ctx.fill();
}

/** layered temple-shikhara silhouette with glowing windows */
export function drawTempleSilhouette(
  ctx: CanvasRenderingContext2D, w: number, baseY: number, color: string,
  parallax: number, seed = 7, glowColor = "rgba(255,190,90,0.85)"
): void {
  const rnd = mulberry32(seed);
  const off = -(parallax % 480);
  ctx.save();
  ctx.fillStyle = color;
  for (let x = off - 480; x < w + 480; x += 480) {
    // ground strip
    ctx.fillRect(x, baseY - 26, 480, 60);
    // a cluster of 3 shrines per tile
    for (let k = 0; k < 3; k++) {
      const bx = x + 60 + k * 150 + rnd() * 20;
      const bw = 54 + rnd() * 26;
      const bh = 60 + rnd() * 70;
      // shikhara (stepped tower)
      const steps = 5;
      for (let s = 0; s < steps; s++) {
        const sw = bw * (1 - (s / steps) * 0.55);
        const sh = bh / steps;
        ctx.fillRect(bx - sw / 2, baseY - 26 - bh + s * sh, sw, sh + 1);
      }
      // kalash finial
      ctx.beginPath();
      ctx.arc(bx, baseY - 26 - bh - 7, 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillRect(bx - 1.5, baseY - 26 - bh - 4, 3, 8);
      // glowing doorway
      ctx.save();
      ctx.fillStyle = glowColor;
      ctx.globalAlpha = 0.85;
      const dw = 12;
      ctx.beginPath();
      ctx.moveTo(bx - dw / 2, baseY - 26);
      ctx.lineTo(bx - dw / 2, baseY - 44);
      ctx.quadraticCurveTo(bx, baseY - 54, bx + dw / 2, baseY - 44);
      ctx.lineTo(bx + dw / 2, baseY - 26);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
      ctx.fillStyle = color;
    }
  }
  ctx.restore();
}

/** triangular festival bunting across the top, gently swaying */
export function drawBunting(ctx: CanvasRenderingContext2D, w: number, y: number, t: number, sag = 26): void {
  const colors = ["#ff7a1a", "#f5b942", "#e63956", "#2f9e6e", "#7ec8ff", "#c77dff"];
  const span = 150;
  ctx.save();
  ctx.lineWidth = 2;
  ctx.strokeStyle = "rgba(255,233,196,0.7)";
  for (let x0 = -span; x0 < w + span; x0 += span * 2) {
    ctx.beginPath();
    ctx.moveTo(x0, y);
    ctx.quadraticCurveTo(x0 + span, y + sag * 2, x0 + span * 2, y);
    ctx.stroke();
    for (let i = 1; i < 8; i++) {
      const u = i / 8;
      const fx = x0 + span * 2 * u;
      const fy = y + Math.sin(Math.PI * u) * sag + Math.sin(t * 2 + fx * 0.05) * 2;
      ctx.fillStyle = colors[(i + ((x0 / span) | 0)) % colors.length < 0 ? 0 : (i + ((x0 / span) | 0)) % colors.length];
      ctx.beginPath();
      ctx.moveTo(fx - 8, fy - 2);
      ctx.lineTo(fx + 8, fy - 2);
      ctx.lineTo(fx, fy + 13);
      ctx.closePath();
      ctx.fill();
    }
  }
  ctx.restore();
}

/** marigold garland strip */
export function drawGarland(ctx: CanvasRenderingContext2D, x: number, y: number, len: number, t: number, vertical = false): void {
  ctx.save();
  const n = Math.floor(len / 13);
  for (let i = 0; i < n; i++) {
    const sway = Math.sin(t * 2.2 + i * 0.7) * 1.6;
    const px = vertical ? x + sway : x + i * 13;
    const py = vertical ? y + i * 13 : y + Math.sin(t * 2 + i) * 1.5;
    const r = 5.5;
    ctx.fillStyle = i % 2 === 0 ? "#ff8c1a" : "#ffc93c";
    ctx.beginPath();
    ctx.arc(px, py, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = i % 2 === 0 ? "#e56b00" : "#f0a500";
    ctx.beginPath();
    ctx.arc(px, py, r * 0.45, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

/** glowing clay diya */
export function drawDiya(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, t: number, on = true, glow = 1): void {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  if (on) {
    const flick = 1 + Math.sin(t * 11 + x * 0.1) * 0.12;
    const g = ctx.createRadialGradient(0, -12, 2, 0, -12, 44 * glow);
    g.addColorStop(0, "rgba(255,200,110,0.55)");
    g.addColorStop(1, "rgba(255,150,50,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(0, -12, 44 * glow * flick, 0, Math.PI * 2);
    ctx.fill();
    // flame
    ctx.fillStyle = "#ff9d2e";
    ctx.beginPath();
    ctx.ellipse(0, -13, 4.6, 8.5 * flick, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#ffe9a8";
    ctx.beginPath();
    ctx.ellipse(0, -11, 2.2, 4.6 * flick, 0, 0, Math.PI * 2);
    ctx.fill();
  }
  // clay bowl
  ctx.fillStyle = "#8a4b1f";
  ctx.beginPath();
  ctx.ellipse(0, 0, 13, 6.5, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#b06028";
  ctx.beginPath();
  ctx.ellipse(0, -2.5, 13, 5.5, 0, Math.PI, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#5e2f10";
  ctx.beginPath();
  ctx.ellipse(0, -2.5, 9, 3.4, 0, Math.PI, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

/** sweet modak with pleats */
export function drawModak(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, t: number, glowAmt = 0.6): void {
  ctx.save();
  ctx.translate(x, y);
  const bob = Math.sin(t * 3 + x * 0.05) * 1.5;
  ctx.translate(0, bob);
  ctx.scale(s, s);
  if (glowAmt > 0) {
    const g = ctx.createRadialGradient(0, 0, 2, 0, 0, 30);
    g.addColorStop(0, `rgba(255,215,130,${0.5 * glowAmt})`);
    g.addColorStop(1, "rgba(255,180,80,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(0, 0, 30, 0, Math.PI * 2);
    ctx.fill();
  }
  // body
  const bg = ctx.createLinearGradient(-14, 0, 14, 0);
  bg.addColorStop(0, "#e8d3ae");
  bg.addColorStop(0.5, "#fff6e3");
  bg.addColorStop(1, "#e0c79c");
  ctx.fillStyle = bg;
  ctx.beginPath();
  ctx.moveTo(0, -20);
  ctx.quadraticCurveTo(9, -10, 13, 2);
  ctx.quadraticCurveTo(15, 10, 8, 13);
  ctx.lineTo(-8, 13);
  ctx.quadraticCurveTo(-15, 10, -13, 2);
  ctx.quadraticCurveTo(-9, -10, 0, -20);
  ctx.closePath();
  ctx.fill();
  // pleats
  ctx.strokeStyle = "rgba(150,110,60,0.55)";
  ctx.lineWidth = 1.2;
  for (const dx of [-7, -3.5, 0, 3.5, 7]) {
    ctx.beginPath();
    ctx.moveTo(dx * 0.25, -18);
    ctx.quadraticCurveTo(dx, -6, dx * 1.1, 11);
    ctx.stroke();
  }
  // crown
  ctx.fillStyle = "#f5b942";
  ctx.beginPath();
  ctx.arc(0, -20, 3.4, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#fff3d6";
  ctx.beginPath();
  ctx.arc(-1, -21, 1.1, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

export function drawFlower(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, t: number, color = "#ff6b8b"): void {
  ctx.save();
  ctx.translate(x, y + Math.sin(t * 2.6 + x * 0.08) * 1.5);
  ctx.scale(s, s);
  ctx.fillStyle = color;
  for (let i = 0; i < 5; i++) {
    const a = (i / 5) * Math.PI * 2 + t * 0.6;
    ctx.beginPath();
    ctx.ellipse(Math.cos(a) * 6, Math.sin(a) * 6, 5.4, 3.4, a, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.fillStyle = "#ffd43b";
  ctx.beginPath();
  ctx.arc(0, 0, 3.4, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

export function drawToken(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, t: number): void {
  ctx.save();
  ctx.translate(x, y + Math.sin(t * 3.2 + x * 0.06) * 2);
  const spin = Math.abs(Math.cos(t * 2.4));
  ctx.scale(s * (0.35 + 0.65 * spin), s);
  const g = ctx.createRadialGradient(-3, -4, 1, 0, 0, 12);
  g.addColorStop(0, "#fff3c4");
  g.addColorStop(0.55, "#f5b942");
  g.addColorStop(1, "#c47f12");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(0, 0, 11, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#8a5a0b";
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.arc(0, 0, 8, 0, Math.PI * 2);
  ctx.stroke();
  ctx.fillStyle = "#8a5a0b";
  ctx.font = "700 10px Georgia, serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText("॥", 0, 0.5);
  ctx.restore();
}

// ---------------- Mushak the mouse ----------------
export type MushakState = "run" | "jump" | "slide" | "idle" | "hurt" | "celebrate" | "sit";

export function drawMushak(
  ctx: CanvasRenderingContext2D, x: number, y: number,
  o: { phase: number; state: MushakState; scale?: number; facing?: 1 | -1; invuln?: boolean; t: number }
): void {
  const s = o.scale ?? 1;
  const facing = o.facing ?? 1;
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s * facing, s);
  if (o.invuln && Math.floor(o.t * 12) % 2 === 0) ctx.globalAlpha = 0.45;

  const run = o.phase;
  const squash = o.state === "slide" ? 0.62 : o.state === "jump" ? 1.08 : 1 + Math.sin(run * 2) * 0.03;
  ctx.scale(1, squash);

  // tail
  ctx.strokeStyle = "#8b93b8";
  ctx.lineWidth = 3;
  ctx.lineCap = "round";
  const wag = Math.sin(o.t * 6) * 4;
  ctx.beginPath();
  ctx.moveTo(-12, -8);
  ctx.quadraticCurveTo(-24, -6 + wag, -28, -16 + wag);
  ctx.stroke();

  // back foot / front foot
  const legSwing = o.state === "run" ? Math.sin(run) * 5 : 0;
  ctx.fillStyle = "#6d76a3";
  ctx.beginPath();
  ctx.ellipse(-4 + legSwing, -2, 5, 3, 0, 0, Math.PI * 2);
  ctx.ellipse(7 - legSwing, -2, 5, 3, 0, 0, Math.PI * 2);
  ctx.fill();

  // body
  const bodyG = ctx.createLinearGradient(0, -26, 0, 0);
  bodyG.addColorStop(0, "#aeb8dd");
  bodyG.addColorStop(1, "#7e89b8");
  ctx.fillStyle = bodyG;
  ctx.beginPath();
  ctx.ellipse(1, -13, o.state === "slide" ? 15 : 12, o.state === "slide" ? 8 : 12, 0, 0, Math.PI * 2);
  ctx.fill();
  // belly
  ctx.fillStyle = "#e6ebff";
  ctx.beginPath();
  ctx.ellipse(4, -10, 6, 7, 0, 0, Math.PI * 2);
  ctx.fill();

  // ears
  const earUp = o.state === "jump" ? -3 : Math.sin(run) * 1.2;
  ctx.fillStyle = "#7e89b8";
  ctx.beginPath();
  ctx.arc(-3, -26 + earUp, 7, 0, Math.PI * 2);
  ctx.arc(8, -25 + earUp, 6, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#ffb3c1";
  ctx.beginPath();
  ctx.arc(-3, -26 + earUp, 3.6, 0, Math.PI * 2);
  ctx.arc(8, -25 + earUp, 3, 0, Math.PI * 2);
  ctx.fill();

  // head snout
  ctx.fillStyle = "#aeb8dd";
  ctx.beginPath();
  ctx.ellipse(11, -16, 6, 5, 0.2, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#e78ba0";
  ctx.beginPath();
  ctx.arc(16.5, -17, 2, 0, Math.PI * 2);
  ctx.fill();
  // whiskers
  ctx.strokeStyle = "rgba(230,235,255,0.8)";
  ctx.lineWidth = 1;
  for (let i = 0; i < 3; i++) {
    ctx.beginPath();
    ctx.moveTo(15, -15 + i * 2);
    ctx.lineTo(23, -17 + i * 3);
    ctx.stroke();
  }
  // eye
  const blink = o.state === "hurt" ? 0.4 : Math.sin(o.t * 0.9) > 0.985 ? 0.15 : 1;
  ctx.fillStyle = "#141a33";
  ctx.beginPath();
  ctx.ellipse(9, -19, 2.6, 2.6 * blink, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#fff";
  if (blink > 0.5) {
    ctx.beginPath();
    ctx.arc(9.8, -19.8, 0.9, 0, Math.PI * 2);
    ctx.fill();
  }
  if (o.state === "hurt") {
    // dizzy X
    ctx.strokeStyle = "#141a33";
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(6.5, -21.5);
    ctx.lineTo(11.5, -16.5);
    ctx.moveTo(11.5, -21.5);
    ctx.lineTo(6.5, -16.5);
    ctx.stroke();
  }
  // tilak
  ctx.fillStyle = "#e63956";
  ctx.beginPath();
  ctx.ellipse(6, -24.5, 1.4, 2, 0, 0, Math.PI * 2);
  ctx.fill();

  // saffron scarf flowing behind
  const flow = o.state === "run" ? Math.sin(run * 1.5) * 3 : Math.sin(o.t * 3) * 2;
  ctx.fillStyle = "#ff7a1a";
  ctx.beginPath();
  ctx.moveTo(-4, -22);
  ctx.quadraticCurveTo(-16, -24 + flow, -24 - (o.state === "run" ? 6 : 0), -19 + flow);
  ctx.quadraticCurveTo(-16, -18 + flow, -6, -18);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = "#f5b942";
  ctx.fillRect(-7, -23, 4, 6);

  // celebrate arms
  if (o.state === "celebrate") {
    ctx.strokeStyle = "#7e89b8";
    ctx.lineWidth = 3.4;
    ctx.beginPath();
    ctx.moveTo(0, -14);
    ctx.lineTo(-8, -26);
    ctx.moveTo(2, -14);
    ctx.lineTo(10, -27);
    ctx.stroke();
  }

  ctx.restore();
}

// ---------------- atmosphere ----------------
export function drawVignette(ctx: CanvasRenderingContext2D, w: number, h: number, strength = 0.42): void {
  const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.42, w / 2, h / 2, Math.max(w, h) * 0.78);
  g.addColorStop(0, "rgba(5,3,12,0)");
  g.addColorStop(1, `rgba(5,3,12,${strength})`);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
}

export function drawLightRays(ctx: CanvasRenderingContext2D, w: number, h: number, t: number, alpha = 0.06): void {
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  ctx.translate(w / 2, -h * 0.1);
  for (let i = -2; i <= 2; i++) {
    const a = i * 0.22 + Math.sin(t * 0.3) * 0.02;
    ctx.save();
    ctx.rotate(a);
    const g = ctx.createLinearGradient(0, 0, 0, h * 1.3);
    g.addColorStop(0, `rgba(255,200,120,${alpha})`);
    g.addColorStop(1, "rgba(255,200,120,0)");
    ctx.fillStyle = g;
    ctx.fillRect(-26, 0, 52, h * 1.3);
    ctx.restore();
  }
  ctx.restore();
}

/** soft golden ground glow strip */
export function drawGroundGlow(ctx: CanvasRenderingContext2D, w: number, y: number, h: number): void {
  const g = ctx.createLinearGradient(0, y - 30, 0, y + h);
  g.addColorStop(0, "rgba(245,185,66,0)");
  g.addColorStop(0.45, "rgba(245,185,66,0.16)");
  g.addColorStop(1, "rgba(120,40,20,0.25)");
  ctx.fillStyle = g;
  ctx.fillRect(0, y - 30, w, h + 30);
}
