// ============================================================
// VIGHNAHARTA audio system — centralized, fully procedural.
// Generative Indian-inspired music + ambience beds + 30+ SFX.
// No audio files, no copyright, no network. Mobile-safe:
// ctx unlocks on first gesture, suspends when tab hidden.
// Hierarchy: background < environment < player < events < UI.
// ============================================================

export type MusicMode = "menu" | "street" | "rangoli" | "ghat" | "temple" | "finale";
export type AmbienceKind = "festival" | "rain" | "temple" | null;

interface MusicPattern {
  bpm: number;
  root: number; // Hz
  scale: number[]; // semitones
  melody: (number | null)[]; // scale degrees per 16th, 32 steps
  bassEvery: number; // steps
  tabla: number[]; // per-8th intensity 0..1, 8 steps
  bellEvery: number; // steps, 0 = never
  pluckVol: number;
}

const YAMAN = [0, 2, 4, 6, 7, 9, 11];
const PENT = [0, 2, 4, 7, 9];
const MINOR_PENT = [0, 3, 5, 7, 10];

const PATTERNS: Record<MusicMode, MusicPattern> = {
  menu: {
    bpm: 62, root: 146.8, scale: YAMAN,
    melody: [0, null, null, 2, null, null, 4, null, 3, null, 2, null, 1, null, null, null, 0, null, null, null, 2, null, 4, null, 5, null, 4, null, 2, null, 1, null],
    bassEvery: 16, tabla: [0.5, 0, 0.25, 0, 0.35, 0, 0.25, 0], bellEvery: 32, pluckVol: 0.11,
  },
  street: {
    bpm: 96, root: 130.8, scale: PENT,
    melody: [0, null, 1, null, 2, 1, null, 0, null, 1, null, 2, 3, null, 2, 1, 0, null, 1, null, 2, null, 4, 3, 2, null, 1, null, 0, null, null, null],
    bassEvery: 8, tabla: [0.7, 0.2, 0.45, 0.2, 0.6, 0.2, 0.45, 0.3], bellEvery: 0, pluckVol: 0.1,
  },
  rangoli: {
    bpm: 72, root: 164.8, scale: YAMAN,
    melody: [4, null, null, 3, null, 2, null, null, 1, null, 2, null, 0, null, null, null, 2, null, 3, null, 4, null, 5, null, 4, 3, null, 2, null, null, null, null],
    bassEvery: 16, tabla: [0.4, 0, 0.2, 0, 0.3, 0, 0.2, 0], bellEvery: 16, pluckVol: 0.1,
  },
  ghat: {
    bpm: 80, root: 138.6, scale: MINOR_PENT,
    melody: [2, null, 1, null, 0, null, null, null, 1, null, 2, null, 3, 2, 1, null, 0, null, null, null, 1, null, 0, null, null, null, null, null, null, null, null, null],
    bassEvery: 16, tabla: [0.45, 0, 0.2, 0.15, 0.35, 0, 0.2, 0], bellEvery: 0, pluckVol: 0.085,
  },
  temple: {
    bpm: 56, root: 146.8, scale: YAMAN,
    melody: [0, null, null, null, null, null, 1, null, null, null, 2, null, null, null, null, null, 1, null, null, null, 0, null, null, null, null, null, null, null, null, null, null, null],
    bassEvery: 32, tabla: [0.3, 0, 0, 0, 0, 0, 0, 0], bellEvery: 24, pluckVol: 0.09,
  },
  finale: {
    bpm: 108, root: 146.8, scale: YAMAN,
    melody: [0, 1, 2, null, 4, null, 3, 2, 1, 2, null, 0, null, 1, 2, null, 4, 5, 4, 3, 2, null, 1, null, 2, 3, 4, null, 5, 6, 7, 6],
    bassEvery: 8, tabla: [0.8, 0.25, 0.5, 0.25, 0.7, 0.25, 0.5, 0.4], bellEvery: 16, pluckVol: 0.1,
  },
};

function semi(root: number, scale: number[], deg: number): number {
  const oct = Math.floor(deg / scale.length);
  const st = scale[((deg % scale.length) + scale.length) % scale.length];
  return root * Math.pow(2, (st + oct * 12) / 12);
}

export class AudioManager {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicBus: GainNode | null = null;
  private sfxBus: GainNode | null = null;
  private envBus: GainNode | null = null;

  private soundOn = true;
  private musicOn = true;
  private masterVol = 90;
  private musicVol = 70;
  private sfxVol = 80;

  // music sequencer
  private mode: MusicMode | null = null;
  private seqTimer: number | null = null;
  private nextT = 0;
  private step = 0;
  private droneNodes: { osc: OscillatorNode[]; gain: GainNode } | null = null;

  // ambience
  private ambKind: AmbienceKind = null;
  private ambNodes: AudioNode[] = [];
  private ambTimer: number | null = null;
  private noiseBuf: AudioBuffer | null = null;

  private lastHurt = 0;
  private lastStep = 0;
  private lastCollide = 0;

  // ================= core =================
  ensure(): AudioContext | null {
    try {
      if (typeof window === "undefined") return null;
      if (!this.ctx) {
        const AC = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
        if (!AC) return null;
        this.ctx = new AC();
        this.master = this.ctx.createGain();
        this.master.connect(this.ctx.destination);
        this.musicBus = this.ctx.createGain();
        this.musicBus.connect(this.master);
        this.sfxBus = this.ctx.createGain();
        this.sfxBus.connect(this.master);
        this.envBus = this.ctx.createGain();
        this.envBus.connect(this.master);
        this.applyVolumes();
      }
      if (this.ctx.state === "suspended") void this.ctx.resume();
      return this.ctx;
    } catch {
      return null;
    }
  }

  setEnabled(sound: boolean, music: boolean): void {
    this.soundOn = sound;
    this.musicOn = music;
    this.applyVolumes();
  }

  setVolumes(master: number, music: number, sfx: number): void {
    this.masterVol = master;
    this.musicVol = music;
    this.sfxVol = sfx;
    this.applyVolumes();
  }

  private applyVolumes(): void {
    if (!this.ctx || !this.master || !this.musicBus || !this.sfxBus || !this.envBus) return;
    const t = this.ctx.currentTime;
    const m = Math.pow(Math.max(0, Math.min(100, this.masterVol)) / 100, 1.4);
    this.master.gain.setTargetAtTime(m, t, 0.05);
    this.musicBus.gain.setTargetAtTime(this.musicOn ? (this.musicVol / 100) * 0.9 : 0, t, 0.08);
    this.sfxBus.gain.setTargetAtTime(this.soundOn ? (this.sfxVol / 100) * 1.0 : 0, t, 0.05);
    this.envBus.gain.setTargetAtTime(this.musicOn ? (this.musicVol / 100) * 0.6 : 0, t, 0.15);
  }

  /** suspend/resume everything (pause menu, hidden tab) */
  pauseAll(paused: boolean): void {
    const ctx = this.ensure();
    if (!ctx) return;
    try {
      if (paused && ctx.state === "running") void ctx.suspend();
      else if (!paused && ctx.state === "suspended") void ctx.resume();
    } catch {
      /* noop */
    }
  }

  // ================= primitives =================
  private tone(
    freq: number, dur: number, type: OscillatorType, vol: number,
    when = 0, slideTo?: number, bus?: GainNode | null, detune = 0
  ): void {
    const ctx = this.ensure();
    const out = bus ?? this.sfxBus;
    if (!ctx || !out) return;
    try {
      const t0 = ctx.currentTime + when;
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(Math.max(20, freq), t0);
      if (detune) osc.detune.value = detune;
      if (slideTo) osc.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), t0 + dur);
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(vol, t0 + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      osc.connect(g);
      g.connect(out);
      osc.start(t0);
      osc.stop(t0 + dur + 0.05);
      osc.onended = () => {
        try {
          osc.disconnect();
          g.disconnect();
        } catch {
          /* noop */
        }
      };
    } catch {
      /* ignore */
    }
  }

  private noise(
    dur: number, vol: number, filterFreq: number, when = 0,
    type: BiquadFilterType = "bandpass", bus?: GainNode | null, sweepTo?: number
  ): void {
    const ctx = this.ensure();
    const out = bus ?? this.sfxBus;
    if (!ctx || !out) return;
    try {
      const t0 = ctx.currentTime + when;
      const len = Math.max(1, Math.floor(ctx.sampleRate * dur));
      const buf = ctx.createBuffer(1, len, ctx.sampleRate);
      const d = buf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
      const src = ctx.createBufferSource();
      src.buffer = buf;
      const f = ctx.createBiquadFilter();
      f.type = type;
      f.frequency.setValueAtTime(filterFreq, t0);
      if (sweepTo) f.frequency.exponentialRampToValueAtTime(sweepTo, t0 + dur);
      f.Q.value = 0.9;
      const g = ctx.createGain();
      g.gain.setValueAtTime(vol, t0);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      src.connect(f);
      f.connect(g);
      g.connect(out);
      src.start(t0);
      src.onended = () => {
        try {
          src.disconnect();
          f.disconnect();
          g.disconnect();
        } catch {
          /* noop */
        }
      };
    } catch {
      /* ignore */
    }
  }

  private sharedNoise(): AudioBuffer | null {
    const ctx = this.ensure();
    if (!ctx) return null;
    if (!this.noiseBuf) {
      const len = ctx.sampleRate * 2;
      this.noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
      const d = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    }
    return this.noiseBuf;
  }

  // ================= generative music =================
  playMusic(mode: MusicMode): void {
    if (this.mode === mode) return;
    this.stopMusic();
    this.mode = mode;
    const ctx = this.ensure();
    if (!ctx || !this.musicBus) return;
    const P = PATTERNS[mode];
    // drone bed (root + fifth, slow breathing LFO)
    try {
      const g = ctx.createGain();
      g.gain.value = 0.05;
      g.connect(this.musicBus);
      const oscs: OscillatorNode[] = [];
      for (const [f, v] of [[P.root / 2, 1], [P.root * 0.75, 0.6]] as const) {
        const o = ctx.createOscillator();
        o.type = "sine";
        o.frequency.value = f;
        const og = ctx.createGain();
        og.gain.value = v;
        o.connect(og);
        og.connect(g);
        o.start();
        oscs.push(o);
      }
      const lfo = ctx.createOscillator();
      lfo.frequency.value = 0.12;
      const lg = ctx.createGain();
      lg.gain.value = 0.018;
      lfo.connect(lg);
      lg.connect(g.gain);
      lfo.start();
      oscs.push(lfo);
      this.droneNodes = { osc: oscs, gain: g };
    } catch {
      /* noop */
    }
    // step sequencer with lookahead
    this.step = 0;
    this.nextT = ctx.currentTime + 0.1;
    const stepDur = 60 / P.bpm / 4;
    this.seqTimer = window.setInterval(() => {
      const c = this.ctx;
      if (!c || !this.musicBus || this.mode !== mode) return;
      if (c.state !== "running" || !this.musicOn) {
        this.nextT = c.currentTime + 0.1; // don't pile up while muted/suspended
        return;
      }
      while (this.nextT < c.currentTime + 0.28) {
        this.scheduleStep(mode, this.step, this.nextT);
        this.nextT += stepDur;
        this.step = (this.step + 1) % 32;
      }
    }, 90);
  }

  private scheduleStep(mode: MusicMode, step: number, t: number): void {
    const c = this.ctx;
    const bus = this.musicBus;
    if (!c || !bus) return;
    const P = PATTERNS[mode];
    const when = Math.max(0, t - c.currentTime);
    // melody pluck
    const deg = P.melody[step];
    if (deg !== null && deg !== undefined) {
      const f = semi(P.root, P.scale, deg) * 2;
      this.tone(f, 0.5, "triangle", P.pluckVol, when, undefined, bus);
      this.tone(f * 2, 0.3, "sine", P.pluckVol * 0.4, when, undefined, bus);
    }
    // bass root
    if (step % P.bassEvery === 0) {
      this.tone(P.root / 2, 1.6, "sine", 0.075, when, undefined, bus);
    }
    // tabla (8th grid)
    if (step % 2 === 0) {
      const v = P.tabla[(step / 2) % 8] ?? 0;
      if (v > 0) {
        const bass = step % 8 === 0;
        this.tone(bass ? 150 : 190, 0.14, "sine", v * 0.16, when, bass ? 70 : 95, bus);
        if (!bass) this.noise(0.05, v * 0.05, 3200, when, "highpass", bus);
      }
    }
    // sparse temple bell
    if (P.bellEvery > 0 && step % P.bellEvery === 8) {
      this.bell(semi(P.root, P.scale, 4) * 4, 0.06, when, bus);
    }
    // finale shimmer
    if (mode === "finale" && step % 4 === 2) {
      this.tone(semi(P.root, P.scale, 7 + ((step / 4) | 0)) * 4, 0.4, "sine", 0.03, when, undefined, bus);
    }
  }

  private bell(freq: number, vol: number, when: number, bus: GainNode | null): void {
    this.tone(freq, 2.4, "sine", vol, when, undefined, bus);
    this.tone(freq * 2.4, 1.6, "sine", vol * 0.4, when, undefined, bus);
    this.tone(freq * 5.4, 0.9, "sine", vol * 0.18, when, undefined, bus);
  }

  stopMusic(): void {
    this.mode = null;
    if (this.seqTimer !== null) {
      window.clearInterval(this.seqTimer);
      this.seqTimer = null;
    }
    if (this.droneNodes && this.ctx) {
      const { osc, gain } = this.droneNodes;
      try {
        gain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.2);
        const os = osc;
        window.setTimeout(() => {
          for (const o of os) {
            try {
              o.stop();
              o.disconnect();
            } catch {
              /* noop */
            }
          }
          try {
            gain.disconnect();
          } catch {
            /* noop */
          }
        }, 700);
      } catch {
        /* noop */
      }
      this.droneNodes = null;
    }
  }

  // ================= ambience beds =================
  startAmbience(kind: Exclude<AmbienceKind, null>): void {
    if (this.ambKind === kind) return;
    this.stopAmbience();
    this.ambKind = kind;
    const ctx = this.ensure();
    const bus = this.envBus;
    const buf = this.sharedNoise();
    if (!ctx || !bus || !buf) return;
    try {
      if (kind === "festival") {
        // distant crowd murmur: looped noise → lowpass + breathing LFO
        const src = ctx.createBufferSource();
        src.buffer = buf;
        src.loop = true;
        const f = ctx.createBiquadFilter();
        f.type = "lowpass";
        f.frequency.value = 420;
        const g = ctx.createGain();
        g.gain.value = 0.05;
        const lfo = ctx.createOscillator();
        lfo.frequency.value = 0.09;
        const lg = ctx.createGain();
        lg.gain.value = 0.025;
        lfo.connect(lg);
        lg.connect(g.gain);
        src.connect(f);
        f.connect(g);
        g.connect(bus);
        src.start();
        lfo.start();
        this.ambNodes.push(src, f, g, lfo, lg);
        // occasional distant bell + chime
        const bellLoop = () => {
          if (this.ambKind !== "festival") return;
          if (ctx.state === "running" && this.musicOn && Math.random() < 0.7) {
            this.bell(880 + Math.random() * 660, 0.028, 0, bus);
          }
          this.ambTimer = window.setTimeout(bellLoop, 7000 + Math.random() * 9000);
        };
        this.ambTimer = window.setTimeout(bellLoop, 4000);
      } else if (kind === "rain") {
        // rain hiss + low rumble
        const mk = (freq: number, type: BiquadFilterType, vol: number) => {
          const src = ctx.createBufferSource();
          src.buffer = buf;
          src.loop = true;
          src.playbackRate.value = 0.7 + Math.random() * 0.6;
          const f = ctx.createBiquadFilter();
          f.type = type;
          f.frequency.value = freq;
          const g = ctx.createGain();
          g.gain.value = vol;
          src.connect(f);
          f.connect(g);
          g.connect(bus);
          src.start();
          this.ambNodes.push(src, f, g);
        };
        mk(4200, "highpass", 0.035);
        mk(300, "lowpass", 0.05);
        // droplet plinks
        const plink = () => {
          if (this.ambKind !== "rain") return;
          if (ctx.state === "running" && this.musicOn) {
            this.tone(1600 + Math.random() * 1600, 0.12, "sine", 0.018, 0, undefined, bus);
          }
          this.ambTimer = window.setTimeout(plink, 250 + Math.random() * 900);
        };
        this.ambTimer = window.setTimeout(plink, 500);
      } else if (kind === "temple") {
        // deep drone + air + sparse bells
        for (const [f, v] of [[73.4, 0.05], [110, 0.035], [220, 0.015]] as const) {
          const o = ctx.createOscillator();
          o.type = "sine";
          o.frequency.value = f;
          const g = ctx.createGain();
          g.gain.value = v;
          o.connect(g);
          g.connect(bus);
          o.start();
          this.ambNodes.push(o, g);
        }
        const bellLoop = () => {
          if (this.ambKind !== "temple") return;
          if (ctx.state === "running" && this.musicOn) {
            this.bell(660, 0.05, 0, bus);
            this.bell(990, 0.03, 0.4, bus);
          }
          this.ambTimer = window.setTimeout(bellLoop, 9000 + Math.random() * 9000);
        };
        this.ambTimer = window.setTimeout(bellLoop, 2500);
      }
    } catch {
      /* noop */
    }
  }

  stopAmbience(): void {
    this.ambKind = null;
    if (this.ambTimer !== null) {
      window.clearTimeout(this.ambTimer);
      this.ambTimer = null;
    }
    const nodes = this.ambNodes;
    this.ambNodes = [];
    window.setTimeout(() => {
      for (const n of nodes) {
        try {
          if (n instanceof AudioBufferSourceNode || n instanceof OscillatorNode) n.stop();
          n.disconnect();
        } catch {
          /* noop */
        }
      }
    }, 400);
  }

  // ================= player =================
  playFootstep(run: boolean): void {
    const now = performance.now();
    if (now - this.lastStep < 110) return;
    this.lastStep = now;
    this.noise(0.07, run ? 0.075 : 0.05, run ? 750 : 550, 0, "lowpass");
  }

  playJump(): void {
    this.noise(0.18, 0.09, 500, 0, "bandpass", null, 1700);
    this.tone(300, 0.16, "sine", 0.08, 0, 620);
  }

  playLand(): void {
    this.tone(130, 0.12, "sine", 0.14, 0, 60);
    this.noise(0.08, 0.06, 500, 0, "lowpass");
  }

  // ================= collectibles =================
  playCollect(step = 0): void {
    const base = 620 + Math.min(step, 16) * 26;
    const det = (Math.random() - 0.5) * 240; // ± variation, never identical
    this.tone(base, 0.13, "sine", 0.2, 0, undefined, null, det);
    this.tone(base * 1.5, 0.16, "sine", 0.14, 0.05, undefined, null, det * 0.5);
  }

  playFlower(): void {
    this.tone(740, 0.1, "triangle", 0.14, 0, undefined, null, (Math.random() - 0.5) * 160);
    this.tone(1108, 0.13, "sine", 0.1, 0.04);
  }

  playToken(): void {
    this.tone(1174, 0.12, "triangle", 0.16);
    this.tone(1568, 0.2, "sine", 0.16, 0.06);
    this.tone(2093, 0.26, "sine", 0.1, 0.12);
  }

  playDiya(): void {
    this.tone(523, 0.18, "sine", 0.18);
    this.tone(784, 0.24, "sine", 0.14, 0.06);
  }

  playDiyaNote(i: number): void {
    const scale = [523, 587, 659, 784, 880];
    this.tone(scale[i % scale.length], 0.32, "triangle", 0.2);
  }

  playFragment(): void {
    [523, 659, 784, 1046, 1318].forEach((f, i) => this.tone(f, 0.3, "sine", 0.16, i * 0.07));
    this.noise(0.4, 0.05, 7000, 0.1, "highpass");
  }

  // ================= combo =================
  playCombo(mult: number): void {
    if (mult <= 1) return;
    if (mult === 2) {
      this.tone(660, 0.12, "triangle", 0.16);
      this.tone(880, 0.14, "triangle", 0.14, 0.06);
    } else if (mult === 3) {
      [660, 830, 990].forEach((f, i) => this.tone(f, 0.13, "triangle", 0.15, i * 0.06));
    } else if (mult === 4) {
      [587, 740, 880, 1174].forEach((f, i) => this.tone(f, 0.14, "sawtooth", 0.07, i * 0.055));
      this.tone(1174, 0.2, "triangle", 0.14, 0.22);
    } else {
      this.playComboFlourish();
    }
  }

  playComboFlourish(): void {
    [523, 659, 784, 1046, 784, 1046, 1318, 1568].forEach((f, i) =>
      this.tone(f, 0.2, "triangle", 0.15, i * 0.07)
    );
    this.noise(0.5, 0.05, 8000, 0.2, "highpass");
  }

  // ================= impact / hearts =================
  playCollision(): void {
    const now = performance.now();
    if (now - this.lastCollide < 250) return;
    this.lastCollide = now;
    this.tone(180, 0.16, "sine", 0.2, 0, 80);
    this.noise(0.12, 0.1, 600, 0, "lowpass");
  }

  playHeartLost(): void {
    this.tone(392, 0.22, "triangle", 0.16);
    this.tone(311, 0.3, "triangle", 0.16, 0.14);
  }

  playGameOver(): void {
    [392, 330, 262, 196].forEach((f, i) => this.tone(f, 0.34, "triangle", 0.15, i * 0.16));
  }

  // ================= UI =================
  playClick(): void {
    this.tone(660, 0.07, "triangle", 0.16);
    this.tone(990, 0.06, "sine", 0.09, 0.02);
  }
  playHover(): void {
    this.tone(520, 0.04, "sine", 0.05);
  }
  playOpen(): void {
    this.tone(440, 0.1, "sine", 0.1, 0, 660);
  }
  playClose(): void {
    this.tone(660, 0.1, "sine", 0.1, 0, 440);
  }
  playPause(): void {
    this.tone(520, 0.12, "triangle", 0.12);
    this.tone(390, 0.14, "triangle", 0.1, 0.08);
  }
  playResume(): void {
    this.tone(390, 0.1, "triangle", 0.12);
    this.tone(520, 0.12, "triangle", 0.12, 0.07);
  }
  playToggle(): void {
    this.tone(750, 0.06, "square", 0.05);
    this.tone(1000, 0.07, "sine", 0.09, 0.03);
  }
  playSelect(): void {
    this.tone(587, 0.12, "triangle", 0.15);
    this.tone(880, 0.18, "triangle", 0.13, 0.08);
  }
  playAchievement(): void {
    [784, 988, 1175, 1568].forEach((f, i) => this.tone(f, 0.2, "sine", 0.16, i * 0.08));
    this.noise(0.3, 0.05, 6000, 0.1, "highpass");
  }

  // ================= milestones =================
  playCheckpoint(): void {
    this.tone(587, 0.12, "triangle", 0.16);
    this.tone(880, 0.22, "triangle", 0.16, 0.1);
  }
  playTick(): void {
    this.tone(1200, 0.05, "sine", 0.09);
  }
  playMistake(): void {
    this.tone(196, 0.2, "triangle", 0.15, 0, 150);
  }
  playRotate(): void {
    this.tone(440, 0.06, "triangle", 0.11);
    this.noise(0.05, 0.04, 2400);
  }
  playSplash(): void {
    this.noise(0.32, 0.18, 1600);
    this.tone(300, 0.22, "sine", 0.09, 0.02, 120);
  }
  playThunder(): void {
    this.noise(1.2, 0.16, 200, 0, "lowpass");
    this.tone(55, 1.0, "sine", 0.1, 0.05, 38);
  }
  playSuccess(): void {
    [523, 659, 784, 1046].forEach((f, i) => this.tone(f, 0.24, "triangle", 0.17, i * 0.09));
  }
  playVictory(): void {
    [523, 659, 784, 1046, 784, 1046, 1318].forEach((f, i) =>
      this.tone(f, 0.26, "triangle", 0.17, i * 0.11)
    );
    this.noise(0.6, 0.045, 7000, 0.3, "highpass");
  }
  playLevelComplete(): void {
    // layered chimes + rising notes + bells + tabla-ish thump
    [659, 784, 988, 1175, 1318].forEach((f, i) => this.tone(f, 0.4, "sine", 0.14, i * 0.1));
    [523, 659, 784, 1046].forEach((f, i) => this.tone(f, 0.3, "triangle", 0.13, 0.15 + i * 0.1));
    this.bell(1318, 0.07, 0.5, this.sfxBus);
    this.tone(150, 0.2, "sine", 0.16, 0, 70);
    this.tone(150, 0.2, "sine", 0.14, 0.55, 70);
  }

  /** ~8s cinematic build → peak → peaceful resolve (Grand Finale) */
  playFinaleCinematic(): void {
    // A: soft swell + rising run
    this.tone(146.8, 2.6, "sine", 0.1, 0);
    [293, 330, 370, 440, 494, 587, 660, 740].forEach((f, i) =>
      this.tone(f, 0.4, "triangle", 0.1, 0.4 + i * 0.22)
    );
    // B: bells answer
    this.bell(880, 0.09, 2.6, this.sfxBus);
    this.bell(1174, 0.08, 3.4, this.sfxBus);
    this.tone(150, 0.25, "sine", 0.16, 2.6, 70);
    // C: peak flourish
    [587, 740, 880, 1175, 880, 1175, 1468, 1760].forEach((f, i) =>
      this.tone(f, 0.32, "triangle", 0.13, 4.2 + i * 0.14)
    );
    this.tone(150, 0.3, "sine", 0.18, 4.2, 65);
    this.noise(0.8, 0.05, 7500, 4.6, "highpass");
    // D: peaceful resolve
    this.bell(1568, 0.1, 6.0, this.sfxBus);
    this.tone(293.6, 3.2, "sine", 0.09, 6.4);
    this.tone(440, 3.2, "sine", 0.06, 6.4);
    this.tone(587, 2.6, "triangle", 0.07, 6.8);
  }

  // ================= rangoli =================
  playRangoliGood(): void {
    this.tone(880, 0.16, "sine", 0.15);
    this.tone(1174, 0.2, "sine", 0.12, 0.07);
  }
  playRangoliPerfect(): void {
    this.tone(1046, 0.16, "sine", 0.17);
    this.tone(1318, 0.18, "sine", 0.15, 0.07);
    this.tone(1760, 0.3, "sine", 0.13, 0.14);
  }
  playRangoliWrong(): void {
    this.tone(233, 0.22, "triangle", 0.13, 0, 180);
  }
  playRangoliFlourish(): void {
    [659, 784, 988, 1175, 1568, 1175, 1568].forEach((f, i) =>
      this.tone(f, 0.26, "sine", 0.14, i * 0.09)
    );
    this.bell(2093, 0.05, 0.5, this.sfxBus);
  }

  // ================= legacy aliases (2D engines still compile) =================
  click(): void { this.playClick(); }
  hover(): void { this.playHover(); }
  collect(step = 0): void { this.playCollect(step); }
  flower(): void { this.playFlower(); }
  token(): void { this.playToken(); }
  perfect(): void { this.playRangoliPerfect(); }
  comboUp(mult: number): void { this.playCombo(mult); }
  hurt(): void {
    const now = performance.now();
    if (now - this.lastHurt < 300) return;
    this.lastHurt = now;
    this.tone(220, 0.22, "sawtooth", 0.14, 0, 110);
    this.noise(0.18, 0.12, 500, 0, "lowpass");
  }
  jump(): void { this.playJump(); }
  slide(): void { this.noise(0.22, 0.09, 900); }
  splash(): void { this.playSplash(); }
  diya(): void { this.playDiya(); }
  diyaNote(i: number): void { this.playDiyaNote(i); }
  rotate(): void { this.playRotate(); }
  checkpoint(): void { this.playCheckpoint(); }
  mistake(): void { this.playMistake(); }
  thunder(): void { this.playThunder(); }
  tick(): void { this.playTick(); }
  success(): void { this.playSuccess(); }
  achievement(): void { this.playAchievement(); }
  victory(): void { this.playVictory(); }
  gameover(): void { this.playGameOver(); }
  startAmbient(mode: "festival" | "rain" | "temple" | "finale"): void {
    if (mode === "festival") {
      this.playMusic("street");
      this.startAmbience("festival");
    } else if (mode === "rain") {
      this.playMusic("ghat");
      this.startAmbience("rain");
    } else if (mode === "temple") {
      this.playMusic("temple");
      this.startAmbience("temple");
    } else {
      this.playMusic("finale");
    }
  }
  stopAmbient(): void {
    this.stopMusic();
    this.stopAmbience();
  }
}

export const audio = new AudioManager();
