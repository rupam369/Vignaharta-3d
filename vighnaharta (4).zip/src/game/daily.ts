// Deterministic daily challenge derived from the calendar date.
import { hashSeed } from "./engine";
import { todayKey } from "./storage";

export interface DailyConfig {
  key: string;
  label: string;
  seed: number;
  goalModaks: number;
  timeLimit: number;
  brief: string;
}

export function getDailyConfig(d = new Date()): DailyConfig {
  const key = todayKey(d);
  const seed = hashSeed(`vighnaharta-daily-${key}`);
  // fixed friendly goal: quick and fun for everyone
  const goalModaks = 7;
  return {
    key,
    label: d.toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long" }),
    seed,
    goalModaks,
    timeLimit: 90,
    brief: `Collect ${goalModaks} Modaks in 90 seconds!`,
  };
}
