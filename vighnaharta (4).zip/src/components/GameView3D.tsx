"use client";
// ============================================================
// GameView3D — WebGL host + 3D HUD + joystick + camera touch.
// Owns the Three.js level lifecycle; React re-renders HUD ~10Hz.
// ============================================================
import { useCallback, useEffect, useRef, useState } from "react";
import { audio } from "@/game/audio";
import { toResult } from "@/game/engine";
import type { EndPayload } from "@/game/engine";
import { createInput3D } from "@/game3d/input3d";
import type { LevelBase } from "@/game3d/levelbase";
import { Level1Streets } from "@/game3d/levels/level1";
import { Level2Rangoli } from "@/game3d/levels/level2";
import { Level3Ghat } from "@/game3d/levels/level3";
import { Level4Temple } from "@/game3d/levels/level4";
import { Level5Finale } from "@/game3d/levels/level5";
import type { HudState, LevelResult, PlayId, Settings } from "@/game/types";
import { PauseMenu, ResultsScreen } from "./Overlays";

interface Props {
  playId: PlayId;
  settings: Settings;
  best: number;
  daily?: { seed: number; goalModaks: number; timeLimit: number } | null;
  title: string;
  onExit: () => void;
  onNext: (() => void) | null;
  onComplete: (r: LevelResult) => void;
  onAchievement: (id: string) => void;
  onOpenSettings: () => void;
}

export default function GameView3D({
  playId, settings, best, daily, title,
  onExit, onNext, onComplete, onAchievement, onOpenSettings,
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const overlayRef = useRef<HTMLDivElement>(null);
  const levelRef = useRef<LevelBase | null>(null);
  const inputRef = useRef(createInput3D());
  const dragRef = useRef({ down: false, sx: 0, sy: 0, moved: 0, t0: 0 });
  const [runId, setRunId] = useState(0);
  const [hud, setHud] = useState<HudState | null>(null);
  const [paused, setPaused] = useState(false);
  const [result, setResult] = useState<LevelResult | null>(null);
  const [touch, setTouch] = useState({ move: true, jump: true, slide: false, interact: false });
  const [scorePulse, setScorePulse] = useState(0);
  const prevScore = useRef(0);

  const bestRef = useRef(best);
  bestRef.current = best;
  const playIdRef = useRef(playId);
  playIdRef.current = playId;

  const handleEnd = useCallback(
    (e: EndPayload) => {
      const r = toResult(playIdRef.current, e, bestRef.current);
      setResult(r);
      onComplete(r);
    },
    [onComplete]
  );

  // ---- level lifecycle ----
  useEffect(() => {
    const canvas = canvasRef.current;
    const overlay = overlayRef.current;
    if (!canvas || !overlay) return;
    audio.ensure();
    const input = inputRef.current;
    input.keys.clear();
    input.jumpQueued = false;
    input.interactQueued = false;
    input.pauseQueued = false;
    input.joyX = 0;
    input.joyY = 0;

    const cb = {
      onEnd: handleEnd,
      onAchievement: (id: string) => onAchievement(id),
    };
    const opts = {
      canvas, overlay, input, settings,
      daily: playId === "daily" && daily ? { goalModaks: daily.goalModaks, timeLimit: daily.timeLimit } : null,
    };
    let level: LevelBase;
    if (playId === 1 || playId === "daily") level = new Level1Streets(opts, cb);
    else if (playId === 2) level = new Level2Rangoli(opts, cb);
    else if (playId === 3) level = new Level3Ghat(opts, cb);
    else if (playId === 4) level = new Level4Temple(opts, cb);
    else level = new Level5Finale(opts, cb);

    levelRef.current = level;
    try {
      level.buildScene();
      level.start();
    } catch (err) {
      console.error("Level build failed:", err);
      if (overlay) {
        overlay.innerHTML = `<div class="load-error">⚠️ This world failed to load.<br/>Please refresh the page!</div>`;
      }
    }
    setTouch(level.needsTouch());

    const onKeyDown = (e: KeyboardEvent) => {
      const c = e.code;
      if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(c)) e.preventDefault();
      if (e.repeat) return;
      input.keys.add(c);
      if (c === "Space" || c === "ArrowUp" || c === "KeyW") input.jumpQueued = true;
      else if (c === "KeyE" || c === "KeyF" || c === "Enter") input.interactQueued = true;
      else if (c === "Escape" || c === "KeyP") input.pauseQueued = true;
    };
    const onKeyUp = (e: KeyboardEvent) => {
      input.keys.delete(e.code);
    };
    const onBlur = () => {
      input.keys.clear();
      input.joyX = 0;
      input.joyY = 0;
    };
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    window.addEventListener("blur", onBlur);

    const tick = window.setInterval(() => {
      if (input.pauseQueued) {
        input.pauseQueued = false;
        setPaused((p) => {
          if (levelRef.current && !result) {
            const np = !p;
            levelRef.current.setPaused(np);
            if (np) audio.playPause();
            else audio.playResume();
            return np;
          }
          return p;
        });
      }
      const h = level.getHud();
      setHud(h);
      if (h.score !== prevScore.current) {
        prevScore.current = h.score;
        setScorePulse((s) => s + 1);
      }
      setTouch(level.needsTouch());
    }, 100);

    const onVis = () => {
      if (document.hidden && levelRef.current && !result) {
        levelRef.current.setPaused(true);
        setPaused(true);
      }
    };
    document.addEventListener("visibilitychange", onVis);

    return () => {
      window.clearInterval(tick);
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("blur", onBlur);
      level.destroy();
      levelRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playId, runId]);

  useEffect(() => {
    audio.setEnabled(settings.sound, settings.music);
    audio.setVolumes(settings.masterVolume, settings.musicVolume, settings.sfxVolume);
  }, [settings.sound, settings.music, settings.masterVolume, settings.musicVolume, settings.sfxVolume]);

  const togglePause = useCallback(() => {
    if (result || !levelRef.current) return;
    setPaused((p) => {
      const np = !p;
      levelRef.current?.setPaused(np);
      if (np) audio.playPause();
      else audio.playResume();
      return np;
    });
  }, [result]);

  const restart = useCallback(() => {
    audio.playClick();
    setResult(null);
    setPaused(false);
    setHud(null);
    prevScore.current = 0;
    setRunId((r) => r + 1);
  }, []);

  const quit = useCallback(() => {
    audio.playClick();
    onExit();
  }, [onExit]);

  // ---- camera drag + tap-to-interact on canvas ----
  const onCanvasDown = useCallback((e: React.PointerEvent<HTMLCanvasElement>) => {
    audio.ensure();
    const d = dragRef.current;
    d.down = true;
    d.sx = e.clientX;
    d.sy = e.clientY;
    d.moved = 0;
    d.t0 = performance.now();
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
  }, []);

  const onCanvasMove = useCallback((e: React.PointerEvent<HTMLCanvasElement>) => {
    const d = dragRef.current;
    if (!d.down || paused || result) return;
    const dx = e.clientX - d.sx;
    const dy = e.clientY - d.sy;
    d.sx = e.clientX;
    d.sy = e.clientY;
    d.moved += Math.abs(dx) + Math.abs(dy);
    inputRef.current.camDX += dx;
    inputRef.current.camDY += dy;
  }, [paused, result]);

  const onCanvasUp = useCallback((e: React.PointerEvent<HTMLCanvasElement>) => {
    const d = dragRef.current;
    d.down = false;
    if (paused || result) return;
    const dt = performance.now() - d.t0;
    if (d.moved < 9 && dt < 400) {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      inputRef.current.tapNDC = {
        x: ((e.clientX - rect.left) / rect.width) * 2 - 1,
        y: -(((e.clientY - rect.top) / rect.height) * 2 - 1),
      };
    }
  }, [paused, result]);

  const timer = hud?.timer;
  const timerDanger = timer !== undefined && timer <= 10;

  return (
    <div className="game-shell" onContextMenu={(e) => e.preventDefault()}>
      <div className="game-stage">
        <canvas
          ref={canvasRef}
          className="game-canvas"
          onPointerDown={onCanvasDown}
          onPointerMove={onCanvasMove}
          onPointerUp={onCanvasUp}
          onPointerCancel={() => { dragRef.current.down = false; }}
        />
        <div ref={overlayRef} className="overlay3d" />

        {/* ---------- HUD ---------- */}
        {hud && !result && (
          <div className="hud">
            <div className="hud-top">
              <div className="hud-left">
                <div className={`hud-score ${scorePulse ? "pulse" : ""}`} key={scorePulse}>
                  {Math.floor(hud.score).toLocaleString("en-IN")}
                </div>
                <div className={`hud-combo ${hud.comboMult > 1 ? "hot" : ""}`} key={hud.comboMult}>
                  {hud.comboMult > 1 ? `🔥 COMBO x${hud.comboMult}` : `${hud.combo} combo`}
                </div>
              </div>
              <div className="hud-center">
                <div className="hud-progress">
                  <div className="hud-progress-fill" style={{ width: `${Math.round(hud.progress * 100)}%` }} />
                </div>
                <div className="hud-phase">
                  {hud.phase || title}
                  {timer !== undefined && (
                    <span className={`hud-timer ${timerDanger ? "danger" : ""}`}>
                      {" "}· ⏱ {Math.floor(Math.ceil(timer) / 60)}:{String(Math.ceil(timer) % 60).padStart(2, "0")}
                    </span>
                  )}
                </div>
              </div>
              <div className="hud-right">
                <div className="hud-hearts">
                  {Array.from({ length: hud.maxHearts }).map((_, i) => (
                    <span key={i} className={`heart ${i < hud.hearts ? "on" : "off"}`}>♥</span>
                  ))}
                </div>
                <div className="hud-items">
                  <span title="Modaks">🍬 {hud.modaks}</span>
                  {hud.diyas > 0 && <span title="Diyas">🪔 {hud.diyas}</span>}
                </div>
                <button className="icon-btn" onClick={togglePause} aria-label="Pause">⏸</button>
              </div>
            </div>
            {hud.message && (
              <div className="hud-banner" key={hud.messageKey}>
                {hud.message}
              </div>
            )}
          </div>
        )}

        {/* ---------- low-HP warning ---------- */}
        {hud && !result && hud.hearts === 1 && <div className="lowhp-veil" />}

        {/* ---------- touch controls ---------- */}
        {!result && !paused && (
          <>
            <Joystick inputRef={inputRef} />
            <div className="touch-layer act">
              <div className="touch-cluster left" />
              <div className="touch-cluster right">
                {touch.interact && (
                  <button
                    className="touch-btn wide gold"
                    onPointerDown={(e) => { e.preventDefault(); inputRef.current.interactQueued = true; }}
                    onContextMenu={(e) => e.preventDefault()}
                    aria-label="Interact"
                  >
                    ✋ USE
                  </button>
                )}
                <button
                  className="touch-btn wide primary"
                  onPointerDown={(e) => {
                    e.preventDefault();
                    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
                    inputRef.current.keys.add("Space");
                    inputRef.current.jumpQueued = true;
                  }}
                  onPointerUp={() => inputRef.current.keys.delete("Space")}
                  onPointerCancel={() => inputRef.current.keys.delete("Space")}
                  onLostPointerCapture={() => inputRef.current.keys.delete("Space")}
                  onContextMenu={(e) => e.preventDefault()}
                  aria-label="Jump"
                >
                  ⬆ JUMP
                </button>
              </div>
            </div>
          </>
        )}

        {paused && !result && (
          <PauseMenu
            onResume={togglePause}
            onRestart={restart}
            onSettings={onOpenSettings}
            onQuit={quit}
          />
        )}

        {result && (
          <ResultsScreen
            result={result}
            playId={playId}
            onRetry={restart}
            onMap={quit}
            onNext={result.victory ? onNext : null}
          />
        )}
      </div>
    </div>
  );
}

// ----------------------------------------------------------------
function Joystick({ inputRef }: { inputRef: React.MutableRefObject<{ joyX: number; joyY: number }> }) {
  const baseRef = useRef<HTMLDivElement>(null);
  const knobRef = useRef<HTMLDivElement>(null);
  const activeRef = useRef<number | null>(null);
  const R = 46;

  const setKnob = (dx: number, dy: number) => {
    if (knobRef.current) knobRef.current.style.transform = `translate(${dx}px, ${dy}px)`;
  };

  const handle = (clientX: number, clientY: number) => {
    const base = baseRef.current;
    if (!base) return;
    const rect = base.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    let dx = clientX - cx;
    let dy = clientY - cy;
    const len = Math.hypot(dx, dy);
    if (len > R) {
      dx = (dx / len) * R;
      dy = (dy / len) * R;
    }
    setKnob(dx, dy);
    inputRef.current.joyX = dx / R;
    inputRef.current.joyY = -dy / R;
  };

  const release = () => {
    activeRef.current = null;
    setKnob(0, 0);
    inputRef.current.joyX = 0;
    inputRef.current.joyY = 0;
  };

  return (
    <div
      ref={baseRef}
      className="joy-base"
      onPointerDown={(e) => {
        e.preventDefault();
        audio.ensure();
        activeRef.current = e.pointerId;
        (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
        handle(e.clientX, e.clientY);
      }}
      onPointerMove={(e) => {
        if (activeRef.current === e.pointerId) handle(e.clientX, e.clientY);
      }}
      onPointerUp={(e) => {
        if (activeRef.current === e.pointerId) release();
      }}
      onPointerCancel={release}
      onLostPointerCapture={release}
      onContextMenu={(e) => e.preventDefault()}
    >
      <div ref={knobRef} className="joy-knob" />
    </div>
  );
}
