"use client";
// ============================================================
// Title · Story intro · World map screens
// ============================================================
import { useEffect, useMemo, useState } from "react";
import { audio } from "@/game/audio";
import type { DailyConfig } from "@/game/daily";
import { STORY_LINES, WORLD_META } from "@/game/types";
import type { Progress } from "@/game/types";
import { totalStars, worldsCompleted } from "@/game/storage";

// ================= TITLE =================
export function TitleScreen({
  hasSave, playerName, onPlay, onContinue, onDaily, onHowTo, onSettings,
}: {
  hasSave: boolean;
  playerName: string;
  onPlay: () => void;
  onContinue: () => void;
  onDaily: () => void;
  onHowTo: () => void;
  onSettings: () => void;
}) {
  const [intro, setIntro] = useState(true);
  useEffect(() => {
    const t = window.setTimeout(() => setIntro(false), 2100);
    return () => window.clearTimeout(t);
  }, []);

  const diyas = useMemo(
    () =>
      Array.from({ length: 14 }).map((_, i) => ({
        left: (i * 71 + 13) % 100,
        delay: (i * 0.7) % 6,
        dur: 5 + ((i * 37) % 40) / 10,
        size: 8 + ((i * 23) % 10),
      })),
    []
  );

  if (intro) {
    return (
      <div className="title-screen">
        <TitleBg diyas={diyas} />
        <div className="intro-splash">
          <div className="intro-om">॥ श्री गणेशाय नमः ॥</div>
          <div className="intro-sub">a festival adventure</div>
        </div>
      </div>
    );
  }

  return (
    <div className="title-screen">
      <TitleBg diyas={diyas} />
      <div className="bunting-css" aria-hidden />
      <div className="title-content fade-up">
        <div className="title-kicker">॥ Ganapati Bappa Morya ॥</div>
        <h1 className="game-title">
          <span className="t1">VIGHNAHARTA</span>
          <span className="t2">✦ THE LOST MODAK ✦</span>
        </h1>
        <p className="tagline">“Every journey has a purpose. Every obstacle has a way through.”</p>
        <MushakSvg />
        {playerName ? <div className="welcome-back">Welcome back, {playerName}! 🙏</div> : null}
        <div className="btn-col title-btns">
          <button className="btn primary big glow" onClick={() => { audio.ensure(); audio.click(); onPlay(); }}>
            ▶ &nbsp;Play
          </button>
          {hasSave && (
            <button className="btn big" onClick={() => { audio.ensure(); audio.click(); onContinue(); }}>
              🗺 &nbsp;Continue Journey
            </button>
          )}
          <button className="btn" onClick={() => { audio.ensure(); audio.click(); onDaily(); }}>
            📅 &nbsp;Daily Challenge
          </button>
          <div className="btn-row">
            <button className="btn small" onClick={() => { audio.click(); onHowTo(); }}>❓ How to Play</button>
            <button className="btn small" onClick={() => { audio.click(); onSettings(); }}>⚙ Settings</button>
          </div>
        </div>
        <div className="title-foot">Made with devotion for the Ganesh Chaturthi Game Design Contest 🪔</div>
      </div>
    </div>
  );
}

function TitleBg({ diyas }: { diyas: { left: number; delay: number; dur: number; size: number }[] }) {
  return (
    <div className="title-bg" aria-hidden>
      <div className="tb-stars" />
      <div className="tb-moon" />
      <div className="tb-rays" />
      {diyas.map((d, i) => (
        <span
          key={i}
          className="tb-diya"
          style={{
            left: `${d.left}%`,
            width: d.size,
            height: d.size,
            animationDelay: `${d.delay}s`,
            animationDuration: `${d.dur}s`,
          }}
        />
      ))}
      <svg className="tb-temple" viewBox="0 0 800 200" preserveAspectRatio="xMidYMax slice">
        <g fill="#0d0a24">
          <rect x="0" y="170" width="800" height="30" />
          <rect x="120" y="90" width="70" height="80" />
          <rect x="135" y="60" width="40" height="35" />
          <rect x="330" y="60" width="90" height="110" />
          <rect x="350" y="25" width="50" height="40" />
          <rect x="580" y="100" width="60" height="70" />
          <rect x="592" y="72" width="36" height="30" />
        </g>
        <g fill="#f5b942">
          <circle cx="155" cy="52" r="5" />
          <circle cx="375" cy="16" r="6" />
          <circle cx="610" cy="64" r="4" />
        </g>
        <g fill="rgba(255,190,90,0.9)">
          <rect x="148" y="130" width="14" height="40" rx="7" />
          <rect x="368" y="115" width="16" height="55" rx="8" />
          <rect x="602" y="132" width="12" height="38" rx="6" />
        </g>
      </svg>
      <div className="tb-ground" />
    </div>
  );
}

function MushakSvg() {
  return (
    <svg className="mushak-hero" viewBox="0 0 120 96" aria-hidden>
      <path d="M18 70 Q6 72 4 58" stroke="#8b93b8" strokeWidth="4" fill="none" strokeLinecap="round" />
      <ellipse cx="60" cy="66" rx="30" ry="22" fill="#7e89b8" />
      <ellipse cx="66" cy="70" rx="16" ry="14" fill="#e6ebff" />
      <circle cx="46" cy="36" r="13" fill="#7e89b8" />
      <circle cx="46" cy="36" r="6" fill="#ffb3c1" />
      <circle cx="72" cy="38" r="11" fill="#7e89b8" />
      <circle cx="72" cy="38" r="5" fill="#ffb3c1" />
      <ellipse cx="84" cy="58" rx="12" ry="10" fill="#aeb8dd" />
      <circle cx="95" cy="56" r="3.4" fill="#e78ba0" />
      <circle cx="82" cy="52" r="4" fill="#141a33" />
      <circle cx="83.4" cy="50.6" r="1.3" fill="#fff" />
      <ellipse cx="76" cy="44" rx="2.2" ry="3.2" fill="#e63956" />
      <path d="M52 46 Q34 42 22 50 Q34 52 50 52 Z" fill="#ff7a1a" />
      <rect x="48" y="43" width="7" height="11" fill="#f5b942" />
    </svg>
  );
}

// ================= STORY =================
export function StoryIntro({ onDone, onSkip }: { onDone: () => void; onSkip: () => void }) {
  const [line, setLine] = useState(0);
  const [chars, setChars] = useState(0);

  useEffect(() => {
    audio.ensure();
    audio.startAmbient("festival");
    return () => audio.stopAmbient();
  }, []);

  useEffect(() => {
    setChars(0);
    const full = STORY_LINES[line] ?? "";
    const iv = window.setInterval(() => {
      setChars((c) => {
        if (c >= full.length) {
          window.clearInterval(iv);
          return c;
        }
        return c + 2;
      });
    }, 24);
    return () => window.clearInterval(iv);
  }, [line]);

  const next = () => {
    audio.click();
    const full = STORY_LINES[line] ?? "";
    if (chars < full.length) {
      setChars(full.length); // tap = complete line first
      return;
    }
    if (line >= STORY_LINES.length - 1) onDone();
    else setLine(line + 1);
  };

  return (
    <div className="story-screen" onClick={next}>
      <div className="story-bg" aria-hidden>
        <div className="tb-stars" />
        <div className="tb-moon" />
        {Array.from({ length: 7 }).map((_, i) => (
          <span key={i} className="story-diya" style={{ left: `${8 + i * 14}%`, animationDelay: `${i * 0.5}s` }} />
        ))}
      </div>
      <div className="story-box fade-up" onClick={(e) => e.stopPropagation()}>
        <div className="story-kicker">✦ The night before the Utsav ✦</div>
        <p className="story-line" onClick={next}>
          {(STORY_LINES[line] ?? "").slice(0, chars)}
          <span className="caret">▌</span>
        </p>
        <div className="story-dots">
          {STORY_LINES.map((_, i) => (
            <span key={i} className={`dot ${i === line ? "on" : i < line ? "done" : ""}`} />
          ))}
        </div>
        <div className="btn-row">
          <button className="btn ghost small" onClick={() => { audio.click(); onSkip(); }}>Skip Intro ⏭</button>
          <button className="btn primary" onClick={next}>
            {line >= STORY_LINES.length - 1 ? "Begin the Journey 🙏" : "Next ▸"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ================= WORLD MAP =================
export function WorldMap({
  progress, daily, dailyBest, onPlayWorld, onPlayDaily, onHowTo, onSettings, onAchievements,
}: {
  progress: Progress;
  daily: DailyConfig;
  dailyBest: number;
  onPlayWorld: (id: 1 | 2 | 3 | 4 | 5) => void;
  onPlayDaily: () => void;
  onHowTo: () => void;
  onSettings: () => void;
  onAchievements: () => void;
}) {
  const stars = totalStars(progress);
  const done = worldsCompleted(progress);
  const name = progress.settings.playerName || "Mushak";

  return (
    <div className="map-screen">
      <div className="map-bg" aria-hidden>
        <div className="tb-stars" />
        <div className="tb-moon" />
      </div>
      <div className="map-wrap">
        <header className="profile-card fade-up">
          <div className="profile-mouse">🐭</div>
          <div className="profile-main">
            <div className="profile-name">{name}</div>
            <div className="profile-role">Festival Explorer · Ganesh Utsav</div>
            <div className="profile-stats">
              <span>⭐ {stars}/15</span>
              <span>🍬 {progress.totalModaks}</span>
              <span>🪔 {progress.totalDiyas}</span>
              <span>🗺 {done}/5 worlds</span>
              <span>🏆 {progress.achievements.length}/8</span>
            </div>
          </div>
        </header>

        <button className="daily-card fade-up" onClick={() => { audio.ensure(); audio.click(); onPlayDaily(); }}>
          <div className="daily-left">
            <div className="daily-kicker">📅 Daily Challenge · {daily.label}</div>
            <div className="daily-brief">{daily.brief}</div>
            <div className="daily-best">
              {dailyBest > 0 ? `Today's best: ${dailyBest.toLocaleString("en-IN")}` : "No attempt yet today — be the first!"}
            </div>
          </div>
          <div className="daily-play">PLAY ▸</div>
        </button>

        <h2 className="map-h">Choose your destination</h2>
        <div className="world-grid">
          {WORLD_META.map((w, idx) => {
            const unlocked = progress.unlockedWorld >= w.id;
            const best = progress.worlds[String(w.id)];
            return (
              <article
                key={w.id}
                className={`world-card fade-up ${unlocked ? "" : "locked"}`}
                style={{ animationDelay: `${idx * 0.07}s` }}
              >
                <div className="world-top">
                  <span className="world-icon">{unlocked ? w.icon : "🔒"}</span>
                  <div>
                    <div className="world-name">{w.id}. {w.name}</div>
                    <div className="world-tag">{w.tag}</div>
                  </div>
                </div>
                <p className="world-desc">{unlocked ? w.desc : "Complete the previous world to unlock this destination."}</p>
                {unlocked && (
                  <>
                    <div className="world-meta">
                      <span className="world-stars">
                        {[0, 1, 2].map((i) => (
                          <span key={i} className={best && i < best.stars ? "lit" : ""}>★</span>
                        ))}
                      </span>
                      <span>Best {((best?.bestScore ?? 0)).toLocaleString("en-IN")}</span>
                      <span>🍬 {best?.modaks ?? 0}</span>
                    </div>
                    <div className="world-ctrl">{w.controlHint}</div>
                    <button
                      className="btn primary world-play"
                      onClick={() => { audio.ensure(); audio.click(); onPlayWorld(w.id); }}
                    >
                      {best?.completed ? "↻  Play Again" : "▶  Play"}
                    </button>
                  </>
                )}
              </article>
            );
          })}
        </div>

        <footer className="map-foot">
          <button className="btn small" onClick={() => { audio.click(); onHowTo(); }}>❓ How to Play</button>
          <button className="btn small" onClick={() => { audio.click(); onAchievements(); }}>🏆 Achievements</button>
          <button className="btn small" onClick={() => { audio.click(); onSettings(); }}>⚙ Settings</button>
        </footer>
        <div className="title-foot">“Every journey has a purpose. Every obstacle has a way through.” 🙏</div>
      </div>
    </div>
  );
}
