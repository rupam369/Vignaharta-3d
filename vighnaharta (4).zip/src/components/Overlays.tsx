"use client";
// ============================================================
// Overlay UI: pause, results, settings, how-to-play, toasts.
// ============================================================
import { useState } from "react";
import { audio } from "@/game/audio";
import { ACHIEVEMENTS } from "@/game/types";
import type { LevelResult, PlayId, Settings } from "@/game/types";

// ---------------- Pause ----------------
export function PauseMenu({
  onResume, onRestart, onSettings, onQuit,
}: {
  onResume: () => void;
  onRestart: () => void;
  onSettings: () => void;
  onQuit: () => void;
}) {
  return (
    <div className="overlay">
      <div className="panel pop-in">
        <div className="panel-om">॥ श्री ॥</div>
        <h2 className="panel-title">Paused</h2>
        <p className="panel-sub">Bappa is waiting… take your breath.</p>
        <div className="btn-col">
          <button className="btn primary" onClick={() => { audio.click(); onResume(); }}>▶ &nbsp;Resume</button>
          <button className="btn" onClick={() => { audio.click(); onRestart(); }}>↻ &nbsp;Restart</button>
          <button className="btn" onClick={() => { audio.click(); onSettings(); }}>⚙ &nbsp;Settings</button>
          <button className="btn ghost" onClick={() => { audio.click(); onQuit(); }}>🗺 &nbsp;Quit to Map</button>
        </div>
      </div>
    </div>
  );
}

// ---------------- Results ----------------
export function ResultsScreen({
  result, playId, onRetry, onMap, onNext,
}: {
  result: LevelResult;
  playId: PlayId;
  onRetry: () => void;
  onMap: () => void;
  onNext: (() => void) | null;
}) {
  const v = result.victory;
  const isDaily = playId === "daily";
  const title = !v
    ? isDaily ? "Time's Up!" : "Run Complete"
    : playId === 5 ? "The Modak Has Returned" : isDaily ? "Challenge Complete!" : "Level Complete!";
  const sub = !v
    ? "Every obstacle has a way through. Try again!"
    : playId === 5 ? "GANAPATI BAPPA MORYA! 🙏" : "The festival glows brighter because of you.";

  return (
    <div className="overlay">
      <div className={`panel pop-in results ${v ? "victory" : ""} ${playId === 5 && v ? "finale" : ""}`}>
        {v && (
          <div className="stars-row">
            {[0, 1, 2].map((i) => (
              <span key={i} className={`star ${i < result.stars ? "lit" : ""}`} style={{ animationDelay: `${0.25 + i * 0.22}s` }}>
                ★
              </span>
            ))}
          </div>
        )}
        <div className="panel-om">॥ {v ? "🎉" : "🪔"} ॥</div>
        <h2 className="panel-title">{title}</h2>
        <p className="panel-sub">{sub}</p>

        <div className="stats-grid">
          <div className="stat">
            <div className="stat-val gold">{result.score.toLocaleString("en-IN")}</div>
            <div className="stat-key">Score {result.isNewBest && <span className="newbest">NEW BEST!</span>}</div>
          </div>
          <div className="stat">
            <div className="stat-val">{result.best.toLocaleString("en-IN")}</div>
            <div className="stat-key">Best</div>
          </div>
          <div className="stat">
            <div className="stat-val">🍬 {result.modaks}</div>
            <div className="stat-key">Modaks</div>
          </div>
          {result.diyas > 0 && (
            <div className="stat">
              <div className="stat-val">🪔 {result.diyas}</div>
              <div className="stat-key">Diyas</div>
            </div>
          )}
          {result.distance > 0 && (
            <div className="stat">
              <div className="stat-val">{result.distance}m</div>
              <div className="stat-key">Distance</div>
            </div>
          )}
          <div className="stat">
            <div className="stat-val">x{result.maxCombo}</div>
            <div className="stat-key">Best Combo</div>
          </div>
          <div className="stat">
            <div className="stat-val">{Math.round(result.accuracy * 100)}%</div>
            <div className="stat-key">Accuracy</div>
          </div>
          <div className="stat">
            <div className="stat-val">{"♥".repeat(Math.max(0, result.heartsLeft)) || "—"}</div>
            <div className="stat-key">Hearts Left</div>
          </div>
        </div>

        <div className="btn-col">
          {onNext && (
            <button className="btn primary glow" onClick={() => { audio.ensure(); audio.success(); onNext(); }}>
              Next World ▸
            </button>
          )}
          <button className="btn primary" onClick={() => { audio.click(); onRetry(); }}>
            {v ? "↻  Play Again" : "↻  Try Again"}
          </button>
          <button className="btn ghost" onClick={() => { audio.click(); onMap(); }}>🗺 &nbsp;World Map</button>
        </div>
      </div>
    </div>
  );
}

// ---------------- Volume ----------------
function VolRow({
  label,
  value,
  onChange,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
}) {
  return (
    <label className="set-row vol-row">
      <span>
        <span className="set-label">{label}</span>
      </span>
      <span className="vol-wrap">
        <input
          className="vol-slider"
          type="range"
          min={0}
          max={100}
          step={5}
          value={value}
          onChange={(e) => {
            audio.ensure();
            onChange(Number(e.target.value));
          }}
          aria-label={label}
        />
        <span className="vol-val">{value}%</span>
      </span>
    </label>
  );
}

// ---------------- Settings ----------------
export function SettingsModal({
  settings, onChange, onClose, onReset,
}: {
  settings: Settings;
  onChange: (s: Settings) => void;
  onClose: () => void;
  onReset: () => void;
}) {
  const [confirmReset, setConfirmReset] = useState(false);
  const row = (label: string, desc: string, key: "sound" | "music" | "reducedMotion" | "highContrast") => (
    <label className="set-row" key={key}>
      <span>
        <span className="set-label">{label}</span>
        <span className="set-desc">{desc}</span>
      </span>
      <button
        role="switch"
        aria-checked={settings[key]}
        className={`switch ${settings[key] ? "on" : ""}`}
        onClick={(e) => {
          e.preventDefault();
          audio.ensure();
          audio.click();
          onChange({ ...settings, [key]: !settings[key] });
        }}
      >
        <span className="knob" />
      </button>
    </label>
  );

  return (
    <div className="overlay">
      <div className="panel pop-in settings-panel">
        <div className="panel-om">॥ ⚙ ॥</div>
        <h2 className="panel-title">Settings</h2>
        {row("🔊 Sound Effects", "Dhol taps, collects, celebrations", "sound")}
        {row("🎵 Music", "Ambient festival rhythm", "music")}
        {row("🍃 Reduced Motion", "Calmer particles & no screen shake", "reducedMotion")}
        {row("◐ High Contrast", "Bolder text & UI outlines", "highContrast")}
        <label className="set-row">
          <span>
            <span className="set-label">🙋 Explorer Name</span>
            <span className="set-desc">Shown on your festival profile</span>
          </span>
          <input
            className="name-input"
            maxLength={18}
            placeholder="Mushak"
            value={settings.playerName}
            onChange={(e) => onChange({ ...settings, playerName: e.target.value })}
          />
        </label>
        <div className="set-sep">Volume</div>
        <VolRow
          label="🎚️ Master"
          value={settings.masterVolume ?? 90}
          onChange={(v) => onChange({ ...settings, masterVolume: v })}
        />
        <VolRow
          label="🎵 Music"
          value={settings.musicVolume ?? 70}
          onChange={(v) => onChange({ ...settings, musicVolume: v })}
        />
        <VolRow
          label="🔔 Effects"
          value={settings.sfxVolume ?? 80}
          onChange={(v) => onChange({ ...settings, sfxVolume: v })}
        />
        <div className="btn-col">
          <button className="btn primary" onClick={() => { audio.click(); onClose(); }}>Done</button>
          {!confirmReset ? (
            <button className="btn danger-ghost" onClick={() => setConfirmReset(true)}>
              Reset all progress…
            </button>
          ) : (
            <button className="btn danger" onClick={() => { onReset(); setConfirmReset(false); }}>
              Yes, erase my journey
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// ---------------- How to play ----------------
export function HowToPlay({ onClose }: { onClose: () => void }) {
  return (
    <div className="overlay">
      <div className="panel pop-in howto">
        <div className="panel-om">॥ 🪔 ॥</div>
        <h2 className="panel-title">How to Play</h2>
        <p className="panel-sub">
          Guide <b>Mushak</b> through 5 explorable 3D festival worlds to recover the Lost Modak.
          Finish a world to unlock the next!
        </p>
        <div className="howto-grid">
          <div className="howto-card">
            <div className="howto-h">🖥️ Desktop Controls</div>
            <p><b>WASD / arrows</b> move · <b>mouse-drag</b> to look around · <b>Space</b> jump · <b>E</b> use / light / talk · <b>Shift</b> sprint.</p>
          </div>
          <div className="howto-card">
            <div className="howto-h">📱 Mobile Controls</div>
            <p><b>Left joystick</b> move · <b>drag right side</b> to look · <b>JUMP</b> leap · gold <b>USE</b> lights diyas &amp; talks. Push the stick fully to sprint! Or just tap glowing things!</p>
          </div>
          <div className="howto-card">
            <div className="howto-h">🏮 1 · Festival Streets</div>
            <p>Explore the moonlit bazaar, grab <b>3 brass fragments</b>, light festival diyas (E), and climb the flag-steps. Dodge the rolling carts — a bump costs a heart!</p>
          </div>
          <div className="howto-card">
            <div className="howto-h">🌸 2 · Rangoli Courtyard</div>
            <p>Walk to the glowing flame and press <b>E</b> (or tap it) in the shown order to bloom the rangoli rings. Mistakes only cost time — the pattern stays kind!</p>
          </div>
          <div className="howto-card">
            <div className="howto-h">🌧️ 3 · Monsoon Ghat</div>
            <p>Hop stones, ride boats — or <b>dive in and SWIM</b> to the <b>8 floating diyas</b>! Swim into a platform to climb out. Falling in never hurts! 💦</p>
          </div>
          <div className="howto-card">
            <div className="howto-h">🛕 4 · Temple Courtyard</div>
            <p><b>STEP 1:</b> go <b>NORTH</b> to the 5 big diyas — watch the order, then replay it with <b>E / tap</b> (3 short rounds). <b>STEP 2:</b> go <b>EAST</b>, tap each chakra till <b>ALIGNED!</b> <b>STEP 3:</b> walk through the glowing <b>east gate</b>! Follow the golden marker ✨ — the red wall opens when the puzzles are done. Take your time — if you're stuck, the temple helps you onward!</p>
          </div>
          <div className="howto-card">
            <div className="howto-h">🎆 5 · Grand Finale</div>
            <p><b>STEP 1:</b> gather <b>6 offerings</b> (follow the light-beams). <b>STEP 2:</b> light the <b>3 flames in number order</b>. <b>STEP 3:</b> watch the mandap diyas, then replay the order. <b>STEP 4:</b> walk into the glowing mandap! Stuck anywhere? Bappa guides you onward! 🙏✨</p>
          </div>
          <div className="howto-card">
            <div className="howto-h">✨ Scoring</div>
            <p>🍬 Modak +100 · 🌸 Flower +25 · 🪙 Token +250 · 🪔 Diya +150. Chain pickups to raise your combo to <b>x5</b>!</p>
          </div>
        </div>
        <div className="btn-col">
          <button className="btn primary" onClick={() => { audio.click(); onClose(); }}>Got it!</button>
        </div>
      </div>
    </div>
  );
}

// ---------------- Achievements ----------------
export function AchievementsPanel({ unlocked, onClose }: { unlocked: string[]; onClose: () => void }) {
  return (
    <div className="overlay">
      <div className="panel pop-in howto">
        <div className="panel-om">॥ 🏆 ॥</div>
        <h2 className="panel-title">Achievements</h2>
        <p className="panel-sub">{unlocked.length} of {ACHIEVEMENTS.length} unlocked</p>
        <div className="ach-grid">
          {ACHIEVEMENTS.map((a) => {
            const has = unlocked.includes(a.id);
            return (
              <div key={a.id} className={`ach-card ${has ? "got" : "locked"}`}>
                <div className="ach-icon">{has ? a.icon : "🔒"}</div>
                <div className="ach-name">{a.name}</div>
                <div className="ach-desc">{a.desc}</div>
              </div>
            );
          })}
        </div>
        <div className="btn-col">
          <button className="btn primary" onClick={() => { audio.click(); onClose(); }}>Close</button>
        </div>
      </div>
    </div>
  );
}

// ---------------- Toasts ----------------
export interface Toast {
  key: number;
  icon: string;
  name: string;
  desc: string;
}

export function Toasts({ toasts }: { toasts: Toast[] }) {
  return (
    <div className="toasts" aria-live="polite">
      {toasts.map((t) => (
        <div key={t.key} className="toast pop-in">
          <div className="toast-icon">{t.icon}</div>
          <div>
            <div className="toast-title">🏆 {t.name}</div>
            <div className="toast-desc">{t.desc}</div>
          </div>
        </div>
      ))}
    </div>
  );
}
